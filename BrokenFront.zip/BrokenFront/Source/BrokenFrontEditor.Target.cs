using UnrealBuildTool;

public class BrokenFrontEditorTarget : TargetRules
{
	public BrokenFrontEditorTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Editor;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
		ExtraModuleNames.Add("BrokenFront");
	}
}
