#include "Vehicles/BFVehicleBase.h"

#include "Camera/CameraComponent.h"
#include "Characters/BFCharacter.h"
#include "ChaosVehicleMovementComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Core/BFLog.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Net/UnrealNetwork.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"
#include "Systems/BFDamageManager.h"
#include "TimerManager.h"

ABFVehicleBase::ABFVehicleBase()
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;
	SetReplicateMovement(true);
	NetUpdateFrequency = 40.f;

	DriverCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("DriverCamera"));
	DriverCamera->SetupAttachment(GetMesh());
	DriverCamera->SetRelativeLocation(FVector(30.f, -40.f, 130.f));
	DriverCamera->bUsePawnControlRotation = false;

	// A sensible default seat set; derived Blueprints override it.
	FBFVehicleSeat Driver;
	Driver.SeatSocket = TEXT("Seat_Driver");
	Driver.bIsDriver = true;
	Seats.Add(Driver);
}

void ABFVehicleBase::BeginPlay()
{
	Super::BeginPlay();

	if (HasAuthority())
	{
		Health = MaxHealth;
		EnginePowerScale = 1.f;
	}
}

void ABFVehicleBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFVehicleBase, Health);
	DOREPLIFETIME(ABFVehicleBase, bDisabled);
	DOREPLIFETIME(ABFVehicleBase, OwningTeam);
	DOREPLIFETIME(ABFVehicleBase, EnginePowerScale);
}

void ABFVehicleBase::SetOwningTeam(EBFTeam NewTeam)
{
	if (HasAuthority())
	{
		OwningTeam = NewTeam;
	}
}

bool ABFVehicleBase::bIsEngineBone(FName BoneName) const
{
	if (BoneName.IsNone())
	{
		return false;
	}

	if (EngineBones.Contains(BoneName))
	{
		return true;
	}

	const FString Name = BoneName.ToString().ToLower();
	return Name.Contains(TEXT("engine")) || Name.Contains(TEXT("hood")) || Name.Contains(TEXT("bonnet"));
}

void ABFVehicleBase::ApplyVehicleDamage(float Damage, const FHitResult& Hit, const FVector& /*Direction*/, ABFCharacter* Instigator)
{
	if (!HasAuthority() || bDisabled || Damage <= 0.f)
	{
		return;
	}

	// Armour blunts incoming fire. Engine-bay hits bypass most of it.
	const bool bEngineHit = bIsEngineBone(Hit.BoneName);
	const float Reduction = bEngineHit ? ArmourReduction * 0.4f : ArmourReduction;
	float Applied = Damage * (1.f - Reduction);

	if (bEngineHit)
	{
		Applied *= EngineHitMultiplier;
		EnginePowerScale = FMath::Max(0.25f, EnginePowerScale - 0.06f);
	}

	Health = FMath::Max(0.f, Health - Applied);

	// Degrade performance as the hull takes punishment.
	if (UChaosVehicleMovementComponent* VehicleMovement = GetVehicleMovementComponent())
	{
		VehicleMovement->SetThrottleInput(VehicleMovement->GetThrottleInput() * EnginePowerScale);
	}

	if (GetHealthPercent() <= DisabledThreshold)
	{
		bDisabled = true;
		OnRep_Disabled();

		BF_LOG(LogBFCombat, Log, TEXT("%s disabled."), *GetName());

		// Eject everyone: sitting in a burning wreck is not a strategy.
		for (FBFVehicleSeat& Seat : Seats)
		{
			if (Seat.Occupant)
			{
				ExitVehicle(Seat.Occupant);
			}
		}

		GetWorldTimerManager().SetTimer(WreckTimer, this, &ABFVehicleBase::Explode, WreckExplodeDelay, false);
	}
}

float ABFVehicleBase::RepairVehicle(float Amount)
{
	if (!HasAuthority() || bDisabled || Amount <= 0.f)
	{
		return 0.f;
	}

	const float Before = Health;
	Health = FMath::Min(MaxHealth, Health + Amount);
	EnginePowerScale = FMath::Min(1.f, EnginePowerScale + 0.05f);
	return Health - Before;
}

void ABFVehicleBase::Explode()
{
	if (!HasAuthority())
	{
		return;
	}

	// Reuse the shared explosion path so the wreck craters the ground and shreds
	// nearby cover exactly like any other blast.
	UBFDamageManager::ApplyExplosion(this, GetActorLocation(), 700.f, 160.f, this, true, 2.f);

	if (UNiagaraSystem* Effect = ExplosionEffect.LoadSynchronous())
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Effect, GetActorLocation(), GetActorRotation());
	}

	SetLifeSpan(30.f); // leave a burnt-out hull as cover for a while
}

void ABFVehicleBase::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (HasAuthority() && !bDisabled)
	{
		// Clamp top speed with engine damage so a beaten-up truck limps home.
		if (UChaosVehicleMovementComponent* VehicleMovement = GetVehicleMovementComponent())
		{
			if (EnginePowerScale < 1.f)
			{
				VehicleMovement->SetThrottleInput(FMath::Min(VehicleMovement->GetThrottleInput(), EnginePowerScale));
			}
		}
	}
}

int32 ABFVehicleBase::GetFreeSeatIndex() const
{
	for (int32 Index = 0; Index < Seats.Num(); ++Index)
	{
		if (!Seats[Index].Occupant)
		{
			return Index;
		}
	}
	return INDEX_NONE;
}

int32 ABFVehicleBase::GetOccupantCount() const
{
	int32 Count = 0;
	for (const FBFVehicleSeat& Seat : Seats)
	{
		if (Seat.Occupant)
		{
			++Count;
		}
	}
	return Count;
}

bool ABFVehicleBase::EnterVehicle(ABFCharacter* Character, int32 SeatIndex)
{
	if (!HasAuthority() || !Character || bDisabled)
	{
		return false;
	}

	if (OwningTeam != EBFTeam::Neutral && Character->GetTeam() != OwningTeam)
	{
		return false;
	}

	if (SeatIndex < 0)
	{
		SeatIndex = GetFreeSeatIndex();
	}

	if (!Seats.IsValidIndex(SeatIndex) || Seats[SeatIndex].Occupant)
	{
		return false;
	}

	FBFVehicleSeat& Seat = Seats[SeatIndex];
	Seat.Occupant = Character;

	// Attach the soldier to the seat socket and hand the vehicle the controller if driving.
	const FAttachmentTransformRules Rules(EAttachmentRule::SnapToTarget, true);
	Character->AttachToComponent(GetMesh(), Rules, Seat.SeatSocket);
	Character->GetCharacterMovement()->DisableMovement();
	Character->SetActorEnableCollision(false);

	if (Seat.bIsDriver)
	{
		if (AController* Controller = Character->GetController())
		{
			Controller->Possess(this);
		}
	}

	// Claim the vehicle for whoever crews it first.
	if (OwningTeam == EBFTeam::Neutral)
	{
		OwningTeam = Character->GetTeam();
	}

	return true;
}

bool ABFVehicleBase::ExitVehicle(ABFCharacter* Character)
{
	if (!HasAuthority() || !Character)
	{
		return false;
	}

	for (FBFVehicleSeat& Seat : Seats)
	{
		if (Seat.Occupant != Character)
		{
			continue;
		}

		Seat.Occupant = nullptr;

		Character->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		Character->SetActorEnableCollision(true);
		Character->GetCharacterMovement()->SetMovementMode(MOVE_Walking);

		// Step out to the side, clear of the hull.
		const FVector ExitLocation = GetActorLocation() + GetActorRightVector() * 260.f + FVector(0.f, 0.f, 60.f);
		Character->SetActorLocation(ExitLocation, false, nullptr, ETeleportType::TeleportPhysics);

		if (Seat.bIsDriver)
		{
			if (AController* Controller = GetController())
			{
				Controller->Possess(Character);
			}
		}

		return true;
	}

	return false;
}

bool ABFVehicleBase::CanInteract_Implementation(ABFCharacter* Interactor) const
{
	if (!Interactor || bDisabled)
	{
		return false;
	}

	if (OwningTeam != EBFTeam::Neutral && Interactor->GetTeam() != OwningTeam)
	{
		return false;
	}

	return GetFreeSeatIndex() != INDEX_NONE;
}

void ABFVehicleBase::Interact_Implementation(ABFCharacter* Interactor)
{
	EnterVehicle(Interactor, -1);
}

FText ABFVehicleBase::GetInteractionPrompt_Implementation(ABFCharacter* Interactor) const
{
	if (bDisabled)
	{
		return NSLOCTEXT("BrokenFront", "VehicleDisabled", "Disabled");
	}
	return NSLOCTEXT("BrokenFront", "VehicleEnter", "Enter vehicle");
}

void ABFVehicleBase::OnRep_Disabled()
{
	if (bDisabled && GetNetMode() != NM_DedicatedServer)
	{
		if (UNiagaraSystem* Smoke = SmokeEffect.LoadSynchronous())
		{
			UNiagaraFunctionLibrary::SpawnSystemAttached(Smoke, GetMesh(), NAME_None,
				FVector::ZeroVector, FRotator::ZeroRotator, EAttachLocation::SnapToTarget, true);
		}
	}
}
