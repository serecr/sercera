#pragma once

#include "CoreMinimal.h"
#include "WheeledVehiclePawn.h"
#include "Core/BFTypes.h"
#include "Core/BFInteractable.h"
#include "BFVehicleBase.generated.h"

class UCameraComponent;
class ABFCharacter;
class UNiagaraSystem;

UENUM(BlueprintType)
enum class EBFVehicleClass : uint8
{
	Transport,
	Armoured,
	Cargo,
	Scout
};

/** One seat. Driver seats steer, gunner seats get a mounted weapon socket. */
USTRUCT(BlueprintType)
struct FBFVehicleSeat
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) FName SeatSocket = TEXT("Seat_Driver");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) bool bIsDriver = false;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) bool bIsGunner = false;
	/** Enclosed seats protect the occupant from small-arms fire. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) bool bEnclosed = true;
	UPROPERTY(BlueprintReadOnly) TObjectPtr<ABFCharacter> Occupant = nullptr;
};

/**
 * Base for every vehicle, built on Chaos Vehicles so physics, suspension and
 * wheel friction come from the engine rather than a bespoke simulation.
 *
 * Damage is component-aware: hits on the engine bay reduce power, hits on wheels
 * degrade handling, and the armour value blunts small-arms fire entirely, which
 * is what makes an armoured car frightening to infantry without a launcher.
 */
UCLASS(Abstract)
class BROKENFRONT_API ABFVehicleBase : public AWheeledVehiclePawn, public IBFInteractable
{
	GENERATED_BODY()

public:
	ABFVehicleBase();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	/** Server: routed from the damage manager. */
	void ApplyVehicleDamage(float Damage, const FHitResult& Hit, const FVector& Direction, ABFCharacter* Instigator);

	/** Server: Engineer repair. Returns the amount restored. */
	float RepairVehicle(float Amount);

	UFUNCTION(BlueprintPure, Category = "Vehicle") EBFTeam GetTeam() const { return OwningTeam; }
	UFUNCTION(BlueprintPure, Category = "Vehicle") float GetHealthPercent() const { return MaxHealth > 0.f ? Health / MaxHealth : 0.f; }
	UFUNCTION(BlueprintPure, Category = "Vehicle") bool IsDisabled() const { return bDisabled; }
	UFUNCTION(BlueprintPure, Category = "Vehicle") EBFVehicleClass GetVehicleClass() const { return VehicleClass; }
	UFUNCTION(BlueprintPure, Category = "Vehicle") int32 GetFreeSeatIndex() const;
	UFUNCTION(BlueprintPure, Category = "Vehicle") int32 GetOccupantCount() const;

	/** Server: seat management. */
	UFUNCTION(BlueprintCallable, Category = "Vehicle") bool EnterVehicle(ABFCharacter* Character, int32 SeatIndex = -1);
	UFUNCTION(BlueprintCallable, Category = "Vehicle") bool ExitVehicle(ABFCharacter* Character);

	void SetOwningTeam(EBFTeam NewTeam);

	// IBFInteractable
	virtual void Interact_Implementation(ABFCharacter* Interactor) override;
	virtual FText GetInteractionPrompt_Implementation(ABFCharacter* Interactor) const override;
	virtual bool CanInteract_Implementation(ABFCharacter* Interactor) const override;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UCameraComponent> DriverCamera;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	EBFVehicleClass VehicleClass = EBFVehicleClass::Transport;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	TArray<FBFVehicleSeat> Seats;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "100.0"))
	float MaxHealth = 2200.f;

	/**
	 * Flat damage reduction against bullets. Armoured vehicles set this high so
	 * rifles cannot kill them; explosives ignore most of it.
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "0.0", ClampMax = "0.98"))
	float ArmourReduction = 0.75f;

	/** Below this fraction the vehicle stops moving and starts burning. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "0.0", ClampMax = "0.5"))
	float DisabledThreshold = 0.15f;

	/** Bone names that count as the engine bay: hits here hurt much more. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	TArray<FName> EngineBones;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float EngineHitMultiplier = 2.2f;

	/** Seconds after being disabled before the wreck explodes. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float WreckExplodeDelay = 6.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "FX") TSoftObjectPtr<UNiagaraSystem> SmokeEffect;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "FX") TSoftObjectPtr<UNiagaraSystem> ExplosionEffect;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") float Health = 2200.f;
	UPROPERTY(ReplicatedUsing = OnRep_Disabled, BlueprintReadOnly, Category = "State") bool bDisabled = false;
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") EBFTeam OwningTeam = EBFTeam::Neutral;
	/** Engine power scalar, degraded by engine-bay damage. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") float EnginePowerScale = 1.f;

	UFUNCTION() void OnRep_Disabled();

	void Explode();

private:
	FTimerHandle WreckTimer;
	bool bIsEngineBone(FName BoneName) const;
};
