#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Core/BFTypes.h"
#include "BFWeaponDataAsset.generated.h"

class UAnimMontage;
class USkeletalMesh;
class USoundBase;
class UNiagaraSystem;
class UTexture2D;
class ABFProjectile;

/**
 * Every tuning value of a weapon lives here. AWeaponBase owns zero hardcoded numbers,
 * so a designer can ship a new gun by creating one asset + one mesh, no code change.
 */
UCLASS(BlueprintType)
class BROKENFRONT_API UBFWeaponDataAsset : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	// ---------- Identity ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	FName WeaponId = NAME_None;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	FText DisplayName;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	EBFWeaponCategory Category = EBFWeaponCategory::Rifle;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	EBFWeaponSlot Slot = EBFWeaponSlot::Primary;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	TSoftObjectPtr<UTexture2D> Icon;

	/** Unlock level on the class progression track. 0 = available from the start. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	int32 UnlockLevel = 0;

	// ---------- Ballistics ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "1.0"))
	float BaseDamage = 34.f;

	/** Damage multiplier applied per hit bone group, e.g. "head" -> 2.0. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics")
	TMap<FName, float> HitZoneMultipliers;

	/** Damage retained at MaxEffectiveRange and beyond (0..1). */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "0.05", ClampMax = "1.0"))
	float MinDamageFalloff = 0.45f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "100.0"))
	float MaxEffectiveRange = 9000.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "100.0"))
	float MaxTraceRange = 30000.f;

	/** cm/s. Above zero with bUseProjectiles spawns a simulated round with drop. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "0.0"))
	float BulletVelocity = 72000.f;

	/** Projectile simulation is more honest at long range; hitscan is cheaper. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics")
	bool bUseProjectiles = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics")
	TSubclassOf<ABFProjectile> ProjectileClass;

	/** Pellets per shot. 1 for everything except shotguns. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "1"))
	int32 PelletsPerShot = 1;

	/** How much of the damage penetrates light wooden cover (0..1). */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Ballistics", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float PenetrationPower = 0.25f;

	// ---------- Handling ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "30.0"))
	float RoundsPerMinute = 620.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling")
	TArray<EBFFireMode> FireModes { EBFFireMode::FullAuto, EBFFireMode::SingleShot };

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "1"))
	int32 BurstCount = 3;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "1"))
	int32 MagazineSize = 30;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "0"))
	int32 StartingMagazines = 5;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "0.2"))
	float ReloadTime = 2.4f;

	/** Shorter path used when a round is still chambered. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "0.2"))
	float TacticalReloadTime = 2.0f;

	/** Shell-by-shell weapons (shotgun) reload in increments. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling")
	bool bShellByShellReload = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "0.05"))
	float EquipTime = 0.6f;

	/** kg. Feeds movement speed and ADS time. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "0.5"))
	float WeightKg = 3.8f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "0.05"))
	float AimDownSightTime = 0.25f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Handling", meta = (ClampMin = "5.0", ClampMax = "120.0"))
	float AimFOV = 55.f;

	// ---------- Recoil & spread ----------
	/** Degrees of upward kick per shot. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Recoil")
	float RecoilPitch = 0.55f;

	/** Absolute horizontal kick; sign is randomised per shot. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Recoil")
	float RecoilYaw = 0.2f;

	/** How fast the view returns to the pre-fire aim point (per second). */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Recoil", meta = (ClampMin = "0.1"))
	float RecoilRecoverySpeed = 7.f;

	/** Recoil accumulates during sustained fire up to this multiplier. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Recoil", meta = (ClampMin = "1.0"))
	float MaxRecoilMultiplier = 2.2f;

	/** Cone half-angle in degrees while hip firing and settled. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread", meta = (ClampMin = "0.0"))
	float BaseSpread = 1.1f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread", meta = (ClampMin = "0.0"))
	float AimSpread = 0.08f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread", meta = (ClampMin = "0.0"))
	float SpreadPerShot = 0.22f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread", meta = (ClampMin = "0.0"))
	float MaxSpread = 4.5f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread", meta = (ClampMin = "0.1"))
	float SpreadRecoverySpeed = 3.2f;

	/** Multipliers applied to spread by stance / motion. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread") float CrouchSpreadScale = 0.75f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread") float ProneSpreadScale = 0.55f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread") float MovingSpreadScale = 1.6f;
	/** Bipod / trench parapet rest bonus. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Spread") float BracedSpreadScale = 0.4f;

	// ---------- Presentation ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Visual")
	TSoftObjectPtr<USkeletalMesh> WeaponMesh;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Visual")
	TSoftObjectPtr<UNiagaraSystem> MuzzleFlash;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Visual")
	TSoftObjectPtr<UNiagaraSystem> ShellEject;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Visual")
	TSoftObjectPtr<UNiagaraSystem> TracerEffect;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation") TSoftObjectPtr<UAnimMontage> FireMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation") TSoftObjectPtr<UAnimMontage> ReloadMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation") TSoftObjectPtr<UAnimMontage> ReloadEmptyMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation") TSoftObjectPtr<UAnimMontage> EquipMontage;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation") TSoftObjectPtr<UAnimMontage> InspectMontage;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Audio") TSoftObjectPtr<USoundBase> FireSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Audio") TSoftObjectPtr<USoundBase> FireTailIndoorSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Audio") TSoftObjectPtr<USoundBase> DryFireSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Audio") TSoftObjectPtr<USoundBase> ReloadSound;

	/** Seconds between shots derived from RPM. */
	UFUNCTION(BlueprintPure, Category = "Handling")
	float GetShotInterval() const { return 60.f / FMath::Max(RoundsPerMinute, 1.f); }

	/** Damage at a given distance using linear falloff between 0 and MaxEffectiveRange. */
	UFUNCTION(BlueprintPure, Category = "Ballistics")
	float GetDamageAtDistance(float Distance) const
	{
		const float Alpha = FMath::Clamp(Distance / FMath::Max(MaxEffectiveRange, 1.f), 0.f, 1.f);
		return BaseDamage * FMath::Lerp(1.f, MinDamageFalloff, Alpha);
	}

	/** Movement speed penalty factor from weapon weight. */
	UFUNCTION(BlueprintPure, Category = "Handling")
	float GetWeightSpeedScale() const
	{
		// 3.5 kg is the reference rifle; every extra kg costs ~3% speed, floored at 0.8.
		return FMath::Clamp(1.f - (WeightKg - 3.5f) * 0.03f, 0.8f, 1.05f);
	}
};
