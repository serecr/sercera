#pragma once

#include "CoreMinimal.h"
#include "Core/BFTypes.h"
#include "BFLoadout.generated.h"

class UBFWeaponDataAsset;
class UBFSoldierClassDataAsset;
class ABFEquipmentBase;
class ABFWeaponBase;

/**
 * What a player deploys with. Chosen in the loadout screen, replicated on the
 * PlayerState, and consumed by the inventory when the pawn spawns.
 */
USTRUCT(BlueprintType)
struct FBFLoadout
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) TObjectPtr<UBFSoldierClassDataAsset> SoldierClass = nullptr;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TObjectPtr<UBFWeaponDataAsset> Primary = nullptr;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TObjectPtr<UBFWeaponDataAsset> Secondary = nullptr;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TSubclassOf<ABFEquipmentBase> Equipment = nullptr;

	/** Cosmetic only: uniform and attachment ids resolved from the profile. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FName UniformId = NAME_None;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<FName> CosmeticIds;

	bool IsValid() const { return SoldierClass != nullptr && Primary != nullptr; }
};

/** Maps a weapon category to the actor class that should be spawned for it. */
USTRUCT(BlueprintType)
struct FBFWeaponClassMapping
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) EBFWeaponCategory Category = EBFWeaponCategory::Rifle;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSubclassOf<ABFWeaponBase> WeaponClass;
};
