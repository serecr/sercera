#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Core/BFTypes.h"
#include "BFSectorDataAsset.generated.h"

/** Static, designer-authored description of one sector on the frontline ladder. */
UCLASS(BlueprintType)
class BROKENFRONT_API UBFSectorDataAsset : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	FName SectorId = NAME_None;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	FText DisplayName;

	/**
	 * Position on the ladder, 0 = deepest Ironclad ground, higher = deeper Ashguard ground.
	 * The frontline manager only ever activates adjacent indices.
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Layout", meta = (ClampMin = "0"))
	int32 LineIndex = 0;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Layout")
	EBFTeam InitialOwner = EBFTeam::Neutral;

	/** Base seconds for a single attacker to take the sector from 0 to 100%. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Capture", meta = (ClampMin = "5.0"))
	float BaseCaptureTime = 90.f;

	/** Each extra attacker adds this fraction of the base rate, with diminishing returns. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Capture", meta = (ClampMin = "0.0"))
	float PerPlayerRateBonus = 0.35f;

	/** Cap on the stacking bonus so a zerg cannot flip a sector instantly. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Capture", meta = (ClampMin = "1.0"))
	float MaxCaptureRateMultiplier = 3.5f;

	/** How fast an uncontested sector bleeds back to its owner. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Capture", meta = (ClampMin = "0.0"))
	float DecayRateMultiplier = 0.5f;

	/** Losing this sector ends the match for its owner. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bIsHomeBase = false;

	/** Ticket bleed per second inflicted on the enemy while this sector is held. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	float TicketBleedPerSecond = 0.2f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	int32 CaptureScore = 250;
};
