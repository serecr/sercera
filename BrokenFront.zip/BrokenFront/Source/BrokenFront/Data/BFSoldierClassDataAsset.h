#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "Core/BFTypes.h"
#include "BFSoldierClassDataAsset.generated.h"

class UBFWeaponDataAsset;
class ABFEquipmentBase;
class UTexture2D;

/** Data-driven role definition. Adding a seventh class means adding one asset. */
UCLASS(BlueprintType)
class BROKENFRONT_API UBFSoldierClassDataAsset : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	EBFSoldierClass ClassType = EBFSoldierClass::Rifleman;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	FText DisplayName;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	FText Description;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Identity")
	TSoftObjectPtr<UTexture2D> Icon;

	/** Weapons this class may take in each slot. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Loadout")
	TArray<TSoftObjectPtr<UBFWeaponDataAsset>> AllowedPrimaries;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Loadout")
	TArray<TSoftObjectPtr<UBFWeaponDataAsset>> AllowedSecondaries;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Loadout")
	TArray<TSubclassOf<ABFEquipmentBase>> AllowedEquipment;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Stats", meta = (ClampMin = "10.0"))
	float MaxHealth = 100.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Stats", meta = (ClampMin = "100.0"))
	float WalkSpeed = 340.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Stats", meta = (ClampMin = "100.0"))
	float SprintSpeed = 620.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Stats", meta = (ClampMin = "0.0"))
	float MaxStamina = 100.f;

	/** Engineers get build resources; everyone else gets zero. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Stats", meta = (ClampMin = "0"))
	int32 PersonalBuildResources = 0;

	/** Only one Commander per team may deploy at a time. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bUniquePerTeam = false;

	/** Hard cap of simultaneous players of this class per team. 0 = unlimited. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules", meta = (ClampMin = "0"))
	int32 MaxPerTeam = 0;

	/** Can place buildable defences. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bCanBuild = false;

	/** Can revive downed allies. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bCanRevive = false;

	/** Can resupply allies' magazines. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bCanResupply = false;

	/** Can mark enemies on the tactical map for the squad. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bCanSpotTargets = false;

	/** Can issue sector-level objectives from the command map. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bCanIssueOrders = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Progression")
	int32 UnlockLevel = 0;
};
