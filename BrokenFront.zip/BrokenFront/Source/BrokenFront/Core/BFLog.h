#pragma once

#include "CoreMinimal.h"

BROKENFRONT_API DECLARE_LOG_CATEGORY_EXTERN(LogBrokenFront, Log, All);
BROKENFRONT_API DECLARE_LOG_CATEGORY_EXTERN(LogBFFrontline, Log, All);
BROKENFRONT_API DECLARE_LOG_CATEGORY_EXTERN(LogBFCombat, Log, All);
BROKENFRONT_API DECLARE_LOG_CATEGORY_EXTERN(LogBFWeather, Log, All);
BROKENFRONT_API DECLARE_LOG_CATEGORY_EXTERN(LogBFGame, Log, All);

#define BF_LOG(Category, Verbosity, Format, ...) UE_LOG(Category, Verbosity, TEXT("[%s] ") Format, *FString(__FUNCTION__), ##__VA_ARGS__)
