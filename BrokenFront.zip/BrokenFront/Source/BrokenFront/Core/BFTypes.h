#pragma once

#include "CoreMinimal.h"
#include "Engine/DataTable.h"
#include "BFTypes.generated.h"

/** Fictional factions. Neutral is used for unowned sectors and spectators. */
UENUM(BlueprintType)
enum class EBFTeam : uint8
{
	Neutral		UMETA(DisplayName = "Neutral"),
	Ironclad	UMETA(DisplayName = "Ironclad Coalition"),
	Ashguard	UMETA(DisplayName = "Ashguard Union")
};

UENUM(BlueprintType)
enum class EBFSectorState : uint8
{
	/** Not part of the active frontline yet - no objectives, no capture allowed. */
	Dormant		UMETA(DisplayName = "Dormant"),
	/** Active and fully held by its owner. */
	Secured		UMETA(DisplayName = "Secured"),
	/** Active, being captured by the attacking team. */
	Capturing	UMETA(DisplayName = "Capturing"),
	/** Both teams present in the capture zone - progress frozen. */
	Contested	UMETA(DisplayName = "Contested"),
	/** Owner lost it this tick; frontline is about to shift. */
	Falling		UMETA(DisplayName = "Falling")
};

UENUM(BlueprintType)
enum class EBFWeatherState : uint8
{
	Clear,
	Cloudy,
	Rain,
	HeavyRain,
	Fog,
	Storm
};

UENUM(BlueprintType)
enum class EBFDayPhase : uint8
{
	Dawn,
	Day,
	Dusk,
	Night
};

UENUM(BlueprintType)
enum class EBFSoldierClass : uint8
{
	Rifleman,
	Medic,
	Engineer,
	Support,
	Scout,
	Commander
};

UENUM(BlueprintType)
enum class EBFStance : uint8
{
	Standing,
	Crouched,
	Prone
};

UENUM(BlueprintType)
enum class EBFWeaponCategory : uint8
{
	Rifle,
	SMG,
	Pistol,
	Shotgun,
	MachineGun,
	Sniper
};

UENUM(BlueprintType)
enum class EBFFireMode : uint8
{
	SingleShot,
	Burst,
	FullAuto
};

UENUM(BlueprintType)
enum class EBFWeaponSlot : uint8
{
	Primary,
	Secondary,
	Equipment
};

UENUM(BlueprintType)
enum class EBFObjectiveType : uint8
{
	CaptureSector,
	DefendSector,
	DestroyObjective,
	ProtectSupply,
	ReconArea,
	HoldPosition
};

UENUM(BlueprintType)
enum class EBFObjectiveStatus : uint8
{
	Inactive,
	Active,
	Completed,
	Failed
};

UENUM(BlueprintType)
enum class EBFSurfaceType : uint8
{
	Default,
	Mud,
	Wood,
	Metal,
	Stone,
	Grass,
	Water
};

UENUM(BlueprintType)
enum class EBFRadioChannel : uint8
{
	Squad,
	Team,
	Local
};

UENUM(BlueprintType)
enum class EBFRadioCommand : uint8
{
	EnemySpotted	UMETA(DisplayName = "Enemy spotted"),
	NeedMedic		UMETA(DisplayName = "Need medic"),
	DefendSector	UMETA(DisplayName = "Defend sector"),
	Attack			UMETA(DisplayName = "Attack"),
	FallBack		UMETA(DisplayName = "Fall back"),
	NeedSupplies	UMETA(DisplayName = "Need supplies")
};

UENUM(BlueprintType)
enum class EBFQualityPreset : uint8
{
	Low,
	Medium,
	High,
	Epic,
	Custom
};

UENUM(BlueprintType)
enum class EBFCraterSize : uint8
{
	Small,
	Medium,
	Large
};

UENUM(BlueprintType)
enum class EBFSpawnKind : uint8
{
	/** Home base, always available while the team owns its rear sector. */
	MainBase,
	/** Spawn on a living squadmate in a safe state. */
	Squad,
	/** Unlocked by owning the parent sector. */
	CapturedSector,
	/** Emergency spawn used when everything else is disabled. */
	Fallback
};

UENUM(BlueprintType)
enum class EBFMatchPhase : uint8
{
	WaitingForPlayers,
	Warmup,
	InProgress,
	PostMatch
};

/** Simple replicated float range used by the weather blender. */
USTRUCT(BlueprintType)
struct FBFWeatherSnapshot
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly) EBFWeatherState State = EBFWeatherState::Clear;
	UPROPERTY(BlueprintReadOnly) float RainIntensity = 0.f;
	UPROPERTY(BlueprintReadOnly) float FogDensity = 0.02f;
	UPROPERTY(BlueprintReadOnly) float CloudCoverage = 0.2f;
	UPROPERTY(BlueprintReadOnly) float WindStrength = 0.15f;
	UPROPERTY(BlueprintReadOnly) FVector WindDirection = FVector(1.f, 0.f, 0.f);
	UPROPERTY(BlueprintReadOnly) float ThunderChance = 0.f;
	/** 0..24 game hours. */
	UPROPERTY(BlueprintReadOnly) float TimeOfDay = 9.f;
	UPROPERTY(BlueprintReadOnly) EBFDayPhase DayPhase = EBFDayPhase::Day;
};

/** Per-weather tuning row, editable as a DataTable. */
USTRUCT(BlueprintType)
struct FBFWeatherPreset : public FTableRowBase
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) EBFWeatherState State = EBFWeatherState::Clear;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0", ClampMax = "1.0")) float RainIntensity = 0.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0", ClampMax = "1.0")) float FogDensity = 0.02f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0", ClampMax = "1.0")) float CloudCoverage = 0.2f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0", ClampMax = "1.0")) float WindStrength = 0.15f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.0", ClampMax = "1.0")) float ThunderChance = 0.f;
	/** Seconds this state persists before the manager rolls a transition. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "10.0")) float MinDuration = 180.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "10.0")) float MaxDuration = 420.f;
	/** Weather states reachable from this one. Keeps transitions believable. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) TArray<EBFWeatherState> AllowedTransitions;
	/** Extra mud accumulation per second while outdoors under this weather. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite) float MudRate = 0.f;
	/** Multiplier applied to AI/foliage/audio occlusion distance. */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (ClampMin = "0.1")) float VisibilityMultiplier = 1.f;
};

/** Cosmetic + stat payload for the profile screen. */
USTRUCT(BlueprintType)
struct FBFProfileStats
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite) int32 MatchesPlayed = 0;
	UPROPERTY(BlueprintReadWrite) int32 MatchesWon = 0;
	UPROPERTY(BlueprintReadWrite) int32 Kills = 0;
	UPROPERTY(BlueprintReadWrite) int32 Deaths = 0;
	UPROPERTY(BlueprintReadWrite) int32 Assists = 0;
	UPROPERTY(BlueprintReadWrite) int32 SectorsCaptured = 0;
	UPROPERTY(BlueprintReadWrite) int32 SectorsDefended = 0;
	UPROPERTY(BlueprintReadWrite) int32 Revives = 0;
	UPROPERTY(BlueprintReadWrite) int32 StructuresBuilt = 0;
	UPROPERTY(BlueprintReadWrite) float TimePlayedSeconds = 0.f;
};

/** One row of the server browser. */
USTRUCT(BlueprintType)
struct FBFServerEntry
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly) FString ServerName;
	UPROPERTY(BlueprintReadOnly) FString MapName;
	UPROPERTY(BlueprintReadOnly) FString GameMode;
	UPROPERTY(BlueprintReadOnly) int32 PlayerCount = 0;
	UPROPERTY(BlueprintReadOnly) int32 MaxPlayers = 64;
	UPROPERTY(BlueprintReadOnly) int32 PingMs = 0;
	/** Human readable frontline state, e.g. "Ironclad +2 sectors". */
	UPROPERTY(BlueprintReadOnly) FString FrontlineState;
	UPROPERTY(BlueprintReadOnly) FString ConnectString;
};

/** Minimap / HUD friendly snapshot of a sector, replicated via GameState. */
USTRUCT(BlueprintType)
struct FBFSectorSnapshot
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly) FName SectorId = NAME_None;
	UPROPERTY(BlueprintReadOnly) FText DisplayName;
	UPROPERTY(BlueprintReadOnly) EBFTeam Owner = EBFTeam::Neutral;
	UPROPERTY(BlueprintReadOnly) EBFSectorState State = EBFSectorState::Dormant;
	/** -1..1 : negative = Ironclad progress, positive = Ashguard progress. */
	UPROPERTY(BlueprintReadOnly) float CaptureProgress = 0.f;
	UPROPERTY(BlueprintReadOnly) FVector WorldLocation = FVector::ZeroVector;
	UPROPERTY(BlueprintReadOnly) int32 LineIndex = 0;
	UPROPERTY(BlueprintReadOnly) bool bIsFrontline = false;
};

namespace BFTeam
{
	/** The opposing faction. Neutral maps to Neutral. */
	FORCEINLINE EBFTeam Opposite(EBFTeam Team)
	{
		switch (Team)
		{
		case EBFTeam::Ironclad: return EBFTeam::Ashguard;
		case EBFTeam::Ashguard: return EBFTeam::Ironclad;
		default: return EBFTeam::Neutral;
		}
	}

	/** +1 for Ashguard, -1 for Ironclad. Used for signed capture progress. */
	FORCEINLINE float Sign(EBFTeam Team)
	{
		switch (Team)
		{
		case EBFTeam::Ashguard: return 1.f;
		case EBFTeam::Ironclad: return -1.f;
		default: return 0.f;
		}
	}

	FORCEINLINE EBFTeam FromSign(float Value)
	{
		if (Value > KINDA_SMALL_NUMBER) { return EBFTeam::Ashguard; }
		if (Value < -KINDA_SMALL_NUMBER) { return EBFTeam::Ironclad; }
		return EBFTeam::Neutral;
	}
}

/** Collision / trace channel aliases configured in DefaultEngine.ini. */
#define BF_TRACE_WEAPON		ECC_GameTraceChannel1
#define BF_TRACE_INTERACT	ECC_GameTraceChannel2
#define BF_TRACE_COVER		ECC_GameTraceChannel3
