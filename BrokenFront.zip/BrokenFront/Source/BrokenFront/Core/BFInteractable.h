#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "BFInteractable.generated.h"

class ABFCharacter;

UINTERFACE(MinimalAPI, BlueprintType)
class UBFInteractable : public UInterface
{
	GENERATED_BODY()
};

/**
 * Anything a soldier can press Use on: ladders, hatches, supply crates,
 * mounted weapons, vehicle seats, buildable defences under repair.
 */
class BROKENFRONT_API IBFInteractable
{
	GENERATED_BODY()

public:
	/** Server-side. Perform the interaction. */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Interaction")
	void Interact(ABFCharacter* Interactor);
	virtual void Interact_Implementation(ABFCharacter* /*Interactor*/) {}

	/** Client-side. Prompt shown on the HUD, e.g. "Hold E - Repair". */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Interaction")
	FText GetInteractionPrompt(ABFCharacter* Interactor) const;
	virtual FText GetInteractionPrompt_Implementation(ABFCharacter* /*Interactor*/) const { return FText::GetEmpty(); }

	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Interaction")
	bool CanInteract(ABFCharacter* Interactor) const;
	virtual bool CanInteract_Implementation(ABFCharacter* /*Interactor*/) const { return true; }
};
