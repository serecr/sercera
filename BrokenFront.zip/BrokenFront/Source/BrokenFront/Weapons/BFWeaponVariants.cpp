#include "Weapons/BFWeaponVariants.h"

ABFWeapon_Rifle::ABFWeapon_Rifle()
{
	CategoryDefault = EBFWeaponCategory::Rifle;
}

ABFWeapon_SMG::ABFWeapon_SMG()
{
	CategoryDefault = EBFWeaponCategory::SMG;
}

ABFWeapon_Pistol::ABFWeapon_Pistol()
{
	CategoryDefault = EBFWeaponCategory::Pistol;
}

ABFWeapon_Shotgun::ABFWeapon_Shotgun()
{
	CategoryDefault = EBFWeaponCategory::Shotgun;
}

ABFWeapon_MachineGun::ABFWeapon_MachineGun()
{
	CategoryDefault = EBFWeaponCategory::MachineGun;
}

void ABFWeapon_MachineGun::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	// Detect shots by watching the clip drop - keeps this subclass free of fire-path overrides.
	if (LastSeenClipAmmo < 0)
	{
		LastSeenClipAmmo = GetClipAmmo();
	}

	const int32 Current = GetClipAmmo();
	if (Current < LastSeenClipAmmo)
	{
		Heat = FMath::Min(1.f, Heat + HeatPerShot * (LastSeenClipAmmo - Current));
	}
	LastSeenClipAmmo = Current;

	if (!IsFiring())
	{
		Heat = FMath::Max(0.f, Heat - CoolPerSecond * DeltaSeconds);
	}

	if (!bOverheated && Heat >= 1.f)
	{
		bOverheated = true;
		StopFire();
	}
	else if (bOverheated && Heat <= OverheatRecoverThreshold)
	{
		bOverheated = false;
	}
}

ABFWeapon_Sniper::ABFWeapon_Sniper()
{
	CategoryDefault = EBFWeaponCategory::Sniper;
}
