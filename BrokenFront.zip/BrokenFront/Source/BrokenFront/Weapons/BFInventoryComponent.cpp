#include "Weapons/BFInventoryComponent.h"

#include "Characters/BFCharacter.h"
#include "Components/SkeletalMeshComponent.h"
#include "Core/BFLog.h"
#include "Data/BFWeaponDataAsset.h"
#include "Equipment/BFEquipmentBase.h"
#include "Net/UnrealNetwork.h"
#include "TimerManager.h"
#include "Weapons/BFWeaponBase.h"

UBFInventoryComponent::UBFInventoryComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	SetIsReplicatedByDefault(true);
}

void UBFInventoryComponent::BeginPlay()
{
	Super::BeginPlay();
	OwnerCharacter = Cast<ABFCharacter>(GetOwner());
}

void UBFInventoryComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UBFInventoryComponent, CurrentWeapon);
	DOREPLIFETIME(UBFInventoryComponent, PrimaryWeapon);
	DOREPLIFETIME(UBFInventoryComponent, SecondaryWeapon);
	DOREPLIFETIME(UBFInventoryComponent, Equipment);
	DOREPLIFETIME(UBFInventoryComponent, CurrentSlot);
}

void UBFInventoryComponent::EndPlay(const EEndPlayReason::Type EndPlayReason)
{
	GetWorld()->GetTimerManager().ClearTimer(SwitchTimer);
	Super::EndPlay(EndPlayReason);
}

TSubclassOf<ABFWeaponBase> UBFInventoryComponent::ResolveWeaponClass(EBFWeaponCategory Category) const
{
	for (const FBFWeaponClassMapping& Mapping : WeaponClassMappings)
	{
		if (Mapping.Category == Category && Mapping.WeaponClass)
		{
			return Mapping.WeaponClass;
		}
	}
	return nullptr;
}

ABFWeaponBase* UBFInventoryComponent::SpawnWeaponFor(UBFWeaponDataAsset* Data) const
{
	if (!Data || !OwnerCharacter)
	{
		return nullptr;
	}

	const TSubclassOf<ABFWeaponBase> WeaponClass = ResolveWeaponClass(Data->Category);
	if (!WeaponClass)
	{
		BF_LOG(LogBFCombat, Warning, TEXT("No weapon actor class mapped for category %d (%s)"),
			static_cast<int32>(Data->Category), *Data->WeaponId.ToString());
		return nullptr;
	}

	FActorSpawnParameters Params;
	Params.Owner = OwnerCharacter;
	Params.Instigator = OwnerCharacter;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ABFWeaponBase* Weapon = GetWorld()->SpawnActor<ABFWeaponBase>(WeaponClass, OwnerCharacter->GetActorTransform(), Params);
	if (Weapon)
	{
		Weapon->InitializeWeapon(OwnerCharacter, Data);
	}
	return Weapon;
}

void UBFInventoryComponent::ServerApplyLoadout(const FBFLoadout& Loadout)
{
	if (!GetOwner() || !GetOwner()->HasAuthority() || !OwnerCharacter)
	{
		return;
	}

	// Wipe anything left over from a previous life.
	ServerDropOrDestroyWeapons();

	PrimaryWeapon = SpawnWeaponFor(Loadout.Primary);
	SecondaryWeapon = SpawnWeaponFor(Loadout.Secondary);

	if (Loadout.Equipment)
	{
		FActorSpawnParameters Params;
		Params.Owner = OwnerCharacter;
		Params.Instigator = OwnerCharacter;
		Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

		Equipment = GetWorld()->SpawnActor<ABFEquipmentBase>(Loadout.Equipment, OwnerCharacter->GetActorTransform(), Params);
		if (Equipment)
		{
			Equipment->InitializeEquipment(OwnerCharacter);
			Equipment->SetActorHiddenInGame(true);
		}
	}

	if (PrimaryWeapon)
	{
		SetCurrentWeaponInternal(PrimaryWeapon, EBFWeaponSlot::Primary);
	}
	else if (SecondaryWeapon)
	{
		SetCurrentWeaponInternal(SecondaryWeapon, EBFWeaponSlot::Secondary);
	}
}

void UBFInventoryComponent::ServerDropOrDestroyWeapons()
{
	if (!GetOwner() || !GetOwner()->HasAuthority())
	{
		return;
	}

	auto Cleanup = [](AActor* Actor)
	{
		if (Actor && !Actor->IsPendingKillPending())
		{
			Actor->Destroy();
		}
	};

	Cleanup(PrimaryWeapon);
	Cleanup(SecondaryWeapon);
	Cleanup(Equipment);

	PrimaryWeapon = nullptr;
	SecondaryWeapon = nullptr;
	Equipment = nullptr;
	CurrentWeapon = nullptr;
}

ABFWeaponBase* UBFInventoryComponent::GetWeaponInSlot(EBFWeaponSlot Slot) const
{
	switch (Slot)
	{
	case EBFWeaponSlot::Primary:   return PrimaryWeapon;
	case EBFWeaponSlot::Secondary: return SecondaryWeapon;
	default:                       return nullptr;
	}
}

void UBFInventoryComponent::AttachWeaponToOwner(ABFWeaponBase* Weapon)
{
	if (!Weapon || !OwnerCharacter)
	{
		return;
	}

	const FAttachmentTransformRules Rules(EAttachmentRule::SnapToTarget, true);

	// The owning client sees the arms rig; everyone else sees the body rig.
	USkeletalMeshComponent* TargetMesh = OwnerCharacter->IsLocallyControlled()
		? OwnerCharacter->GetArmsMesh()
		: OwnerCharacter->GetMesh();

	const FName Socket = OwnerCharacter->IsLocallyControlled() ? ArmsWeaponSocket : BodyWeaponSocket;

	Weapon->AttachToComponent(TargetMesh, Rules, Socket);
	Weapon->GetWeaponMesh()->SetOnlyOwnerSee(OwnerCharacter->IsLocallyControlled());
	Weapon->GetWeaponMesh()->SetOwnerNoSee(false);
}

void UBFInventoryComponent::SetCurrentWeaponInternal(ABFWeaponBase* NewWeapon, EBFWeaponSlot Slot)
{
	if (CurrentWeapon && CurrentWeapon != NewWeapon)
	{
		CurrentWeapon->SetWeaponActive(false);
	}

	CurrentWeapon = NewWeapon;
	CurrentSlot = Slot;

	if (CurrentWeapon)
	{
		AttachWeaponToOwner(CurrentWeapon);
		CurrentWeapon->SetWeaponActive(true);
		CurrentWeapon->SetAiming(bPendingAim);
		CurrentWeapon->SetBraced(bPendingBraced);
	}

	OnWeaponChanged.Broadcast(CurrentWeapon);
}

void UBFInventoryComponent::OnRep_CurrentWeapon()
{
	if (CurrentWeapon)
	{
		AttachWeaponToOwner(CurrentWeapon);
		CurrentWeapon->SetWeaponActive(true);
	}

	// Hide the slots we are not holding.
	for (ABFWeaponBase* Weapon : { PrimaryWeapon.Get(), SecondaryWeapon.Get() })
	{
		if (Weapon && Weapon != CurrentWeapon)
		{
			Weapon->SetWeaponActive(false);
		}
	}

	OnWeaponChanged.Broadcast(CurrentWeapon);
}

void UBFInventoryComponent::SelectSlot(EBFWeaponSlot Slot)
{
	if (bSwitching || Slot == CurrentSlot)
	{
		return;
	}

	if (Slot == EBFWeaponSlot::Equipment)
	{
		if (!Equipment)
		{
			return;
		}
	}
	else if (!GetWeaponInSlot(Slot))
	{
		return;
	}

	StopFire();
	bSwitching = true;

	float EquipTime = 0.5f;
	if (ABFWeaponBase* Target = GetWeaponInSlot(Slot))
	{
		if (const UBFWeaponDataAsset* Data = Target->GetWeaponData())
		{
			EquipTime = Data->EquipTime;
		}
	}

	CurrentSlot = Slot;
	GetWorld()->GetTimerManager().SetTimer(SwitchTimer, this, &UBFInventoryComponent::FinishSwitch, EquipTime, false);

	if (!GetOwner()->HasAuthority())
	{
		ServerSelectSlot(Slot);
	}
}

void UBFInventoryComponent::ServerSelectSlot_Implementation(EBFWeaponSlot Slot)
{
	if (Slot == EBFWeaponSlot::Equipment)
	{
		if (!Equipment) { return; }
		CurrentSlot = Slot;
		if (CurrentWeapon) { CurrentWeapon->SetWeaponActive(false); }
		Equipment->SetActorHiddenInGame(false);
		Equipment->SetEquipmentActive(true);
		return;
	}

	if (ABFWeaponBase* Target = GetWeaponInSlot(Slot))
	{
		if (Equipment)
		{
			Equipment->SetEquipmentActive(false);
			Equipment->SetActorHiddenInGame(true);
		}
		SetCurrentWeaponInternal(Target, Slot);
	}
}

void UBFInventoryComponent::FinishSwitch()
{
	bSwitching = false;

	if (CurrentSlot == EBFWeaponSlot::Equipment)
	{
		if (CurrentWeapon) { CurrentWeapon->SetWeaponActive(false); }
		if (Equipment)
		{
			Equipment->SetActorHiddenInGame(false);
			Equipment->SetEquipmentActive(true);
		}
		return;
	}

	if (Equipment)
	{
		Equipment->SetEquipmentActive(false);
		Equipment->SetActorHiddenInGame(true);
	}

	if (ABFWeaponBase* Target = GetWeaponInSlot(CurrentSlot))
	{
		SetCurrentWeaponInternal(Target, CurrentSlot);
	}
}

void UBFInventoryComponent::CycleWeapon(int32 Direction)
{
	// Primary -> Secondary -> Equipment -> Primary ...
	TArray<EBFWeaponSlot> Available;
	if (PrimaryWeapon)   { Available.Add(EBFWeaponSlot::Primary); }
	if (SecondaryWeapon) { Available.Add(EBFWeaponSlot::Secondary); }
	if (Equipment)       { Available.Add(EBFWeaponSlot::Equipment); }

	if (Available.Num() <= 1)
	{
		return;
	}

	int32 Index = Available.IndexOfByKey(CurrentSlot);
	if (Index == INDEX_NONE) { Index = 0; }

	const int32 Next = (Index + Direction + Available.Num()) % Available.Num();
	SelectSlot(Available[Next]);
}

bool UBFInventoryComponent::IsFiring() const
{
	return CurrentWeapon && CurrentWeapon->IsFiring();
}

float UBFInventoryComponent::GetCurrentAimFOV(float DefaultFOV) const
{
	return CurrentWeapon ? CurrentWeapon->GetAimFOV(DefaultFOV) : DefaultFOV;
}

float UBFInventoryComponent::GetCurrentADSTime() const
{
	return CurrentWeapon ? CurrentWeapon->GetADSTime() : 0.25f;
}

void UBFInventoryComponent::StartFire()
{
	if (bSwitching) { return; }

	if (CurrentSlot == EBFWeaponSlot::Equipment)
	{
		if (Equipment) { Equipment->PrimaryUse(); }
		return;
	}

	if (CurrentWeapon) { CurrentWeapon->StartFire(); }
}

void UBFInventoryComponent::StopFire()
{
	if (CurrentWeapon) { CurrentWeapon->StopFire(); }
	if (Equipment && CurrentSlot == EBFWeaponSlot::Equipment) { Equipment->StopUse(); }
}

void UBFInventoryComponent::Reload()
{
	if (!bSwitching && CurrentWeapon && CurrentSlot != EBFWeaponSlot::Equipment)
	{
		CurrentWeapon->Reload();
	}
}

void UBFInventoryComponent::CycleFireMode()
{
	if (CurrentWeapon) { CurrentWeapon->CycleFireMode(); }
}

void UBFInventoryComponent::InspectWeapon()
{
	if (CurrentWeapon) { CurrentWeapon->Inspect(); }
}

void UBFInventoryComponent::UseEquipment()
{
	if (CurrentSlot == EBFWeaponSlot::Equipment)
	{
		if (Equipment) { Equipment->PrimaryUse(); }
	}
	else
	{
		SelectSlot(EBFWeaponSlot::Equipment);
	}
}

void UBFInventoryComponent::SetAiming(bool bNewAiming)
{
	bPendingAim = bNewAiming;
	if (CurrentWeapon) { CurrentWeapon->SetAiming(bNewAiming); }
}

void UBFInventoryComponent::SetBraced(bool bNewBraced)
{
	bPendingBraced = bNewBraced;
	if (CurrentWeapon) { CurrentWeapon->SetBraced(bNewBraced); }
}

bool UBFInventoryComponent::ResupplyAmmo(int32 Magazines)
{
	if (!GetOwner() || !GetOwner()->HasAuthority())
	{
		return false;
	}

	int32 Added = 0;
	if (PrimaryWeapon)   { Added += PrimaryWeapon->AddReserveAmmo(Magazines); }
	if (SecondaryWeapon) { Added += SecondaryWeapon->AddReserveAmmo(FMath::Max(1, Magazines / 2)); }
	return Added > 0;
}
