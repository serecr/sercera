#pragma once

#include "CoreMinimal.h"
#include "Weapons/BFWeaponBase.h"
#include "BFWeaponVariants.generated.h"

/**
 * The six weapon families. They exist so designers get obvious Blueprint parents and
 * so per-family behaviour has a home - all *numbers* still come from the data asset.
 */

UCLASS()
class BROKENFRONT_API ABFWeapon_Rifle : public ABFWeaponBase
{
	GENERATED_BODY()
public:
	ABFWeapon_Rifle();
};

UCLASS()
class BROKENFRONT_API ABFWeapon_SMG : public ABFWeaponBase
{
	GENERATED_BODY()
public:
	ABFWeapon_SMG();
};

UCLASS()
class BROKENFRONT_API ABFWeapon_Pistol : public ABFWeaponBase
{
	GENERATED_BODY()
public:
	ABFWeapon_Pistol();
};

UCLASS()
class BROKENFRONT_API ABFWeapon_Shotgun : public ABFWeaponBase
{
	GENERATED_BODY()
public:
	ABFWeapon_Shotgun();
};

/**
 * Bipod weapon: gets an extra accuracy bonus while braced and heats up during
 * sustained fire, which forces short bursts from a fixed position.
 */
UCLASS()
class BROKENFRONT_API ABFWeapon_MachineGun : public ABFWeaponBase
{
	GENERATED_BODY()
public:
	ABFWeapon_MachineGun();

	virtual void Tick(float DeltaSeconds) override;

	UFUNCTION(BlueprintPure, Category = "Weapon") float GetHeat() const { return Heat; }
	UFUNCTION(BlueprintPure, Category = "Weapon") bool IsOverheated() const { return bOverheated; }

protected:
	UPROPERTY(EditDefaultsOnly, Category = "Overheat") float HeatPerShot = 0.035f;
	UPROPERTY(EditDefaultsOnly, Category = "Overheat") float CoolPerSecond = 0.18f;
	UPROPERTY(EditDefaultsOnly, Category = "Overheat") float OverheatRecoverThreshold = 0.35f;

private:
	float Heat = 0.f;
	bool bOverheated = false;
	int32 LastSeenClipAmmo = -1;
};

/** Bolt / semi rifle with a scope. Holds breath support for a steadier sight picture. */
UCLASS()
class BROKENFRONT_API ABFWeapon_Sniper : public ABFWeaponBase
{
	GENERATED_BODY()
public:
	ABFWeapon_Sniper();
};
