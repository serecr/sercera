#include "Weapons/BFProjectile.h"

#include "Characters/BFCharacter.h"
#include "Components/SphereComponent.h"
#include "Data/BFWeaponDataAsset.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "Net/UnrealNetwork.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "Systems/BFAudioManager.h"
#include "Systems/BFDamageManager.h"

ABFProjectile::ABFProjectile()
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = true;
	SetReplicateMovement(true);
	// Small, fast, short-lived: replicate the spawn but let clients extrapolate.
	NetUpdateFrequency = 20.f;
	InitialLifeSpan = 6.f;

	CollisionSphere = CreateDefaultSubobject<USphereComponent>(TEXT("CollisionSphere"));
	CollisionSphere->InitSphereRadius(2.5f);
	CollisionSphere->SetCollisionObjectType(ECC_WorldDynamic);
	CollisionSphere->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	CollisionSphere->SetCollisionResponseToAllChannels(ECR_Ignore);
	CollisionSphere->SetCollisionResponseToChannel(ECC_WorldStatic, ECR_Block);
	CollisionSphere->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Block);
	CollisionSphere->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
	CollisionSphere->bReturnMaterialOnMove = true;
	SetRootComponent(CollisionSphere);

	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("ProjectileMovement"));
	ProjectileMovement->bRotationFollowsVelocity = true;
	ProjectileMovement->bShouldBounce = false;
	ProjectileMovement->ProjectileGravityScale = GravityScale;
	ProjectileMovement->InitialSpeed = 70000.f;
	ProjectileMovement->MaxSpeed = 120000.f;
}

void ABFProjectile::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}

void ABFProjectile::BeginPlay()
{
	Super::BeginPlay();

	SpawnLocation = GetActorLocation();

	if (HasAuthority())
	{
		CollisionSphere->OnComponentHit.AddDynamic(this, &ABFProjectile::OnProjectileHit);
	}
	else
	{
		// Clients only need the visual; no collision work.
		CollisionSphere->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	}
}

void ABFProjectile::InitializeBallistics(UBFWeaponDataAsset* Data, const FVector& Direction, ABFCharacter* Shooter)
{
	SourceWeaponData = Data;
	ShooterCharacter = Shooter;

	if (Shooter)
	{
		SetInstigator(Shooter);
		CollisionSphere->IgnoreActorWhenMoving(Shooter, true);
	}

	if (Data && ProjectileMovement)
	{
		const float Speed = FMath::Max(Data->BulletVelocity, 1000.f);
		ProjectileMovement->InitialSpeed = Speed;
		ProjectileMovement->MaxSpeed = Speed * 1.05f;
		ProjectileMovement->Velocity = Direction.GetSafeNormal() * Speed;
		ProjectileMovement->ProjectileGravityScale = GravityScale;
	}
}

void ABFProjectile::OnProjectileHit(UPrimitiveComponent* /*HitComp*/, AActor* OtherActor, UPrimitiveComponent* /*OtherComp*/,
	FVector /*NormalImpulse*/, const FHitResult& Hit)
{
	if (!HasAuthority())
	{
		return;
	}

	if (SourceWeaponData)
	{
		const float Distance = FVector::Dist(SpawnLocation, Hit.ImpactPoint);
		const float Damage = SourceWeaponData->GetDamageAtDistance(Distance);
		const FVector ShotDirection = GetVelocity().GetSafeNormal();

		UBFDamageManager::ApplyWeaponDamage(OtherActor, Damage, Hit, ShotDirection,
			ShooterCharacter, this, SourceWeaponData);
	}

	EBFSurfaceType Surface = EBFSurfaceType::Default;
	if (Hit.PhysMaterial.IsValid())
	{
		const int32 Index = static_cast<int32>(Hit.PhysMaterial->SurfaceType);
		if (Index >= 1 && Index <= 6)
		{
			Surface = static_cast<EBFSurfaceType>(Index);
		}
	}
	ABFAudioManager::PlaySurfaceImpact(GetWorld(), Surface, Hit.ImpactPoint, Hit.ImpactNormal);

	Destroy();
}
