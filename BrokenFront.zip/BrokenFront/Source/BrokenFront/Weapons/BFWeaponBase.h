#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFWeaponBase.generated.h"

class ABFCharacter;
class UBFWeaponDataAsset;
class USkeletalMeshComponent;
class UAudioComponent;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBFAmmoChanged, int32, ClipAmmo, int32, ReserveAmmo);

/**
 * Base for every firearm. Contains zero hardcoded stats - everything is read from
 * the data asset in WeaponData, so Rifle/SMG/Sniper subclasses exist only to hold
 * category defaults and to give designers clear Blueprint parents.
 *
 * Networking: the owning client predicts visuals and drives its own cooldown, but
 * every trace, damage application and ammo decrement happens on the server.
 */
UCLASS(Abstract)
class BROKENFRONT_API ABFWeaponBase : public AActor
{
	GENERATED_BODY()

public:
	ABFWeaponBase();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Weapon") FBFAmmoChanged OnAmmoChanged;

	// ---------- Setup ----------
	/** Server: bind this weapon to its owner and data. Called by the inventory. */
	void InitializeWeapon(ABFCharacter* NewOwner, UBFWeaponDataAsset* Data);

	UFUNCTION(BlueprintPure, Category = "Weapon") UBFWeaponDataAsset* GetWeaponData() const { return WeaponData; }
	UFUNCTION(BlueprintPure, Category = "Weapon") USkeletalMeshComponent* GetWeaponMesh() const { return WeaponMesh; }
	UFUNCTION(BlueprintPure, Category = "Weapon") ABFCharacter* GetOwningCharacter() const { return OwningCharacter; }

	// ---------- State ----------
	UFUNCTION(BlueprintPure, Category = "Weapon") int32 GetClipAmmo() const { return ClipAmmo; }
	UFUNCTION(BlueprintPure, Category = "Weapon") int32 GetReserveAmmo() const { return ReserveAmmo; }
	UFUNCTION(BlueprintPure, Category = "Weapon") bool IsReloading() const { return bReloading; }
	UFUNCTION(BlueprintPure, Category = "Weapon") bool IsFiring() const { return bTriggerHeld; }
	UFUNCTION(BlueprintPure, Category = "Weapon") EBFFireMode GetFireMode() const { return CurrentFireMode; }
	UFUNCTION(BlueprintPure, Category = "Weapon") float GetCurrentSpread() const;
	UFUNCTION(BlueprintPure, Category = "Weapon") float GetWeightSpeedScale() const;
	UFUNCTION(BlueprintPure, Category = "Weapon") float GetAimFOV(float DefaultFOV) const;
	UFUNCTION(BlueprintPure, Category = "Weapon") float GetADSTime() const;
	UFUNCTION(BlueprintPure, Category = "Weapon") FText GetDisplayName() const;
	UFUNCTION(BlueprintPure, Category = "Weapon") bool CanFire() const;

	// ---------- Commands (called on the owning client by the inventory) ----------
	void StartFire();
	void StopFire();
	void Reload();
	void CycleFireMode();
	void Inspect();
	void SetAiming(bool bNewAiming) { bAiming = bNewAiming; }
	void SetBraced(bool bNewBraced) { bBraced = bNewBraced; }

	/** Server: refill reserve magazines, used by Support resupply. Returns ammo actually added. */
	int32 AddReserveAmmo(int32 Magazines);

	/** Server: hide/show + stop timers when swapped away from. */
	void SetWeaponActive(bool bActive);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USkeletalMeshComponent> WeaponMesh;

	/** Category default; the data asset always wins if it disagrees. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
	EBFWeaponCategory CategoryDefault = EBFWeaponCategory::Rifle;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Weapon")
	FName MuzzleSocketName = TEXT("Muzzle");

	UPROPERTY(ReplicatedUsing = OnRep_WeaponData, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<UBFWeaponDataAsset> WeaponData;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Weapon")
	TObjectPtr<ABFCharacter> OwningCharacter;

	UPROPERTY(ReplicatedUsing = OnRep_Ammo, BlueprintReadOnly, Category = "Weapon")
	int32 ClipAmmo = 0;

	UPROPERTY(ReplicatedUsing = OnRep_Ammo, BlueprintReadOnly, Category = "Weapon")
	int32 ReserveAmmo = 0;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Weapon")
	bool bReloading = false;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Weapon")
	EBFFireMode CurrentFireMode = EBFFireMode::FullAuto;

	UFUNCTION() void OnRep_Ammo();
	UFUNCTION() void OnRep_WeaponData();

	// ---------- Networking ----------
	/** Client -> server. Aim transform is sent so the server traces from what the shooter saw. */
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerFire(FVector_NetQuantize AimLocation, FVector_NetQuantizeNormal AimDirection, float ClientSpread, int32 ShotSeed);

	UFUNCTION(Server, Reliable) void ServerStartReload();
	UFUNCTION(Server, Reliable) void ServerStopFire();
	UFUNCTION(Server, Reliable) void ServerSetFireMode(EBFFireMode NewMode);

	/** Cosmetics for everyone except the predicting shooter. */
	UFUNCTION(NetMulticast, Unreliable) void MulticastFireEffects(FVector_NetQuantize TracerEnd);
	UFUNCTION(NetMulticast, Unreliable) void MulticastImpactEffects(FVector_NetQuantize Location, FVector_NetQuantizeNormal Normal, uint8 SurfaceType);

	// ---------- Internals ----------
	void LocalFire();
	void FinishReload();
	void ResetBurst();

	/** Performs the actual damage resolution. Server only. */
	void ServerResolveShot(const FVector& Origin, const FVector& Direction, float Spread, int32 Seed);

	/** Single pellet / round trace with light-cover penetration. */
	void TraceAndDamage(const FVector& Origin, const FVector& Direction, FRandomStream& Stream, float Spread);

	FVector ApplySpreadToDirection(const FVector& Direction, float SpreadDegrees, FRandomStream& Stream) const;
	void GetMuzzleTransform(FVector& OutLocation, FRotator& OutRotation) const;
	void PlayFireCosmetics(const FVector& TracerEnd);
	void SpawnImpactCosmetics(const FVector& Location, const FVector& Normal, EBFSurfaceType Surface);
	float ComputeSpreadScale() const;

private:
	FTimerHandle FireTimer;
	FTimerHandle ReloadTimer;

	bool bTriggerHeld = false;
	bool bAiming = false;
	bool bBraced = false;
	bool bActiveWeapon = true;

	int32 BurstShotsFired = 0;
	float AccumulatedSpread = 0.f;
	float CurrentRecoilMultiplier = 1.f;
	float LastFireTime = -100.f;

	/** Shared seed so client prediction and server resolution use the same pellet pattern. */
	int32 NextShotSeed = 0;
};
