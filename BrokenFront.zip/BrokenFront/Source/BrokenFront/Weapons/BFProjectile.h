#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFProjectile.generated.h"

class UProjectileMovementComponent;
class USphereComponent;
class UBFWeaponDataAsset;
class ABFCharacter;
class UNiagaraSystem;

/**
 * Server-only simulated round. Used by weapons whose data asset sets bUseProjectiles
 * (snipers, high-velocity rifles) so long shots respect travel time and drop.
 * Clients never spawn these; they see the tracer VFX from the weapon multicast.
 */
UCLASS()
class BROKENFRONT_API ABFProjectile : public AActor
{
	GENERATED_BODY()

public:
	ABFProjectile();

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	/** Server: configure velocity, gravity scale and damage source from the weapon data. */
	void InitializeBallistics(UBFWeaponDataAsset* Data, const FVector& Direction, ABFCharacter* Shooter);

protected:
	virtual void BeginPlay() override;

	UFUNCTION()
	void OnProjectileHit(UPrimitiveComponent* HitComp, AActor* OtherActor, UPrimitiveComponent* OtherComp,
		FVector NormalImpulse, const FHitResult& Hit);

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> CollisionSphere;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UProjectileMovementComponent> ProjectileMovement;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TSoftObjectPtr<UNiagaraSystem> TracerEffect;

	/** How much drop the round takes. 0.12 reads well without feeling like a mortar. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float GravityScale = 0.12f;

private:
	UPROPERTY() TObjectPtr<UBFWeaponDataAsset> SourceWeaponData;
	UPROPERTY() TObjectPtr<ABFCharacter> ShooterCharacter;

	FVector SpawnLocation = FVector::ZeroVector;
};
