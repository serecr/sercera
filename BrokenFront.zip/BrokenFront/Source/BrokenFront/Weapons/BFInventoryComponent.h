#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Core/BFTypes.h"
#include "Data/BFLoadout.h"
#include "BFInventoryComponent.generated.h"

class ABFWeaponBase;
class ABFEquipmentBase;
class ABFCharacter;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFWeaponChanged, ABFWeaponBase*, NewWeapon);

/**
 * Holds the soldier's three slots and owns swap timing. All spawning happens on
 * the server; the weapon actors replicate down and attach to the right mesh
 * depending on whether the viewer is the owner (arms) or a spectator (body).
 */
UCLASS(ClassGroup = (BrokenFront), meta = (BlueprintSpawnableComponent))
class BROKENFRONT_API UBFInventoryComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBFInventoryComponent();

	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void EndPlay(const EEndPlayReason::Type EndPlayReason) override;

	UPROPERTY(BlueprintAssignable, Category = "Inventory") FBFWeaponChanged OnWeaponChanged;

	UFUNCTION(BlueprintPure, Category = "Inventory") ABFWeaponBase* GetCurrentWeapon() const { return CurrentWeapon; }
	UFUNCTION(BlueprintPure, Category = "Inventory") ABFWeaponBase* GetWeaponInSlot(EBFWeaponSlot Slot) const;
	UFUNCTION(BlueprintPure, Category = "Inventory") ABFEquipmentBase* GetEquipment() const { return Equipment; }
	UFUNCTION(BlueprintPure, Category = "Inventory") EBFWeaponSlot GetCurrentSlot() const { return CurrentSlot; }
	UFUNCTION(BlueprintPure, Category = "Inventory") bool IsSwitching() const { return bSwitching; }
	UFUNCTION(BlueprintPure, Category = "Inventory") bool IsFiring() const;
	UFUNCTION(BlueprintPure, Category = "Inventory") float GetCurrentAimFOV(float DefaultFOV) const;
	UFUNCTION(BlueprintPure, Category = "Inventory") float GetCurrentADSTime() const;

	/** Server: spawn everything described by the loadout and equip the primary. */
	void ServerApplyLoadout(const FBFLoadout& Loadout);

	/** Server: called on death. */
	void ServerDropOrDestroyWeapons();

	// Forwarded input, safe to call on the owning client.
	void StartFire();
	void StopFire();
	void Reload();
	void CycleFireMode();
	void InspectWeapon();
	void UseEquipment();
	void SelectSlot(EBFWeaponSlot Slot);
	void CycleWeapon(int32 Direction);
	void SetAiming(bool bNewAiming);
	void SetBraced(bool bNewBraced);

	/** Server: Support class resupply. Returns true if anything was added. */
	bool ResupplyAmmo(int32 Magazines);

protected:
	/** Which actor class to spawn for each weapon category. Set on the character Blueprint. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<FBFWeaponClassMapping> WeaponClassMappings;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	FName ArmsWeaponSocket = TEXT("WeaponSocket");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	FName BodyWeaponSocket = TEXT("WeaponSocket");

	UPROPERTY(ReplicatedUsing = OnRep_CurrentWeapon, BlueprintReadOnly, Category = "State")
	TObjectPtr<ABFWeaponBase> CurrentWeapon;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	TObjectPtr<ABFWeaponBase> PrimaryWeapon;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	TObjectPtr<ABFWeaponBase> SecondaryWeapon;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	TObjectPtr<ABFEquipmentBase> Equipment;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	EBFWeaponSlot CurrentSlot = EBFWeaponSlot::Primary;

	UFUNCTION() void OnRep_CurrentWeapon();

	UFUNCTION(Server, Reliable) void ServerSelectSlot(EBFWeaponSlot Slot);

private:
	UPROPERTY() TObjectPtr<ABFCharacter> OwnerCharacter;

	bool bSwitching = false;
	bool bPendingAim = false;
	bool bPendingBraced = false;
	FTimerHandle SwitchTimer;

	TSubclassOf<ABFWeaponBase> ResolveWeaponClass(EBFWeaponCategory Category) const;
	ABFWeaponBase* SpawnWeaponFor(UBFWeaponDataAsset* Data) const;
	void AttachWeaponToOwner(ABFWeaponBase* Weapon);
	void FinishSwitch();
	void SetCurrentWeaponInternal(ABFWeaponBase* NewWeapon, EBFWeaponSlot Slot);
};
