#include "Weapons/BFWeaponBase.h"

#include "Animation/AnimInstance.h"
#include "Animation/AnimMontage.h"
#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "NiagaraComponent.h"
#include "Sound/SoundBase.h"
#include "Core/BFLog.h"
#include "Data/BFWeaponDataAsset.h"
#include "Engine/DamageEvents.h"
#include "Engine/World.h"
#include "GameFramework/Controller.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"
#include "NiagaraFunctionLibrary.h"
#include "PhysicalMaterials/PhysicalMaterial.h"
#include "Systems/BFAudioManager.h"
#include "Systems/BFDamageManager.h"
#include "TimerManager.h"
#include "Weapons/BFProjectile.h"

ABFWeaponBase::ABFWeaponBase()
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;
	SetReplicateMovement(false); // attached to the owner; movement follows the parent

	WeaponMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("WeaponMesh"));
	WeaponMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	WeaponMesh->bReceivesDecals = false;
	WeaponMesh->CastShadow = true;
	SetRootComponent(WeaponMesh);

	NetUpdateFrequency = 40.f;
}

void ABFWeaponBase::BeginPlay()
{
	Super::BeginPlay();

	if (WeaponData)
	{
		OnRep_WeaponData();
	}
}

void ABFWeaponBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABFWeaponBase, WeaponData);
	DOREPLIFETIME(ABFWeaponBase, OwningCharacter);
	DOREPLIFETIME(ABFWeaponBase, bReloading);
	DOREPLIFETIME(ABFWeaponBase, CurrentFireMode);
	// Ammo only matters to the holder and to the server.
	DOREPLIFETIME_CONDITION(ABFWeaponBase, ClipAmmo, COND_OwnerOnly);
	DOREPLIFETIME_CONDITION(ABFWeaponBase, ReserveAmmo, COND_OwnerOnly);
}

void ABFWeaponBase::InitializeWeapon(ABFCharacter* NewOwner, UBFWeaponDataAsset* Data)
{
	if (!HasAuthority())
	{
		return;
	}

	OwningCharacter = NewOwner;
	WeaponData = Data;
	SetOwner(NewOwner);

	if (WeaponData)
	{
		ClipAmmo = WeaponData->MagazineSize;
		ReserveAmmo = WeaponData->MagazineSize * WeaponData->StartingMagazines;
		CurrentFireMode = WeaponData->FireModes.Num() > 0 ? WeaponData->FireModes[0] : EBFFireMode::SingleShot;
		OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);
	}

	OnRep_WeaponData();
}

void ABFWeaponBase::OnRep_WeaponData()
{
	if (!WeaponData)
	{
		return;
	}

	if (USkeletalMesh* Mesh = WeaponData->WeaponMesh.LoadSynchronous())
	{
		WeaponMesh->SetSkeletalMesh(Mesh);
	}
}

void ABFWeaponBase::OnRep_Ammo()
{
	OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);
}

void ABFWeaponBase::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!WeaponData)
	{
		return;
	}

	// Spread and recoil bloom settle over time whenever we are not shooting.
	const float TimeSinceFire = GetWorld()->GetTimeSeconds() - LastFireTime;
	if (TimeSinceFire > 0.08f)
	{
		if (AccumulatedSpread > 0.f)
		{
			AccumulatedSpread = FMath::FInterpConstantTo(AccumulatedSpread, 0.f, DeltaSeconds, WeaponData->SpreadRecoverySpeed);
		}
		if (CurrentRecoilMultiplier > 1.f)
		{
			CurrentRecoilMultiplier = FMath::FInterpConstantTo(CurrentRecoilMultiplier, 1.f, DeltaSeconds, WeaponData->RecoilRecoverySpeed * 0.35f);
		}
	}
}

// ---------------------------------------------------------------- Queries

float ABFWeaponBase::ComputeSpreadScale() const
{
	if (!WeaponData || !OwningCharacter)
	{
		return 1.f;
	}

	float Scale = 1.f;

	switch (OwningCharacter->GetStance())
	{
	case EBFStance::Crouched: Scale *= WeaponData->CrouchSpreadScale; break;
	case EBFStance::Prone:    Scale *= WeaponData->ProneSpreadScale; break;
	default: break;
	}

	if (bBraced)
	{
		Scale *= WeaponData->BracedSpreadScale;
	}

	if (const UCharacterMovementComponent* Move = OwningCharacter->GetCharacterMovement())
	{
		const float Speed = Move->Velocity.Size2D();
		if (Speed > 50.f)
		{
			const float MoveAlpha = FMath::Clamp(Speed / 600.f, 0.f, 1.f);
			Scale *= FMath::Lerp(1.f, WeaponData->MovingSpreadScale, MoveAlpha);
		}
		if (Move->IsFalling())
		{
			Scale *= 2.5f; // jump-shooting is punished, not banned
		}
	}

	return Scale;
}

float ABFWeaponBase::GetCurrentSpread() const
{
	if (!WeaponData)
	{
		return 0.f;
	}

	const float Base = bAiming ? WeaponData->AimSpread : WeaponData->BaseSpread;
	return FMath::Min(WeaponData->MaxSpread, (Base + AccumulatedSpread) * ComputeSpreadScale());
}

float ABFWeaponBase::GetWeightSpeedScale() const
{
	return WeaponData ? WeaponData->GetWeightSpeedScale() : 1.f;
}

float ABFWeaponBase::GetAimFOV(float DefaultFOV) const
{
	return WeaponData ? WeaponData->AimFOV : DefaultFOV;
}

float ABFWeaponBase::GetADSTime() const
{
	return WeaponData ? WeaponData->AimDownSightTime : 0.25f;
}

FText ABFWeaponBase::GetDisplayName() const
{
	return WeaponData ? WeaponData->DisplayName : FText::GetEmpty();
}

bool ABFWeaponBase::CanFire() const
{
	if (!WeaponData || !OwningCharacter || bReloading || !bActiveWeapon)
	{
		return false;
	}

	if (ClipAmmo <= 0)
	{
		return false;
	}

	if (const UBFHealthComponent* Health = OwningCharacter->GetHealthComponent())
	{
		if (Health->IsDead() || Health->IsDowned())
		{
			return false;
		}
	}

	// Sprinting blocks fire; it forces players to slow down before engaging.
	if (OwningCharacter->IsSprinting())
	{
		return false;
	}

	if (CurrentFireMode == EBFFireMode::Burst && BurstShotsFired >= WeaponData->BurstCount)
	{
		return false;
	}

	return true;
}

// ---------------------------------------------------------------- Commands

void ABFWeaponBase::SetWeaponActive(bool bActive)
{
	bActiveWeapon = bActive;
	SetActorHiddenInGame(!bActive);

	if (!bActive)
	{
		StopFire();
		GetWorldTimerManager().ClearTimer(FireTimer);
		if (HasAuthority())
		{
			GetWorldTimerManager().ClearTimer(ReloadTimer);
			bReloading = false;
		}
	}
}

void ABFWeaponBase::StartFire()
{
	if (!WeaponData)
	{
		return;
	}

	bTriggerHeld = true;
	BurstShotsFired = 0;

	if (ClipAmmo <= 0)
	{
		if (USoundBase* Dry = WeaponData->DryFireSound.LoadSynchronous())
		{
			UGameplayStatics::PlaySoundAtLocation(this, Dry, GetActorLocation());
		}
		Reload();
		return;
	}

	const float ShotInterval = WeaponData->GetShotInterval();
	const float TimeSinceLast = GetWorld()->GetTimeSeconds() - LastFireTime;

	if (TimeSinceLast >= ShotInterval)
	{
		LocalFire();
	}

	if (CurrentFireMode != EBFFireMode::SingleShot)
	{
		const float FirstDelay = FMath::Max(ShotInterval - FMath::Max(TimeSinceLast, 0.f), 0.f) + ShotInterval;
		GetWorldTimerManager().SetTimer(FireTimer, this, &ABFWeaponBase::LocalFire, ShotInterval, true, FirstDelay - ShotInterval);
	}
}

void ABFWeaponBase::StopFire()
{
	bTriggerHeld = false;
	BurstShotsFired = 0;
	GetWorldTimerManager().ClearTimer(FireTimer);

	if (!HasAuthority())
	{
		ServerStopFire();
	}
}

void ABFWeaponBase::ServerStopFire_Implementation()
{
	bTriggerHeld = false;
}

void ABFWeaponBase::LocalFire()
{
	if (!CanFire())
	{
		GetWorldTimerManager().ClearTimer(FireTimer);
		if (ClipAmmo <= 0 && !bReloading)
		{
			Reload();
		}
		return;
	}

	LastFireTime = GetWorld()->GetTimeSeconds();
	++BurstShotsFired;

	FVector AimLocation;
	FRotator AimRotation;
	OwningCharacter->GetAimTransform(AimLocation, AimRotation);
	const FVector AimDirection = AimRotation.Vector();

	const float Spread = GetCurrentSpread();
	const int32 Seed = ++NextShotSeed * 7919 + FMath::RandRange(0, 1023);

	// The owning client predicts cosmetics immediately; the server owns the outcome.
	if (!HasAuthority())
	{
		// Local ammo prediction keeps the HUD responsive; the server value overwrites it on replication.
		ClipAmmo = FMath::Max(0, ClipAmmo - 1);
		OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);
		PlayFireCosmetics(AimLocation + AimDirection * WeaponData->MaxEffectiveRange);
		ServerFire(AimLocation, AimDirection, Spread, Seed);
	}
	else
	{
		ServerFire_Implementation(AimLocation, AimDirection, Spread, Seed);
	}

	// Recoil and bloom are applied locally so the shooter feels it on the exact frame.
	if (OwningCharacter->IsLocallyControlled())
	{
		const float Pitch = WeaponData->RecoilPitch * CurrentRecoilMultiplier * (bBraced ? 0.55f : 1.f) * (bAiming ? 0.8f : 1.f);
		const float Yaw = WeaponData->RecoilYaw * CurrentRecoilMultiplier * FMath::RandRange(-1.f, 1.f);
		OwningCharacter->AddRecoil(Pitch, Yaw);
	}

	AccumulatedSpread = FMath::Min(WeaponData->MaxSpread, AccumulatedSpread + WeaponData->SpreadPerShot);
	CurrentRecoilMultiplier = FMath::Min(WeaponData->MaxRecoilMultiplier, CurrentRecoilMultiplier + 0.12f);

	if (CurrentFireMode == EBFFireMode::Burst && BurstShotsFired >= WeaponData->BurstCount)
	{
		GetWorldTimerManager().ClearTimer(FireTimer);
		// Burst re-arms after a short pause even if the trigger stays down.
		GetWorldTimerManager().SetTimer(FireTimer, this, &ABFWeaponBase::ResetBurst, WeaponData->GetShotInterval() * 2.5f, false);
	}
}

void ABFWeaponBase::ResetBurst()
{
	BurstShotsFired = 0;
	if (bTriggerHeld && CurrentFireMode == EBFFireMode::Burst)
	{
		StartFire();
	}
}

bool ABFWeaponBase::ServerFire_Validate(FVector_NetQuantize /*AimLocation*/, FVector_NetQuantizeNormal /*AimDirection*/, float ClientSpread, int32 /*ShotSeed*/)
{
	// Reject absurd spread claims outright.
	return ClientSpread >= 0.f && ClientSpread < 45.f;
}

void ABFWeaponBase::ServerFire_Implementation(FVector_NetQuantize AimLocation, FVector_NetQuantizeNormal AimDirection, float ClientSpread, int32 ShotSeed)
{
	if (!WeaponData || !OwningCharacter)
	{
		return;
	}

	// Server-side rate limit. A small tolerance absorbs jitter without allowing rapid fire.
	const float Now = GetWorld()->GetTimeSeconds();
	const float MinInterval = WeaponData->GetShotInterval() * 0.85f;
	static const FName AmmoTag(TEXT("BFServerFire"));
	if (ClipAmmo <= 0 || bReloading)
	{
		return;
	}
	if (Now - LastFireTime < MinInterval && !FMath::IsNearlyEqual(LastFireTime, Now))
	{
		// Allow the authoritative path from LocalFire (same frame) but drop true spam.
		if (GetNetMode() != NM_Standalone && !OwningCharacter->IsLocallyControlled())
		{
			return;
		}
	}

	// Anti-cheat: the shot must originate near the pawn's actual view point.
	const FVector ServerViewLocation = OwningCharacter->GetPawnViewLocation();
	if (FVector::DistSquared(ServerViewLocation, AimLocation) > FMath::Square(180.f))
	{
		AimLocation = ServerViewLocation;
	}

	LastFireTime = Now;
	ClipAmmo = FMath::Max(0, ClipAmmo - 1);
	OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);

	// Use the server's own spread when the client claims something better than possible.
	const float ServerSpread = FMath::Min(ClientSpread, GetCurrentSpread() + 0.15f);
	ServerResolveShot(AimLocation, AimDirection.GetSafeNormal(), ServerSpread, ShotSeed);
}

void ABFWeaponBase::ServerResolveShot(const FVector& Origin, const FVector& Direction, float Spread, int32 Seed)
{
	FRandomStream Stream(Seed);

	if (WeaponData->bUseProjectiles && WeaponData->ProjectileClass)
	{
		for (int32 Pellet = 0; Pellet < WeaponData->PelletsPerShot; ++Pellet)
		{
			const FVector ShotDir = ApplySpreadToDirection(Direction, Spread, Stream);

			FActorSpawnParameters Params;
			Params.Owner = this;
			Params.Instigator = OwningCharacter;
			Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

			if (ABFProjectile* Projectile = GetWorld()->SpawnActor<ABFProjectile>(
				WeaponData->ProjectileClass, Origin + ShotDir * 30.f, ShotDir.Rotation(), Params))
			{
				Projectile->InitializeBallistics(WeaponData, ShotDir, OwningCharacter);
			}
		}
	}
	else
	{
		for (int32 Pellet = 0; Pellet < WeaponData->PelletsPerShot; ++Pellet)
		{
			TraceAndDamage(Origin, Direction, Stream, Spread);
		}
	}

	MulticastFireEffects(Origin + Direction * WeaponData->MaxEffectiveRange);
}

FVector ABFWeaponBase::ApplySpreadToDirection(const FVector& Direction, float SpreadDegrees, FRandomStream& Stream) const
{
	if (SpreadDegrees <= KINDA_SMALL_NUMBER)
	{
		return Direction;
	}
	return Stream.VRandCone(Direction, FMath::DegreesToRadians(SpreadDegrees));
}

void ABFWeaponBase::TraceAndDamage(const FVector& Origin, const FVector& Direction, FRandomStream& Stream, float Spread)
{
	const FVector ShotDir = ApplySpreadToDirection(Direction, Spread, Stream);
	FVector TraceStart = Origin;
	FVector TraceEnd = Origin + ShotDir * WeaponData->MaxTraceRange;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFWeaponTrace), true, OwningCharacter);
	Params.bReturnPhysicalMaterial = true;
	Params.AddIgnoredActor(this);

	float RemainingPower = 1.f;
	int32 PenetrationsLeft = 2; // a round can punch through at most two light surfaces

	while (PenetrationsLeft-- > 0 && RemainingPower > 0.05f)
	{
		FHitResult Hit;
		if (!GetWorld()->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, BF_TRACE_WEAPON, Params))
		{
			break;
		}

		const float Distance = FVector::Dist(Origin, Hit.ImpactPoint);
		const float Damage = WeaponData->GetDamageAtDistance(Distance) * RemainingPower;

		EBFSurfaceType Surface = EBFSurfaceType::Default;
		if (Hit.PhysMaterial.IsValid())
		{
			const int32 Index = static_cast<int32>(Hit.PhysMaterial->SurfaceType);
			if (Index >= 1 && Index <= 6)
			{
				Surface = static_cast<EBFSurfaceType>(Index);
			}
		}

		// Central routing so friendly fire rules, hit-zone multipliers and scoring live in one place.
		UBFDamageManager::ApplyWeaponDamage(
			Hit.GetActor(), Damage, Hit, ShotDir, OwningCharacter, this, WeaponData);

		MulticastImpactEffects(Hit.ImpactPoint, Hit.ImpactNormal, static_cast<uint8>(Surface));

		// Wood and sandbags bleed the round; stone and metal stop it.
		const bool bLightCover = (Surface == EBFSurfaceType::Wood || Surface == EBFSurfaceType::Grass || Surface == EBFSurfaceType::Mud);
		if (!bLightCover || WeaponData->PenetrationPower <= 0.f)
		{
			break;
		}

		RemainingPower *= WeaponData->PenetrationPower;
		TraceStart = Hit.ImpactPoint + ShotDir * 12.f;
		Params.AddIgnoredActor(Hit.GetActor());
	}
}

// ---------------------------------------------------------------- Reload

void ABFWeaponBase::Reload()
{
	if (!WeaponData || bReloading || ReserveAmmo <= 0 || ClipAmmo >= WeaponData->MagazineSize)
	{
		return;
	}

	if (HasAuthority())
	{
		ServerStartReload_Implementation();
	}
	else
	{
		// Predict the animation locally for responsiveness.
		bReloading = true;
		ServerStartReload();
	}

	if (WeaponData)
	{
		if (USoundBase* Sound = WeaponData->ReloadSound.LoadSynchronous())
		{
			UGameplayStatics::SpawnSoundAttached(Sound, WeaponMesh);
		}
	}
}

void ABFWeaponBase::ServerStartReload_Implementation()
{
	if (!WeaponData || bReloading || ReserveAmmo <= 0 || ClipAmmo >= WeaponData->MagazineSize)
	{
		return;
	}

	bReloading = true;
	bTriggerHeld = false;
	GetWorldTimerManager().ClearTimer(FireTimer);

	const float Duration = (ClipAmmo > 0) ? WeaponData->TacticalReloadTime : WeaponData->ReloadTime;
	GetWorldTimerManager().SetTimer(ReloadTimer, this, &ABFWeaponBase::FinishReload, Duration, false);
}

void ABFWeaponBase::FinishReload()
{
	if (!HasAuthority() || !WeaponData)
	{
		return;
	}

	if (WeaponData->bShellByShellReload)
	{
		// One shell at a time: keep going until full or empty, interruptible by firing.
		if (ClipAmmo < WeaponData->MagazineSize && ReserveAmmo > 0)
		{
			++ClipAmmo;
			--ReserveAmmo;
			OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);

			if (ClipAmmo < WeaponData->MagazineSize && ReserveAmmo > 0)
			{
				GetWorldTimerManager().SetTimer(ReloadTimer, this, &ABFWeaponBase::FinishReload, WeaponData->TacticalReloadTime * 0.4f, false);
				return;
			}
		}
		bReloading = false;
		return;
	}

	const int32 Needed = WeaponData->MagazineSize - ClipAmmo;
	const int32 Taken = FMath::Min(Needed, ReserveAmmo);
	ClipAmmo += Taken;
	ReserveAmmo -= Taken;
	bReloading = false;
	AccumulatedSpread = 0.f;
	CurrentRecoilMultiplier = 1.f;
	OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);
}

int32 ABFWeaponBase::AddReserveAmmo(int32 Magazines)
{
	if (!HasAuthority() || !WeaponData || Magazines <= 0)
	{
		return 0;
	}

	const int32 MaxReserve = WeaponData->MagazineSize * WeaponData->StartingMagazines;
	const int32 Added = FMath::Min(Magazines * WeaponData->MagazineSize, FMath::Max(0, MaxReserve - ReserveAmmo));
	ReserveAmmo += Added;
	OnAmmoChanged.Broadcast(ClipAmmo, ReserveAmmo);
	return Added;
}

// ---------------------------------------------------------------- Fire mode / inspect

void ABFWeaponBase::CycleFireMode()
{
	if (!WeaponData || WeaponData->FireModes.Num() <= 1)
	{
		return;
	}

	const int32 Current = WeaponData->FireModes.IndexOfByKey(CurrentFireMode);
	const int32 Next = (Current + 1) % WeaponData->FireModes.Num();
	CurrentFireMode = WeaponData->FireModes[Next];
	BurstShotsFired = 0;

	if (!HasAuthority())
	{
		ServerSetFireMode(CurrentFireMode);
	}
}

void ABFWeaponBase::ServerSetFireMode_Implementation(EBFFireMode NewMode)
{
	if (WeaponData && WeaponData->FireModes.Contains(NewMode))
	{
		CurrentFireMode = NewMode;
	}
}

void ABFWeaponBase::Inspect()
{
	if (!WeaponData || bReloading || bTriggerHeld)
	{
		return;
	}

	if (OwningCharacter && OwningCharacter->IsLocallyControlled())
	{
		if (UAnimMontage* Montage = WeaponData->InspectMontage.LoadSynchronous())
		{
			if (USkeletalMeshComponent* Arms = OwningCharacter->GetArmsMesh())
			{
				if (UAnimInstance* Anim = Arms->GetAnimInstance())
				{
					Anim->Montage_Play(Montage);
				}
			}
		}
	}
}

// ---------------------------------------------------------------- Cosmetics

void ABFWeaponBase::GetMuzzleTransform(FVector& OutLocation, FRotator& OutRotation) const
{
	if (WeaponMesh && WeaponMesh->DoesSocketExist(MuzzleSocketName))
	{
		OutLocation = WeaponMesh->GetSocketLocation(MuzzleSocketName);
		OutRotation = WeaponMesh->GetSocketRotation(MuzzleSocketName);
		return;
	}

	OutLocation = GetActorLocation();
	OutRotation = GetActorRotation();
}

void ABFWeaponBase::MulticastFireEffects_Implementation(FVector_NetQuantize TracerEnd)
{
	// The shooter already predicted this locally.
	if (OwningCharacter && OwningCharacter->IsLocallyControlled() && GetNetMode() == NM_Client)
	{
		return;
	}
	PlayFireCosmetics(TracerEnd);
}

void ABFWeaponBase::PlayFireCosmetics(const FVector& TracerEnd)
{
	if (!WeaponData || GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	FVector MuzzleLoc;
	FRotator MuzzleRot;
	GetMuzzleTransform(MuzzleLoc, MuzzleRot);

	if (UNiagaraSystem* Flash = WeaponData->MuzzleFlash.LoadSynchronous())
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Flash, MuzzleLoc, MuzzleRot);
	}

	if (UNiagaraSystem* Shell = WeaponData->ShellEject.LoadSynchronous())
	{
		UNiagaraFunctionLibrary::SpawnSystemAttached(Shell, WeaponMesh, TEXT("ShellEject"),
			FVector::ZeroVector, FRotator::ZeroRotator, EAttachLocation::SnapToTarget, true);
	}

	if (UNiagaraSystem* Tracer = WeaponData->TracerEffect.LoadSynchronous())
	{
		if (UNiagaraComponent* Comp = UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Tracer, MuzzleLoc, MuzzleRot))
		{
			Comp->SetVectorParameter(TEXT("TracerEnd"), TracerEnd);
		}
	}

	// Indoor tail swap: a rifle inside a bunker should slap, not echo across a field.
	const bool bIndoors = OwningCharacter && OwningCharacter->IsIndoors();
	TSoftObjectPtr<USoundBase> SoundPtr = (bIndoors && !WeaponData->FireTailIndoorSound.IsNull())
		? WeaponData->FireTailIndoorSound : WeaponData->FireSound;

	if (USoundBase* Sound = SoundPtr.LoadSynchronous())
	{
		ABFAudioManager::PlaySpatialised(GetWorld(), Sound, MuzzleLoc, 1.f);
	}
}

void ABFWeaponBase::MulticastImpactEffects_Implementation(FVector_NetQuantize Location, FVector_NetQuantizeNormal Normal, uint8 SurfaceType)
{
	SpawnImpactCosmetics(Location, Normal, static_cast<EBFSurfaceType>(SurfaceType));
}

void ABFWeaponBase::SpawnImpactCosmetics(const FVector& Location, const FVector& Normal, EBFSurfaceType Surface)
{
	if (GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	// Impact VFX/SFX banks live on the audio manager so every damage source shares them.
	ABFAudioManager::PlaySurfaceImpact(GetWorld(), Surface, Location, Normal);
}
