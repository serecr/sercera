#include "BrokenFront.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE(FDefaultGameModuleImpl, BrokenFront, "BrokenFront");
