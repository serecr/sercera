#include "Frontline/BFFrontlineManager.h"

#include "Core/BFLog.h"
#include "Data/BFSectorDataAsset.h"
#include "EngineUtils.h"
#include "Gameplay/BFGameState.h"
#include "Net/UnrealNetwork.h"
#include "Sectors/BFSector.h"
#include "Systems/BFObjectiveManager.h"
#include "TimerManager.h"

ABFFrontlineManager::ABFFrontlineManager()
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = true;
	SetReplicateMovement(false);
	bAlwaysRelevant = true;
	NetUpdateFrequency = 4.f;
}

ABFFrontlineManager* ABFFrontlineManager::Get(const UWorld* World)
{
	if (!World)
	{
		return nullptr;
	}

	for (TActorIterator<ABFFrontlineManager> It(World); It; ++It)
	{
		return *It;
	}
	return nullptr;
}

void ABFFrontlineManager::BeginPlay()
{
	Super::BeginPlay();

	if (HasAuthority())
	{
		// Sectors register themselves in their own BeginPlay, so wait one tick.
		GetWorld()->GetTimerManager().SetTimerForNextTick(
			FTimerDelegate::CreateUObject(this, &ABFFrontlineManager::InitializeFrontline));
	}
}

void ABFFrontlineManager::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFFrontlineManager, IroncladFrontIndex);
	DOREPLIFETIME(ABFFrontlineManager, AshguardFrontIndex);
	DOREPLIFETIME(ABFFrontlineManager, VictoriousTeam);
}

void ABFFrontlineManager::GatherSectors()
{
	LadderInternal.Reset();

	for (TActorIterator<ABFSector> It(GetWorld()); It; ++It)
	{
		if (ABFSector* Sector = *It)
		{
			LadderInternal.Add(Sector);
		}
	}

	LadderInternal.Sort([](const ABFSector& A, const ABFSector& B)
	{
		return A.GetLineIndex() < B.GetLineIndex();
	});

	Ladder.Reset(LadderInternal.Num());
	for (const TObjectPtr<ABFSector>& Sector : LadderInternal)
	{
		Ladder.Add(Sector.Get());
	}
}

void ABFFrontlineManager::InitializeFrontline()
{
	if (!HasAuthority())
	{
		return;
	}

	GatherSectors();

	if (LadderInternal.Num() < 2)
	{
		BF_LOG(LogBFFrontline, Error,
			TEXT("Frontline needs at least two sectors in the level, found %d."), LadderInternal.Num());
		return;
	}

	// Assign starting ownership. A sector's data asset wins if it declares an owner;
	// otherwise we split the ladder down the middle.
	const int32 Split = (InitialSplitIndex >= 0)
		? InitialSplitIndex
		: LadderInternal.Num() / 2;

	for (int32 Index = 0; Index < LadderInternal.Num(); ++Index)
	{
		ABFSector* Sector = LadderInternal[Index];
		if (!Sector)
		{
			continue;
		}

		Sector->OnOwnerChanged.RemoveDynamic(this, &ABFFrontlineManager::HandleSectorOwnerChanged);
		Sector->OnOwnerChanged.AddDynamic(this, &ABFFrontlineManager::HandleSectorOwnerChanged);

		const UBFSectorDataAsset* Data = Sector->GetSectorData();
		const bool bDataDeclaresOwner = Data && Data->InitialOwner != EBFTeam::Neutral;

		const EBFTeam Owner = bDataDeclaresOwner
			? Data->InitialOwner
			: (Index < Split ? EBFTeam::Ironclad : EBFTeam::Ashguard);

		Sector->SetOwningTeam(Owner, true);
	}

	RecalculateFrontline();

	BF_LOG(LogBFFrontline, Log, TEXT("Frontline initialised with %d sectors. Ironclad front %d, Ashguard front %d."),
		LadderInternal.Num(), IroncladFrontIndex, AshguardFrontIndex);
}

void ABFFrontlineManager::RecalculateFrontline()
{
	if (!HasAuthority() || LadderInternal.Num() == 0)
	{
		return;
	}

	int32 HighestIronclad = INDEX_NONE;
	int32 LowestAshguard = INDEX_NONE;

	for (int32 Index = 0; Index < LadderInternal.Num(); ++Index)
	{
		const ABFSector* Sector = LadderInternal[Index];
		if (!Sector)
		{
			continue;
		}

		if (Sector->GetOwningTeam() == EBFTeam::Ironclad)
		{
			HighestIronclad = Index;
		}
		else if (Sector->GetOwningTeam() == EBFTeam::Ashguard && LowestAshguard == INDEX_NONE)
		{
			LowestAshguard = Index;
		}
	}

	// Neutral edge cases: if one side owns nothing, clamp to the ladder bounds.
	IroncladFrontIndex = (HighestIronclad == INDEX_NONE) ? -1 : HighestIronclad;
	AshguardFrontIndex = (LowestAshguard == INDEX_NONE) ? LadderInternal.Num() : LowestAshguard;

	ApplyActivation();
	CheckVictory();

	OnFrontlineShifted.Broadcast(IroncladFrontIndex, AshguardFrontIndex);

	if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
	{
		GS->RefreshSectorSnapshots();
	}

	if (UBFObjectiveManager* Objectives = UBFObjectiveManager::Get(GetWorld()))
	{
		Objectives->RebuildObjectivesForFrontline(this);
	}
}

void ABFFrontlineManager::ApplyActivation()
{
	// Everything between the two fronts is in play. With a full ladder and no
	// neutral gaps that is exactly one sector; after a flip it is the newly
	// exposed line. ActiveWindow widens it for flanking play.
	const int32 FirstContested = IroncladFrontIndex + 1;
	const int32 LastContested = AshguardFrontIndex - 1;

	for (int32 Index = 0; Index < LadderInternal.Num(); ++Index)
	{
		ABFSector* Sector = LadderInternal[Index];
		if (!Sector)
		{
			continue;
		}

		bool bActive = false;

		if (FirstContested <= LastContested)
		{
			// There is genuinely neutral ground in the middle.
			bActive = (Index >= FirstContested && Index <= LastContested);
		}
		else
		{
			// Fronts are adjacent: both sides' foremost sectors are attackable.
			bActive = (Index == IroncladFrontIndex) || (Index == AshguardFrontIndex);
		}

		// Widen by ActiveWindow - 1 on each side so pushes can bypass a strongpoint.
		if (!bActive && ActiveWindow > 1)
		{
			const int32 Slack = ActiveWindow - 1;
			bActive = (Index >= IroncladFrontIndex - Slack && Index <= AshguardFrontIndex + Slack) &&
				(Index > IroncladFrontIndex - ActiveWindow) && (Index < AshguardFrontIndex + ActiveWindow);
		}

		// Home bases can only be attacked when they are the last line standing.
		if (bActive && Sector->IsHomeBase())
		{
			const bool bIsLastLine = (Sector->GetOwningTeam() == EBFTeam::Ironclad && Index == IroncladFrontIndex)
				|| (Sector->GetOwningTeam() == EBFTeam::Ashguard && Index == AshguardFrontIndex);
			bActive = bIsLastLine;
		}

		Sector->SetCaptureEnabled(bActive && !bShiftLocked);
		Sector->SetIsFrontline(bActive);
	}
}

void ABFFrontlineManager::HandleSectorOwnerChanged(ABFSector* Sector, EBFTeam NewOwner, EBFTeam OldOwner)
{
	if (!HasAuthority() || !Sector)
	{
		return;
	}

	BF_LOG(LogBFFrontline, Log, TEXT("Frontline shift: %s now held by team %d (was %d)"),
		*Sector->GetSectorId().ToString(), static_cast<int32>(NewOwner), static_cast<int32>(OldOwner));

	// Brief lockout so the losing side can fall back into the next trench line
	// instead of being immediately steamrolled.
	if (ShiftCooldown > 0.f)
	{
		bShiftLocked = true;
		GetWorld()->GetTimerManager().SetTimer(ShiftCooldownTimer, this,
			&ABFFrontlineManager::ReleaseShiftLock, ShiftCooldown, false);
	}

	RecalculateFrontline();
}

void ABFFrontlineManager::ReleaseShiftLock()
{
	bShiftLocked = false;
	ApplyActivation();
}

void ABFFrontlineManager::CheckVictory()
{
	EBFTeam Winner = EBFTeam::Neutral;

	// A team wins by taking the enemy home base.
	for (const TObjectPtr<ABFSector>& Sector : LadderInternal)
	{
		if (Sector && Sector->IsHomeBase() && Sector->GetOwningTeam() != EBFTeam::Neutral)
		{
			// Home base at the low end belongs to Ironclad by convention.
			const bool bIsLowEnd = Sector->GetLineIndex() <= LadderInternal[0]->GetLineIndex();
			const EBFTeam ExpectedOwner = bIsLowEnd ? EBFTeam::Ironclad : EBFTeam::Ashguard;
			if (Sector->GetOwningTeam() != ExpectedOwner)
			{
				Winner = Sector->GetOwningTeam();
				break;
			}
		}
	}

	if (Winner != EBFTeam::Neutral && VictoriousTeam == EBFTeam::Neutral)
	{
		VictoriousTeam = Winner;
		BF_LOG(LogBFFrontline, Log, TEXT("Team %d has broken the front."), static_cast<int32>(Winner));

		if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
		{
			GS->RequestMatchEnd(Winner, TEXT("HomeBaseCaptured"));
		}
	}
}

ABFSector* ABFFrontlineManager::GetSectorByIndex(int32 LineIndex) const
{
	for (const TObjectPtr<ABFSector>& Sector : LadderInternal)
	{
		if (Sector && Sector->GetLineIndex() == LineIndex)
		{
			return Sector.Get();
		}
	}
	return nullptr;
}

ABFSector* ABFFrontlineManager::GetSectorById(FName SectorId) const
{
	for (const TObjectPtr<ABFSector>& Sector : LadderInternal)
	{
		if (Sector && Sector->GetSectorId() == SectorId)
		{
			return Sector.Get();
		}
	}
	return nullptr;
}

TArray<ABFSector*> ABFFrontlineManager::GetActiveSectors() const
{
	TArray<ABFSector*> Result;
	for (const TObjectPtr<ABFSector>& Sector : LadderInternal)
	{
		if (Sector && Sector->IsActive())
		{
			Result.Add(Sector.Get());
		}
	}
	return Result;
}

ABFSector* ABFFrontlineManager::GetAttackTargetFor(EBFTeam Team) const
{
	// The nearest live sector that the team does not own.
	const bool bAscending = (Team == EBFTeam::Ironclad);

	TArray<ABFSector*> Active = GetActiveSectors();
	Active.Sort([bAscending](const ABFSector& A, const ABFSector& B)
	{
		return bAscending ? A.GetLineIndex() < B.GetLineIndex() : A.GetLineIndex() > B.GetLineIndex();
	});

	for (ABFSector* Sector : Active)
	{
		if (Sector && Sector->GetOwningTeam() != Team)
		{
			return Sector;
		}
	}
	return nullptr;
}

ABFSector* ABFFrontlineManager::GetDefenceTargetFor(EBFTeam Team) const
{
	TArray<ABFSector*> Active = GetActiveSectors();
	const bool bAscending = (Team == EBFTeam::Ashguard);

	Active.Sort([bAscending](const ABFSector& A, const ABFSector& B)
	{
		return bAscending ? A.GetLineIndex() < B.GetLineIndex() : A.GetLineIndex() > B.GetLineIndex();
	});

	for (ABFSector* Sector : Active)
	{
		if (Sector && Sector->GetOwningTeam() == Team)
		{
			return Sector;
		}
	}
	return nullptr;
}

int32 ABFFrontlineManager::GetSectorAdvantage() const
{
	int32 Ironclad = 0;
	int32 Ashguard = 0;
	for (const TObjectPtr<ABFSector>& Sector : LadderInternal)
	{
		if (!Sector) { continue; }
		if (Sector->GetOwningTeam() == EBFTeam::Ironclad) { ++Ironclad; }
		else if (Sector->GetOwningTeam() == EBFTeam::Ashguard) { ++Ashguard; }
	}
	return Ashguard - Ironclad;
}

FString ABFFrontlineManager::GetFrontlineStateString() const
{
	const int32 Advantage = GetSectorAdvantage();
	if (Advantage == 0)
	{
		return TEXT("Even front");
	}
	return Advantage > 0
		? FString::Printf(TEXT("Ashguard +%d"), Advantage)
		: FString::Printf(TEXT("Ironclad +%d"), -Advantage);
}
