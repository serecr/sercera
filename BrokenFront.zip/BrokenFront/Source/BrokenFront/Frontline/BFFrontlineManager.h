#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFFrontlineManager.generated.h"

class ABFSector;
class ABFObjective;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBFFrontlineShifted, int32, NewIroncladLine, int32, NewAshguardLine);

/**
 * The heart of Broken Front.
 *
 * Sectors are sorted into a ladder by LineIndex. Ironclad owns the low indices,
 * Ashguard the high ones, and exactly one sector between them is live at a time
 * (optionally a small window, see ActiveWindow). When a live sector flips, the
 * ladder recalculates: the next enemy line opens, spawns move up, routes and
 * objectives change, and the loser's previous line becomes capturable again -
 * which is what lets a counter-attack push the front back the other way.
 *
 * Place exactly one of these in the level. It runs on the server and replicates
 * a compact frontline state to every client.
 */
UCLASS()
class BROKENFRONT_API ABFFrontlineManager : public AActor
{
	GENERATED_BODY()

public:
	ABFFrontlineManager();

	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	/** Convenience lookup; there is one manager per level. */
	static ABFFrontlineManager* Get(const UWorld* World);

	UPROPERTY(BlueprintAssignable, Category = "Frontline") FBFFrontlineShifted OnFrontlineShifted;

	/** Server: called once the match starts. Safe to call again to reset. */
	UFUNCTION(BlueprintCallable, Category = "Frontline")
	void InitializeFrontline();

	UFUNCTION(BlueprintPure, Category = "Frontline") const TArray<ABFSector*>& GetLadder() const { return Ladder; }

	/** Highest index Ironclad holds. */
	UFUNCTION(BlueprintPure, Category = "Frontline") int32 GetIroncladFrontIndex() const { return IroncladFrontIndex; }
	/** Lowest index Ashguard holds. */
	UFUNCTION(BlueprintPure, Category = "Frontline") int32 GetAshguardFrontIndex() const { return AshguardFrontIndex; }

	UFUNCTION(BlueprintPure, Category = "Frontline") ABFSector* GetSectorByIndex(int32 LineIndex) const;
	UFUNCTION(BlueprintPure, Category = "Frontline") ABFSector* GetSectorById(FName SectorId) const;

	/** The sector(s) currently in play. */
	UFUNCTION(BlueprintPure, Category = "Frontline") TArray<ABFSector*> GetActiveSectors() const;

	/** Which sector a team should be attacking right now. */
	UFUNCTION(BlueprintPure, Category = "Frontline") ABFSector* GetAttackTargetFor(EBFTeam Team) const;

	/** Which sector a team should be defending right now. */
	UFUNCTION(BlueprintPure, Category = "Frontline") ABFSector* GetDefenceTargetFor(EBFTeam Team) const;

	/** Net sector advantage, positive = Ashguard ahead. Used for the server browser string. */
	UFUNCTION(BlueprintPure, Category = "Frontline") int32 GetSectorAdvantage() const;

	/** Human readable state for the server browser, e.g. "Ironclad +2". */
	UFUNCTION(BlueprintPure, Category = "Frontline") FString GetFrontlineStateString() const;

	/** Set true when one side has taken every sector. */
	UFUNCTION(BlueprintPure, Category = "Frontline") EBFTeam GetVictoriousTeam() const { return VictoriousTeam; }

protected:
	/**
	 * How many sectors are live at once.
	 * 1 = strict single contested line (default, readable).
	 * 2 = the contested sector plus the next one back, which allows flanking pushes.
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "1", ClampMax = "3"))
	int32 ActiveWindow = 1;

	/** Seconds of lockout after a flip before the next sector opens: lets the losers fall back. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "0.0"))
	float ShiftCooldown = 12.f;

	/** Ironclad starts owning every index below this; Ashguard owns the rest. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	int32 InitialSplitIndex = -1;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") int32 IroncladFrontIndex = 0;
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") int32 AshguardFrontIndex = 0;
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") EBFTeam VictoriousTeam = EBFTeam::Neutral;

	UFUNCTION() void HandleSectorOwnerChanged(ABFSector* Sector, EBFTeam NewOwner, EBFTeam OldOwner);

private:
	/** Sorted by LineIndex ascending. */
	UPROPERTY() TArray<TObjectPtr<ABFSector>> LadderInternal;

	/** Blueprint-facing raw view of the ladder. */
	TArray<ABFSector*> Ladder;

	bool bShiftLocked = false;
	FTimerHandle ShiftCooldownTimer;

	void GatherSectors();
	void RecalculateFrontline();
	void ApplyActivation();
	void ReleaseShiftLock();
	void CheckVictory();
};
