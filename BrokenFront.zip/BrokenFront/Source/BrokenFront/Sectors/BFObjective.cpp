#include "Sectors/BFObjective.h"

#include "Characters/BFCharacter.h"
#include "Components/SphereComponent.h"
#include "Core/BFLog.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "Sectors/BFSector.h"
#include "Systems/BFDestructibleActor.h"

ABFObjective::ABFObjective()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.25f;
	bReplicates = true;
	SetReplicateMovement(false);
	bAlwaysRelevant = true;
	NetUpdateFrequency = 4.f;

	ObjectiveArea = CreateDefaultSubobject<USphereComponent>(TEXT("ObjectiveArea"));
	ObjectiveArea->InitSphereRadius(1400.f);
	ObjectiveArea->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	ObjectiveArea->SetHiddenInGame(true);
	SetRootComponent(ObjectiveArea);
}

void ABFObjective::BeginPlay()
{
	Super::BeginPlay();

	if (HasAuthority())
	{
		if (LinkedSector)
		{
			LinkedSector->RegisterObjective(this);
		}
		if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
		{
			GS->RegisterObjective(this);
		}
	}
	else
	{
		SetActorTickEnabled(false);
	}
}

void ABFObjective::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFObjective, Status);
	DOREPLIFETIME(ABFObjective, AssignedTeam);
	DOREPLIFETIME(ABFObjective, Progress);
}

float ABFObjective::GetRadius() const
{
	return ObjectiveArea ? ObjectiveArea->GetScaledSphereRadius() : 1400.f;
}

void ABFObjective::ActivateFor(EBFTeam Team)
{
	if (!HasAuthority() || (Status == EBFObjectiveStatus::Active && AssignedTeam == Team))
	{
		return;
	}

	AssignedTeam = Team;
	Status = EBFObjectiveStatus::Active;
	Progress = 0.f;
	ElapsedHoldTime = 0.f;
	OnStatusChanged.Broadcast(this, Status);
}

void ABFObjective::Deactivate()
{
	if (!HasAuthority() || Status == EBFObjectiveStatus::Inactive)
	{
		return;
	}

	Status = EBFObjectiveStatus::Inactive;
	AssignedTeam = EBFTeam::Neutral;
	Progress = 0.f;
	ElapsedHoldTime = 0.f;
	OnStatusChanged.Broadcast(this, Status);
}

void ABFObjective::OnSectorOwnershipChanged(EBFTeam NewOwner)
{
	if (!HasAuthority() || Status != EBFObjectiveStatus::Active)
	{
		return;
	}

	switch (ObjectiveType)
	{
	case EBFObjectiveType::CaptureSector:
		// Taking the sector *is* the objective.
		CompleteObjective(NewOwner == AssignedTeam);
		break;

	case EBFObjectiveType::DefendSector:
	case EBFObjectiveType::HoldPosition:
		// Losing the ground you were told to hold is a failure.
		if (NewOwner != AssignedTeam)
		{
			CompleteObjective(false);
		}
		break;

	default:
		break;
	}
}

void ABFObjective::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!HasAuthority() || Status != EBFObjectiveStatus::Active)
	{
		return;
	}

	switch (ObjectiveType)
	{
	case EBFObjectiveType::CaptureSector:
		if (LinkedSector)
		{
			Progress = LinkedSector->GetProgressForTeam(AssignedTeam);
		}
		break;

	case EBFObjectiveType::DestroyObjective:
		if (const ABFDestructibleActor* Destructible = Cast<ABFDestructibleActor>(TargetActor))
		{
			Progress = 1.f - Destructible->GetIntegrityPercent();
			if (Destructible->IsDestroyed())
			{
				CompleteObjective(true);
			}
		}
		else if (!TargetActor || TargetActor->IsPendingKillPending())
		{
			CompleteObjective(true);
		}
		break;

	case EBFObjectiveType::ProtectSupply:
		if (const ABFDestructibleActor* Supply = Cast<ABFDestructibleActor>(TargetActor))
		{
			Progress = Supply->GetIntegrityPercent();
			if (Supply->IsDestroyed())
			{
				CompleteObjective(false);
			}
		}
		break;

	case EBFObjectiveType::DefendSector:
	case EBFObjectiveType::HoldPosition:
	case EBFObjectiveType::ReconArea:
		TickHoldStyleObjective(DeltaSeconds);
		break;
	}
}

void ABFObjective::TickHoldStyleObjective(float DeltaSeconds)
{
	// Recon needs a scout inside the area; hold/defend just needs the timer to run out
	// while the sector stays yours.
	bool bConditionMet = true;

	if (ObjectiveType == EBFObjectiveType::ReconArea)
	{
		bConditionMet = false;
		const float RadiusSq = FMath::Square(GetRadius());
		for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
		{
			const ABFCharacter* Char = *It;
			if (Char && Char->GetTeam() == AssignedTeam &&
				FVector::DistSquared(Char->GetActorLocation(), GetActorLocation()) <= RadiusSq)
			{
				bConditionMet = true;
				break;
			}
		}
	}
	else if (LinkedSector)
	{
		bConditionMet = LinkedSector->GetOwningTeam() == AssignedTeam;
	}

	if (bConditionMet)
	{
		ElapsedHoldTime += DeltaSeconds;
		Progress = FMath::Clamp(ElapsedHoldTime / FMath::Max(RequiredDuration, 1.f), 0.f, 1.f);

		if (Progress >= 1.f)
		{
			CompleteObjective(true);
		}
	}
	else if (ObjectiveType == EBFObjectiveType::ReconArea)
	{
		// Recon progress decays if the area is left unobserved.
		ElapsedHoldTime = FMath::Max(0.f, ElapsedHoldTime - DeltaSeconds * 0.5f);
		Progress = FMath::Clamp(ElapsedHoldTime / FMath::Max(RequiredDuration, 1.f), 0.f, 1.f);
	}
}

void ABFObjective::CompleteObjective(bool bSuccess)
{
	if (!HasAuthority() || Status != EBFObjectiveStatus::Active)
	{
		return;
	}

	Status = bSuccess ? EBFObjectiveStatus::Completed : EBFObjectiveStatus::Failed;
	Progress = bSuccess ? 1.f : 0.f;

	if (bSuccess)
	{
		AwardTeamScore();
	}

	BF_LOG(LogBFFrontline, Log, TEXT("Objective %s %s for team %d"),
		*GetName(), bSuccess ? TEXT("completed") : TEXT("failed"), static_cast<int32>(AssignedTeam));

	OnStatusChanged.Broadcast(this, Status);
}

void ABFObjective::AwardTeamScore() const
{
	if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
	{
		GS->AddTeamScore(AssignedTeam, CompletionScore);
	}

	// Anyone inside the area shares the credit.
	const float RadiusSq = FMath::Square(GetRadius() * 1.2f);
	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		const ABFCharacter* Char = *It;
		if (Char && Char->GetTeam() == AssignedTeam &&
			FVector::DistSquared(Char->GetActorLocation(), GetActorLocation()) <= RadiusSq)
		{
			if (ABFPlayerState* PS = Char->GetPlayerState<ABFPlayerState>())
			{
				PS->AddScore(CompletionScore / 4);
			}
		}
	}
}

FText ABFObjective::GetObjectiveText() const
{
	const FText SectorName = LinkedSector ? LinkedSector->GetDisplayName() : FText::FromString(TEXT("Area"));

	switch (ObjectiveType)
	{
	case EBFObjectiveType::CaptureSector:
		return FText::Format(NSLOCTEXT("BrokenFront", "ObjCapture", "Capture {0}"), SectorName);
	case EBFObjectiveType::DefendSector:
		return FText::Format(NSLOCTEXT("BrokenFront", "ObjDefend", "Defend {0}"), SectorName);
	case EBFObjectiveType::DestroyObjective:
		return NSLOCTEXT("BrokenFront", "ObjDestroy", "Destroy the enemy emplacement");
	case EBFObjectiveType::ProtectSupply:
		return NSLOCTEXT("BrokenFront", "ObjProtect", "Protect the supply depot");
	case EBFObjectiveType::ReconArea:
		return FText::Format(NSLOCTEXT("BrokenFront", "ObjRecon", "Scout {0}"), SectorName);
	case EBFObjectiveType::HoldPosition:
		return FText::Format(NSLOCTEXT("BrokenFront", "ObjHold", "Hold {0}"), SectorName);
	default:
		return FText::GetEmpty();
	}
}

void ABFObjective::OnRep_Status()
{
	OnStatusChanged.Broadcast(this, Status);
}
