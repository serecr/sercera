#include "Sectors/BFSector.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Components/BoxComponent.h"
#include "Core/BFLog.h"
#include "Data/BFSectorDataAsset.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "Sectors/BFObjective.h"
#include "Sectors/BFSpawnPoint.h"
#include "Systems/BFDestructibleActor.h"

ABFSector::ABFSector()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.2f; // capture math does not need per-frame precision
	bReplicates = true;
	SetReplicateMovement(false);
	NetUpdateFrequency = 5.f;
	bAlwaysRelevant = true; // the HUD and minimap need every sector, everywhere

	CapturePointMarker = CreateDefaultSubobject<USceneComponent>(TEXT("CapturePointMarker"));
	SetRootComponent(CapturePointMarker);

	CaptureVolume = CreateDefaultSubobject<UBoxComponent>(TEXT("CaptureVolume"));
	CaptureVolume->SetupAttachment(CapturePointMarker);
	CaptureVolume->SetBoxExtent(FVector(1500.f, 1500.f, 600.f));
	CaptureVolume->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	CaptureVolume->SetCollisionObjectType(ECC_WorldStatic);
	CaptureVolume->SetCollisionResponseToAllChannels(ECR_Ignore);
	CaptureVolume->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
	CaptureVolume->SetGenerateOverlapEvents(true);
	CaptureVolume->SetHiddenInGame(true);
}

void ABFSector::BeginPlay()
{
	Super::BeginPlay();

	CaptureVolume->OnComponentBeginOverlap.AddDynamic(this, &ABFSector::OnCaptureVolumeBeginOverlap);
	CaptureVolume->OnComponentEndOverlap.AddDynamic(this, &ABFSector::OnCaptureVolumeEndOverlap);

	if (HasAuthority())
	{
		if (SectorData)
		{
			OwningTeam = SectorData->InitialOwner;
		}
		PreviousOwner = OwningTeam;
		SectorState = EBFSectorState::Dormant;
		CaptureProgress = BFTeam::Sign(OwningTeam);
		RefreshSpawnPoints();

		if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
		{
			GS->RegisterSector(this);
		}
	}
	else
	{
		// Clients still need the volume for local "you are in a contested zone" HUD cues.
		SetActorTickEnabled(false);
	}
}

void ABFSector::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABFSector, OwningTeam);
	DOREPLIFETIME(ABFSector, SectorState);
	DOREPLIFETIME(ABFSector, CaptureProgress);
	DOREPLIFETIME(ABFSector, bCaptureEnabled);
	DOREPLIFETIME(ABFSector, bIsFrontline);
	DOREPLIFETIME(ABFSector, IroncladPresent);
	DOREPLIFETIME(ABFSector, AshguardPresent);
}

// ---------------------------------------------------------------- Data accessors

FName ABFSector::GetSectorId() const
{
	return SectorData ? SectorData->SectorId : FallbackSectorId;
}

FText ABFSector::GetDisplayName() const
{
	if (SectorData && !SectorData->DisplayName.IsEmpty())
	{
		return SectorData->DisplayName;
	}
	return FText::FromName(GetSectorId());
}

int32 ABFSector::GetLineIndex() const
{
	return SectorData ? SectorData->LineIndex : FallbackLineIndex;
}

bool ABFSector::IsHomeBase() const
{
	return SectorData ? SectorData->bIsHomeBase : false;
}

FVector ABFSector::GetCapturePointLocation() const
{
	return CapturePointMarker ? CapturePointMarker->GetComponentLocation() : GetActorLocation();
}

float ABFSector::GetProgressForTeam(EBFTeam Team) const
{
	const float Sign = BFTeam::Sign(Team);
	if (FMath::IsNearlyZero(Sign))
	{
		return 0.f;
	}
	return FMath::Clamp(CaptureProgress * Sign, 0.f, 1.f);
}

int32 ABFSector::GetPresentCount(EBFTeam Team) const
{
	switch (Team)
	{
	case EBFTeam::Ironclad: return IroncladPresent;
	case EBFTeam::Ashguard: return AshguardPresent;
	default: return 0;
	}
}

FBFSectorSnapshot ABFSector::BuildSnapshot() const
{
	FBFSectorSnapshot Snapshot;
	Snapshot.SectorId = GetSectorId();
	Snapshot.DisplayName = GetDisplayName();
	Snapshot.Owner = OwningTeam;
	Snapshot.State = SectorState;
	Snapshot.CaptureProgress = CaptureProgress;
	Snapshot.WorldLocation = GetCapturePointLocation();
	Snapshot.LineIndex = GetLineIndex();
	Snapshot.bIsFrontline = bIsFrontline;
	return Snapshot;
}

// ---------------------------------------------------------------- Occupancy

void ABFSector::OnCaptureVolumeBeginOverlap(UPrimitiveComponent* /*OverlappedComp*/, AActor* OtherActor,
	UPrimitiveComponent* /*OtherComp*/, int32 /*OtherBodyIndex*/, bool /*bFromSweep*/, const FHitResult& /*Sweep*/)
{
	if (ABFCharacter* Char = Cast<ABFCharacter>(OtherActor))
	{
		Occupants.AddUnique(Char);
	}
}

void ABFSector::OnCaptureVolumeEndOverlap(UPrimitiveComponent* /*OverlappedComp*/, AActor* OtherActor,
	UPrimitiveComponent* /*OtherComp*/, int32 /*OtherBodyIndex*/)
{
	if (ABFCharacter* Char = Cast<ABFCharacter>(OtherActor))
	{
		Occupants.RemoveAll([Char](const TWeakObjectPtr<ABFCharacter>& Ptr) { return Ptr.Get() == Char; });
	}
}

void ABFSector::RecountOccupants()
{
	int32 Ironclad = 0;
	int32 Ashguard = 0;

	for (int32 Index = Occupants.Num() - 1; Index >= 0; --Index)
	{
		ABFCharacter* Char = Occupants[Index].Get();
		if (!Char)
		{
			Occupants.RemoveAtSwap(Index);
			continue;
		}

		// Downed and dead soldiers do not hold ground.
		if (const UBFHealthComponent* Health = Char->GetHealthComponent())
		{
			if (!Health->IsAlive() || Health->IsDowned())
			{
				continue;
			}
		}

		switch (Char->GetTeam())
		{
		case EBFTeam::Ironclad: ++Ironclad; break;
		case EBFTeam::Ashguard: ++Ashguard; break;
		default: break;
		}
	}

	IroncladPresent = Ironclad;
	AshguardPresent = Ashguard;
}

// ---------------------------------------------------------------- Capture

float ABFSector::GetCaptureRatePerSecond(int32 AttackerCount) const
{
	const float BaseTime = SectorData ? SectorData->BaseCaptureTime : FallbackCaptureTime;
	const float PerPlayer = SectorData ? SectorData->PerPlayerRateBonus : 0.35f;
	const float MaxMultiplier = SectorData ? SectorData->MaxCaptureRateMultiplier : 3.5f;

	// Diminishing returns: sqrt keeps a full squad meaningful without letting 20 players flip instantly.
	const float Multiplier = FMath::Clamp(1.f + PerPlayer * FMath::Sqrt(FMath::Max(0.f, AttackerCount - 1.f)), 1.f, MaxMultiplier);
	return (1.f / FMath::Max(BaseTime, 1.f)) * Multiplier;
}

void ABFSector::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!HasAuthority())
	{
		return;
	}

	RecountOccupants();

	if (!bCaptureEnabled)
	{
		if (SectorState != EBFSectorState::Dormant)
		{
			SectorState = EBFSectorState::Dormant;
			OnStateChanged.Broadcast(this, SectorState);
		}
		return;
	}

	UpdateCapture(DeltaSeconds);

	// Ticket bleed for the side holding this ground.
	if (SectorData && OwningTeam != EBFTeam::Neutral && SectorData->TicketBleedPerSecond > 0.f)
	{
		if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
		{
			GS->DrainTickets(BFTeam::Opposite(OwningTeam), SectorData->TicketBleedPerSecond * DeltaSeconds);
		}
	}
}

void ABFSector::UpdateCapture(float DeltaSeconds)
{
	const bool bBothPresent = IroncladPresent > 0 && AshguardPresent > 0;
	EBFSectorState NewState = SectorState;

	if (bBothPresent)
	{
		// Contested: progress freezes entirely. No stalemate-breaking majority rule -
		// you have to actually clear the zone.
		NewState = EBFSectorState::Contested;
	}
	else
	{
		const EBFTeam Attacker = IroncladPresent > 0 ? EBFTeam::Ironclad
			: (AshguardPresent > 0 ? EBFTeam::Ashguard : EBFTeam::Neutral);

		if (Attacker == EBFTeam::Neutral)
		{
			// Nobody here: progress decays back toward the current owner.
			const float OwnerSign = BFTeam::Sign(OwningTeam);
			if (!FMath::IsNearlyEqual(CaptureProgress, OwnerSign, 0.001f))
			{
				const float DecayRate = GetCaptureRatePerSecond(1) * (SectorData ? SectorData->DecayRateMultiplier : 0.5f);
				CaptureProgress = FMath::FInterpConstantTo(CaptureProgress, OwnerSign, DeltaSeconds, DecayRate);
			}
			NewState = (OwningTeam == EBFTeam::Neutral) ? EBFSectorState::Capturing : EBFSectorState::Secured;
		}
		else if (Attacker == OwningTeam)
		{
			// Owner reinforcing: push progress back to full control.
			const float OwnerSign = BFTeam::Sign(OwningTeam);
			if (!FMath::IsNearlyEqual(CaptureProgress, OwnerSign, 0.001f))
			{
				const float Rate = GetCaptureRatePerSecond(GetPresentCount(Attacker));
				CaptureProgress = FMath::FInterpConstantTo(CaptureProgress, OwnerSign, DeltaSeconds, Rate);
				NewState = EBFSectorState::Capturing;
			}
			else
			{
				NewState = EBFSectorState::Secured;
			}
		}
		else
		{
			// Attackers alone in the zone: drive progress toward their sign.
			const float TargetSign = BFTeam::Sign(Attacker);
			const float Rate = GetCaptureRatePerSecond(GetPresentCount(Attacker));
			const float Before = CaptureProgress;
			CaptureProgress = FMath::Clamp(CaptureProgress + TargetSign * Rate * DeltaSeconds, -1.f, 1.f);
			NewState = EBFSectorState::Capturing;

			// Award capture score while actually pushing the bar.
			ScoreAccumulator += FMath::Abs(CaptureProgress - Before);
			if (ScoreAccumulator >= 0.1f)
			{
				const int32 Points = FMath::FloorToInt(ScoreAccumulator * (SectorData ? SectorData->CaptureScore : 250) * 0.1f);
				ScoreAccumulator = 0.f;
				for (const TWeakObjectPtr<ABFCharacter>& Weak : Occupants)
				{
					const ABFCharacter* Char = Weak.Get();
					if (Char && Char->GetTeam() == Attacker)
					{
						if (ABFPlayerState* PS = Char->GetPlayerState<ABFPlayerState>())
						{
							PS->AddScore(Points);
						}
					}
				}
			}

			// Flip once the bar crosses the attacker's side of neutral.
			const EBFTeam NewOwnerFromProgress = BFTeam::FromSign(CaptureProgress);
			if (FMath::Abs(CaptureProgress) >= 1.f - KINDA_SMALL_NUMBER && NewOwnerFromProgress == Attacker && OwningTeam != Attacker)
			{
				ApplyOwnershipChange(Attacker);
				NewState = EBFSectorState::Secured;
			}
			else if (OwningTeam != EBFTeam::Neutral && NewOwnerFromProgress != OwningTeam && NewOwnerFromProgress != EBFTeam::Neutral)
			{
				// The bar crossed zero: the defender has effectively lost the point.
				NewState = EBFSectorState::Falling;
			}
		}
	}

	if (NewState != SectorState)
	{
		SectorState = NewState;
		OnStateChanged.Broadcast(this, SectorState);
	}
}

void ABFSector::ApplyOwnershipChange(EBFTeam NewOwner)
{
	if (OwningTeam == NewOwner)
	{
		return;
	}

	PreviousOwner = OwningTeam;
	OwningTeam = NewOwner;
	CaptureProgress = BFTeam::Sign(NewOwner);

	RefreshSpawnPoints();

	// Defensive props switch sides and get repaired for the new holder.
	for (const TObjectPtr<ABFDestructibleActor>& Prop : DefensiveObjects)
	{
		if (Prop)
		{
			Prop->SetOwningTeam(NewOwner);
			Prop->RepairFully();
		}
	}

	// Objectives inside this sector re-evaluate for the new owner.
	for (const TObjectPtr<ABFObjective>& Objective : Objectives)
	{
		if (Objective)
		{
			Objective->OnSectorOwnershipChanged(NewOwner);
		}
	}

	BF_LOG(LogBFFrontline, Log, TEXT("Sector %s captured: %d -> %d"),
		*GetSectorId().ToString(), static_cast<int32>(PreviousOwner), static_cast<int32>(NewOwner));

	OnOwnerChanged.Broadcast(this, NewOwner, PreviousOwner);
	OnRep_OwningTeam();
}

void ABFSector::SetOwningTeam(EBFTeam NewTeam, bool bResetProgress)
{
	if (!HasAuthority())
	{
		return;
	}

	PreviousOwner = OwningTeam;
	OwningTeam = NewTeam;
	if (bResetProgress)
	{
		CaptureProgress = BFTeam::Sign(NewTeam);
	}
	RefreshSpawnPoints();

	if (PreviousOwner != NewTeam)
	{
		OnOwnerChanged.Broadcast(this, NewTeam, PreviousOwner);
	}
	OnRep_OwningTeam();
}

void ABFSector::SetCaptureEnabled(bool bEnabled)
{
	if (!HasAuthority() || bCaptureEnabled == bEnabled)
	{
		return;
	}

	bCaptureEnabled = bEnabled;
	SectorState = bEnabled ? EBFSectorState::Secured : EBFSectorState::Dormant;
	RefreshSpawnPoints();
	OnStateChanged.Broadcast(this, SectorState);
}

void ABFSector::SetIsFrontline(bool bNewFrontline)
{
	if (HasAuthority())
	{
		bIsFrontline = bNewFrontline;
	}
}

void ABFSector::RefreshSpawnPoints()
{
	for (const TObjectPtr<ABFSpawnPoint>& Spawn : SpawnPoints)
	{
		if (!Spawn)
		{
			continue;
		}

		Spawn->SetOwningTeam(OwningTeam);
		// A sector spawn only works for the current owner, and only while the sector is live.
		const bool bShouldEnable = bCaptureEnabled && OwningTeam != EBFTeam::Neutral && SectorState != EBFSectorState::Falling;
		Spawn->SetEnabled(bShouldEnable);
	}
}

void ABFSector::RegisterSpawnPoint(ABFSpawnPoint* SpawnPoint)
{
	if (SpawnPoint)
	{
		SpawnPoints.AddUnique(SpawnPoint);
		SpawnPoint->SetOwningTeam(OwningTeam);
	}
}

void ABFSector::RegisterObjective(ABFObjective* Objective)
{
	if (Objective)
	{
		Objectives.AddUnique(Objective);
	}
}

void ABFSector::OnRep_OwningTeam()
{
	OnOwnerChanged.Broadcast(this, OwningTeam, PreviousOwner);
}

void ABFSector::OnRep_SectorState()
{
	OnStateChanged.Broadcast(this, SectorState);
}
