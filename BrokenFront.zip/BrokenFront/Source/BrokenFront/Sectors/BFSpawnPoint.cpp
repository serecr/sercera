#include "Sectors/BFSpawnPoint.h"

#include "Characters/BFCharacter.h"
#include "Components/ArrowComponent.h"
#include "Components/SceneComponent.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/PlayerState.h"
#include "Gameplay/BFPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "Sectors/BFSector.h"

ABFSpawnPoint::ABFSpawnPoint()
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = true;
	SetReplicateMovement(false);
	NetUpdateFrequency = 2.f; // state changes rarely

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

#if WITH_EDITORONLY_DATA
	ArrowComponent = CreateDefaultSubobject<UArrowComponent>(TEXT("Arrow"));
	ArrowComponent->SetupAttachment(Root);
	ArrowComponent->ArrowSize = 1.4f;
#endif
}

void ABFSpawnPoint::BeginPlay()
{
	Super::BeginPlay();

	if (HasAuthority())
	{
		OwningTeam = InitialTeam;

		if (OwningSector)
		{
			OwningSector->RegisterSpawnPoint(this);
		}
	}
}

void ABFSpawnPoint::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFSpawnPoint, OwningTeam);
	DOREPLIFETIME(ABFSpawnPoint, bEnabled);
}

void ABFSpawnPoint::SetEnabled(bool bNewEnabled)
{
	if (HasAuthority())
	{
		bEnabled = bNewEnabled;
	}
}

void ABFSpawnPoint::SetOwningTeam(EBFTeam NewTeam)
{
	if (HasAuthority())
	{
		OwningTeam = NewTeam;
	}
}

bool ABFSpawnPoint::IsSafeToSpawn(float SafeRadius) const
{
	if (!bEnabled)
	{
		return false;
	}

	// Main bases are always safe - they are behind the last defensive line.
	if (SpawnKind == EBFSpawnKind::MainBase)
	{
		return true;
	}

	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		const ABFCharacter* Char = *It;
		if (!Char || Char->GetTeam() == OwningTeam || Char->GetTeam() == EBFTeam::Neutral)
		{
			continue;
		}

		if (const UBFHealthComponent* Health = Char->GetHealthComponent())
		{
			if (!Health->IsAlive())
			{
				continue;
			}
		}

		if (FVector::DistSquared(Char->GetActorLocation(), GetActorLocation()) < FMath::Square(SafeRadius))
		{
			return false;
		}
	}

	return true;
}

float ABFSpawnPoint::ScoreForPlayer(const APlayerController* Requester, const FVector& PreferredLocation) const
{
	if (!bEnabled)
	{
		return -1.f;
	}

	float Score = PriorityBias;

	switch (SpawnKind)
	{
	case EBFSpawnKind::Squad:          Score += 300.f; break;
	case EBFSpawnKind::CapturedSector: Score += 200.f; break;
	case EBFSpawnKind::MainBase:       Score += 50.f; break;
	case EBFSpawnKind::Fallback:       Score += 1.f; break;
	}

	// Closer to where the player wants to be is better, but never dominant.
	if (!PreferredLocation.IsNearlyZero())
	{
		const float DistanceKm = FVector::Dist(PreferredLocation, GetActorLocation()) / 100000.f;
		Score -= DistanceKm * 40.f;
	}

	if (!IsSafeToSpawn())
	{
		Score -= 500.f;
	}

	return Score;
}
