#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFSector.generated.h"

class UBoxComponent;
class UBFSectorDataAsset;
class ABFSpawnPoint;
class ABFObjective;
class ABFDestructibleActor;
class ABFCharacter;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FBFSectorOwnerChanged, ABFSector*, Sector, EBFTeam, NewOwner, EBFTeam, OldOwner);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBFSectorStateChanged, ABFSector*, Sector, EBFSectorState, NewState);

/**
 * One rung of the frontline ladder. Owns its capture volume, its spawns, its
 * objectives and the defensive props inside it. Capture is gradual and contested
 * whenever both teams are present, never instant.
 */
UCLASS()
class BROKENFRONT_API ABFSector : public AActor
{
	GENERATED_BODY()

public:
	ABFSector();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Sector") FBFSectorOwnerChanged OnOwnerChanged;
	UPROPERTY(BlueprintAssignable, Category = "Sector") FBFSectorStateChanged OnStateChanged;

	// ---------- Queries ----------
	UFUNCTION(BlueprintPure, Category = "Sector") FName GetSectorId() const;
	UFUNCTION(BlueprintPure, Category = "Sector") FText GetDisplayName() const;
	UFUNCTION(BlueprintPure, Category = "Sector") int32 GetLineIndex() const;
	UFUNCTION(BlueprintPure, Category = "Sector") EBFTeam GetOwningTeam() const { return OwningTeam; }
	UFUNCTION(BlueprintPure, Category = "Sector") EBFSectorState GetSectorState() const { return SectorState; }
	UFUNCTION(BlueprintPure, Category = "Sector") bool IsActive() const { return bCaptureEnabled; }
	UFUNCTION(BlueprintPure, Category = "Sector") bool IsHomeBase() const;
	UFUNCTION(BlueprintPure, Category = "Sector") UBFSectorDataAsset* GetSectorData() const { return SectorData; }
	UFUNCTION(BlueprintPure, Category = "Sector") FVector GetCapturePointLocation() const;

	/** Signed progress: -1 fully Ironclad, +1 fully Ashguard, 0 neutral/even. */
	UFUNCTION(BlueprintPure, Category = "Sector") float GetSignedProgress() const { return CaptureProgress; }

	/** 0..1 progress of whichever team is currently pushing. */
	UFUNCTION(BlueprintPure, Category = "Sector") float GetProgressForTeam(EBFTeam Team) const;

	UFUNCTION(BlueprintPure, Category = "Sector") int32 GetPresentCount(EBFTeam Team) const;

	UFUNCTION(BlueprintPure, Category = "Sector")
	FBFSectorSnapshot BuildSnapshot() const;

	// ---------- Server control (frontline manager drives these) ----------
	/** Enables/disables capture. A dormant sector is scenery. */
	void SetCaptureEnabled(bool bEnabled);

	/** Hard set of ownership, used at match start and by admin/debug commands. */
	void SetOwningTeam(EBFTeam NewTeam, bool bResetProgress = true);

	/** True when this sector sits directly between the two front lines. */
	void SetIsFrontline(bool bNewFrontline);
	UFUNCTION(BlueprintPure, Category = "Sector") bool IsFrontline() const { return bIsFrontline; }

	void RegisterSpawnPoint(ABFSpawnPoint* SpawnPoint);
	void RegisterObjective(ABFObjective* Objective);

	UFUNCTION(BlueprintPure, Category = "Sector") const TArray<ABFSpawnPoint*>& GetSpawnPoints() const { return SpawnPoints; }
	UFUNCTION(BlueprintPure, Category = "Sector") const TArray<ABFObjective*>& GetObjectives() const { return Objectives; }

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBoxComponent> CaptureVolume;

	/** Where the flag/marker sits. Defaults to the actor origin. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> CapturePointMarker;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sector")
	TObjectPtr<UBFSectorDataAsset> SectorData;

	/** Fallbacks used when no data asset is assigned, so a sector always works. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sector|Fallback") FName FallbackSectorId = TEXT("SECTOR");
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sector|Fallback") int32 FallbackLineIndex = 0;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Sector|Fallback") float FallbackCaptureTime = 90.f;

	/** Defensive props inside the sector; re-armed when ownership flips. */
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly, Category = "Sector")
	TArray<TObjectPtr<ABFDestructibleActor>> DefensiveObjects;

	/** Supply crates / ammo points that only work for the owner. */
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly, Category = "Sector")
	TArray<TObjectPtr<AActor>> SupplyPoints;

	// ---------- Replicated state ----------
	UPROPERTY(ReplicatedUsing = OnRep_OwningTeam, BlueprintReadOnly, Category = "State")
	EBFTeam OwningTeam = EBFTeam::Neutral;

	UPROPERTY(ReplicatedUsing = OnRep_SectorState, BlueprintReadOnly, Category = "State")
	EBFSectorState SectorState = EBFSectorState::Dormant;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float CaptureProgress = 0.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	bool bCaptureEnabled = false;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	bool bIsFrontline = false;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	int32 IroncladPresent = 0;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	int32 AshguardPresent = 0;

	UFUNCTION() void OnRep_OwningTeam();
	UFUNCTION() void OnRep_SectorState();

	UFUNCTION() void OnCaptureVolumeBeginOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& Sweep);
	UFUNCTION() void OnCaptureVolumeEndOverlap(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
		UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

private:
	UPROPERTY() TArray<TObjectPtr<ABFSpawnPoint>> SpawnPoints;
	UPROPERTY() TArray<TObjectPtr<ABFObjective>> Objectives;

	/** Live occupancy, rebuilt from overlaps. */
	TArray<TWeakObjectPtr<ABFCharacter>> Occupants;

	EBFTeam PreviousOwner = EBFTeam::Neutral;
	float ScoreAccumulator = 0.f;

	void RecountOccupants();
	void UpdateCapture(float DeltaSeconds);
	void ApplyOwnershipChange(EBFTeam NewOwner);
	void RefreshSpawnPoints();
	float GetCaptureRatePerSecond(int32 AttackerCount) const;
};
