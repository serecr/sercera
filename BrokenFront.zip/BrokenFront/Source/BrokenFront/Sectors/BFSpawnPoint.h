#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFSpawnPoint.generated.h"

class UArrowComponent;
class UBillboardComponent;
class ABFSector;

/**
 * A deployment location. Enabled/disabled by its owning sector: when the front
 * moves, every spawn tied to a lost sector goes dark on the same frame.
 */
UCLASS()
class BROKENFRONT_API ABFSpawnPoint : public AActor
{
	GENERATED_BODY()

public:
	ABFSpawnPoint();

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void BeginPlay() override;

	UFUNCTION(BlueprintPure, Category = "Spawn") EBFSpawnKind GetSpawnKind() const { return SpawnKind; }
	UFUNCTION(BlueprintPure, Category = "Spawn") EBFTeam GetOwningTeam() const { return OwningTeam; }
	UFUNCTION(BlueprintPure, Category = "Spawn") bool IsEnabled() const { return bEnabled; }
	UFUNCTION(BlueprintPure, Category = "Spawn") ABFSector* GetOwningSector() const { return OwningSector; }

	/** Server: driven by the sector / frontline manager. */
	void SetEnabled(bool bNewEnabled);
	void SetOwningTeam(EBFTeam NewTeam);

	/** True when nothing hostile is standing on top of the spawn. */
	UFUNCTION(BlueprintPure, Category = "Spawn")
	bool IsSafeToSpawn(float SafeRadius = 1200.f) const;

	/** Score used by the spawn manager to pick the best point. Higher wins. */
	UFUNCTION(BlueprintPure, Category = "Spawn")
	float ScoreForPlayer(const APlayerController* Requester, const FVector& PreferredLocation) const;

protected:
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
	EBFSpawnKind SpawnKind = EBFSpawnKind::CapturedSector;

	/** Set in the level for base/fallback spawns; sector spawns inherit from the sector. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
	EBFTeam InitialTeam = EBFTeam::Neutral;

	/** Leave empty for base spawns. */
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly, Category = "Spawn")
	TObjectPtr<ABFSector> OwningSector;

	/** Spawns further forward are preferred; this biases the choice. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Spawn")
	float PriorityBias = 0.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Spawn")
	EBFTeam OwningTeam = EBFTeam::Neutral;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Spawn")
	bool bEnabled = true;

#if WITH_EDITORONLY_DATA
	UPROPERTY() TObjectPtr<UArrowComponent> ArrowComponent;
#endif
};
