#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFObjective.generated.h"

class USphereComponent;
class ABFSector;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBFObjectiveStatusChanged, ABFObjective*, Objective, EBFObjectiveStatus, NewStatus);

/**
 * A task attached to a sector. The objective manager activates and deactivates
 * these as the frontline moves, so the task list a player sees is always about
 * ground that is actually in play.
 */
UCLASS()
class BROKENFRONT_API ABFObjective : public AActor
{
	GENERATED_BODY()

public:
	ABFObjective();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Objective") FBFObjectiveStatusChanged OnStatusChanged;

	UFUNCTION(BlueprintPure, Category = "Objective") EBFObjectiveType GetObjectiveType() const { return ObjectiveType; }
	UFUNCTION(BlueprintPure, Category = "Objective") EBFObjectiveStatus GetStatus() const { return Status; }
	UFUNCTION(BlueprintPure, Category = "Objective") EBFTeam GetAssignedTeam() const { return AssignedTeam; }
	UFUNCTION(BlueprintPure, Category = "Objective") float GetProgress() const { return Progress; }
	UFUNCTION(BlueprintPure, Category = "Objective") ABFSector* GetSector() const { return LinkedSector; }
	UFUNCTION(BlueprintPure, Category = "Objective") float GetRadius() const;

	/** HUD line, e.g. "Hold Main Trench - 0:45". */
	UFUNCTION(BlueprintPure, Category = "Objective") FText GetObjectiveText() const;

	/** Server: called by the objective manager. */
	void ActivateFor(EBFTeam Team);
	void Deactivate();

	/** Server: called by the owning sector when it changes hands. */
	void OnSectorOwnershipChanged(EBFTeam NewOwner);

	/** Server: external completion trigger, e.g. a destroy target blowing up. */
	UFUNCTION(BlueprintCallable, Category = "Objective")
	void CompleteObjective(bool bSuccess);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USphereComponent> ObjectiveArea;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Objective")
	EBFObjectiveType ObjectiveType = EBFObjectiveType::CaptureSector;

	UPROPERTY(EditInstanceOnly, BlueprintReadOnly, Category = "Objective")
	TObjectPtr<ABFSector> LinkedSector;

	/** For Destroy / Protect objectives: the actor that matters. */
	UPROPERTY(EditInstanceOnly, BlueprintReadOnly, Category = "Objective")
	TObjectPtr<AActor> TargetActor;

	/** Seconds of presence required for Hold / Recon objectives. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Objective", meta = (ClampMin = "1.0"))
	float RequiredDuration = 90.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Objective")
	int32 CompletionScore = 400;

	/** Only the Commander can hand this one out manually. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Objective")
	bool bCommanderAssignable = false;

	UPROPERTY(ReplicatedUsing = OnRep_Status, BlueprintReadOnly, Category = "State")
	EBFObjectiveStatus Status = EBFObjectiveStatus::Inactive;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	EBFTeam AssignedTeam = EBFTeam::Neutral;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float Progress = 0.f;

	UFUNCTION() void OnRep_Status();

private:
	float ElapsedHoldTime = 0.f;

	void TickHoldStyleObjective(float DeltaSeconds);
	void AwardTeamScore() const;
};
