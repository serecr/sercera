#include "Equipment/BFEquipmentVariants.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Equipment/BFReconDrone.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerController.h"
#include "Gameplay/BFPlayerController.h"
#include "Gameplay/BFPlayerState.h"
#include "Systems/BFDestructibleActor.h"
#include "Vehicles/BFVehicleBase.h"
#include "Weapons/BFInventoryComponent.h"

// ------------------------------------------------------------------ Medical kit

ABFMedicalKit::ABFMedicalKit()
{
	DisplayName = NSLOCTEXT("BrokenFront", "MedKit", "Medical Kit");
	MaxCharges = 4;
	UseCooldown = 1.5f;
	UseRange = 220.f;
}

bool ABFMedicalKit::ServerPerformUse_Internal()
{
	if (!OwningCharacter)
	{
		return false;
	}

	ABFCharacter* Target = Cast<ABFCharacter>(TraceUseTarget());

	// No ally in the crosshair: patch yourself up.
	const bool bSelfUse = (Target == nullptr);
	if (bSelfUse)
	{
		Target = OwningCharacter;
	}

	if (Target->GetTeam() != OwningCharacter->GetTeam())
	{
		return false;
	}

	UBFHealthComponent* Health = Target->GetHealthComponent();
	if (!Health)
	{
		return false;
	}

	if (Health->IsDowned())
	{
		if (Health->Revive(OwningCharacter, ReviveHealthFraction))
		{
			if (ABFPlayerState* PS = OwningCharacter->GetPlayerState<ABFPlayerState>())
			{
				PS->RegisterRevive();
			}
			return true;
		}
		return false;
	}

	if (Health->GetHealthPercent() >= 1.f)
	{
		return false;
	}

	Health->ApplyHealthDelta(HealAmount * (bSelfUse ? SelfHealScale : 1.f), OwningCharacter);

	if (!bSelfUse)
	{
		if (ABFPlayerState* PS = OwningCharacter->GetPlayerState<ABFPlayerState>())
		{
			PS->AddScore(40);
		}
	}

	return true;
}

// ------------------------------------------------------------------ Repair tool

ABFRepairTool::ABFRepairTool()
{
	DisplayName = NSLOCTEXT("BrokenFront", "RepairTool", "Repair Tool");
	MaxCharges = 6;
	UseCooldown = 1.f;
	UseRange = 260.f;
}

bool ABFRepairTool::ServerPerformUse_Internal()
{
	AActor* Target = TraceUseTarget();
	if (!Target || !OwningCharacter)
	{
		return false;
	}

	if (ABFDestructibleActor* Destructible = Cast<ABFDestructibleActor>(Target))
	{
		return Destructible->Repair(RepairAmount, OwningCharacter) > 0.f;
	}

	if (ABFVehicleBase* Vehicle = Cast<ABFVehicleBase>(Target))
	{
		if (Vehicle->GetTeam() == OwningCharacter->GetTeam() || Vehicle->GetTeam() == EBFTeam::Neutral)
		{
			return Vehicle->RepairVehicle(RepairAmount) > 0.f;
		}
	}

	return false;
}

// ------------------------------------------------------------------ Ammo bag

ABFAmmoBag::ABFAmmoBag()
{
	DisplayName = NSLOCTEXT("BrokenFront", "AmmoBag", "Ammo Bag");
	MaxCharges = 3;
	UseCooldown = 2.f;
}

bool ABFAmmoBag::ServerPerformUse_Internal()
{
	if (!OwningCharacter)
	{
		return false;
	}

	const EBFTeam Team = OwningCharacter->GetTeam();
	const FVector Origin = OwningCharacter->GetActorLocation();
	const float RadiusSq = FMath::Square(ResupplyRadius);

	int32 Supplied = 0;

	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		ABFCharacter* Ally = *It;
		if (!Ally || Ally->GetTeam() != Team)
		{
			continue;
		}

		if (FVector::DistSquared(Ally->GetActorLocation(), Origin) > RadiusSq)
		{
			continue;
		}

		if (UBFInventoryComponent* Inventory = Ally->GetInventory())
		{
			if (Inventory->ResupplyAmmo(MagazinesPerUse))
			{
				++Supplied;
			}
		}
	}

	if (Supplied > 0)
	{
		if (ABFPlayerState* PS = OwningCharacter->GetPlayerState<ABFPlayerState>())
		{
			PS->AddScore(20 * Supplied);
		}
		return true;
	}

	return false;
}

// ------------------------------------------------------------------ Drone launcher

ABFDroneController::ABFDroneController()
{
	DisplayName = NSLOCTEXT("BrokenFront", "DroneKit", "Recon Drone");
	MaxCharges = 2;
	UseCooldown = 2.f;
}

void ABFDroneController::PrimaryUse()
{
	// Pressing use again while the drone is up recalls the camera instead of
	// burning another charge.
	if (ActiveDrone && OwningCharacter)
	{
		if (ABFPlayerController* PC = Cast<ABFPlayerController>(OwningCharacter->GetController()))
		{
			if (PC->IsInDroneView())
			{
				PC->ExitDroneView();
				return;
			}

			PC->EnterDroneView(ActiveDrone);
			return;
		}
	}

	Super::PrimaryUse();
}

bool ABFDroneController::ServerPerformUse_Internal()
{
	if (!DroneClass || !OwningCharacter)
	{
		return false;
	}

	// Launch it just above and in front of the scout.
	const FVector SpawnLocation = OwningCharacter->GetActorLocation()
		+ OwningCharacter->GetActorForwardVector() * 150.f
		+ FVector(0.f, 0.f, 220.f);

	FActorSpawnParameters Params;
	Params.Owner = OwningCharacter;
	Params.Instigator = OwningCharacter;
	Params.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AdjustIfPossibleButAlwaysSpawn;

	ActiveDrone = GetWorld()->SpawnActor<ABFReconDrone>(DroneClass, SpawnLocation,
		OwningCharacter->GetActorRotation(), Params);

	if (!ActiveDrone)
	{
		return false;
	}

	ActiveDrone->InitializeDrone(OwningCharacter);

	if (ABFPlayerController* PC = Cast<ABFPlayerController>(OwningCharacter->GetController()))
	{
		PC->EnterDroneView(ActiveDrone);
	}

	return true;
}
