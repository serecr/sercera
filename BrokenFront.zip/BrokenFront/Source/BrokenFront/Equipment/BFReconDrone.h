#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Pawn.h"
#include "Core/BFTypes.h"
#include "BFReconDrone.generated.h"

class UCameraComponent;
class UStaticMeshComponent;
class UFloatingPawnMovement;
class USphereComponent;
class UAudioComponent;
class ABFCharacter;
class ABFPlayerController;

/**
 * Small observation drone. Deliberately not a weapon: it has no damage output at
 * all. It flies on a battery, streams a camera feed, and marks enemies it sees
 * for the owner's squad. Losing it costs you a charge, not a life.
 */
UCLASS()
class BROKENFRONT_API ABFReconDrone : public APawn
{
	GENERATED_BODY()

public:
	ABFReconDrone();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;

	/** Server: bind to the operator. */
	void InitializeDrone(ABFCharacter* Operator);

	/** Local: the controller took or released the camera. */
	void SetControllingPlayer(ABFPlayerController* Controller);

	UFUNCTION(BlueprintPure, Category = "Drone") float GetBatteryPercent() const { return MaxFlightTime > 0.f ? BatteryRemaining / MaxFlightTime : 0.f; }
	UFUNCTION(BlueprintPure, Category = "Drone") EBFTeam GetTeam() const;
	UFUNCTION(BlueprintPure, Category = "Drone") const TArray<AActor*>& GetSpottedActors() const { return SpottedActors; }

	/** Server: battery dead or shot down. */
	UFUNCTION(BlueprintCallable, Category = "Drone")
	void Recall(bool bBatteryDead);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<USphereComponent> Collision;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UStaticMeshComponent> DroneMesh;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UCameraComponent> DroneCamera;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UFloatingPawnMovement> Movement;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UAudioComponent> RotorAudio;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "5.0"))
	float MaxFlightTime = 45.f;

	/** Metres the drone may stray from its operator before the link drops. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float MaxLinkDistance = 12000.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float MaxAltitude = 4000.f;

	/** How often the drone re-scans for enemies below it. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float SpotInterval = 1.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float SpotRange = 6000.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") float BatteryRemaining = 45.f;
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") TObjectPtr<ABFCharacter> OperatorCharacter;

	/** Enemies currently visible to the drone; replicated to the operator only. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") TArray<AActor*> SpottedActors;

	void UpdateSpotting();
	void EnforceFlightEnvelope();

private:
	float SpotTimer = 0.f;
	UPROPERTY() TObjectPtr<ABFPlayerController> ViewingController;
};
