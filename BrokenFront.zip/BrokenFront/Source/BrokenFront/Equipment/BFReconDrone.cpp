#include "Equipment/BFReconDrone.h"

#include "Camera/CameraComponent.h"
#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Components/AudioComponent.h"
#include "Components/SphereComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Core/BFLog.h"
#include "EngineUtils.h"
#include "GameFramework/FloatingPawnMovement.h"
#include "Gameplay/BFPlayerController.h"
#include "Net/UnrealNetwork.h"

ABFReconDrone::ABFReconDrone()
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;
	SetReplicateMovement(true);
	NetUpdateFrequency = 30.f;

	Collision = CreateDefaultSubobject<USphereComponent>(TEXT("Collision"));
	Collision->InitSphereRadius(28.f);
	Collision->SetCollisionObjectType(ECC_Pawn);
	Collision->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	Collision->SetCollisionResponseToAllChannels(ECR_Block);
	Collision->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
	SetRootComponent(Collision);

	DroneMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("DroneMesh"));
	DroneMesh->SetupAttachment(Collision);
	DroneMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);

	DroneCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("DroneCamera"));
	DroneCamera->SetupAttachment(Collision);
	DroneCamera->SetRelativeLocation(FVector(20.f, 0.f, -10.f));
	DroneCamera->SetRelativeRotation(FRotator(-25.f, 0.f, 0.f));
	DroneCamera->FieldOfView = 75.f;

	Movement = CreateDefaultSubobject<UFloatingPawnMovement>(TEXT("Movement"));
	Movement->MaxSpeed = 900.f;
	Movement->Acceleration = 1400.f;
	Movement->Deceleration = 1800.f;

	RotorAudio = CreateDefaultSubobject<UAudioComponent>(TEXT("RotorAudio"));
	RotorAudio->SetupAttachment(Collision);
	RotorAudio->bAutoActivate = true;
}

void ABFReconDrone::BeginPlay()
{
	Super::BeginPlay();
	BatteryRemaining = MaxFlightTime;
}

void ABFReconDrone::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFReconDrone, BatteryRemaining);
	DOREPLIFETIME(ABFReconDrone, OperatorCharacter);
	DOREPLIFETIME_CONDITION(ABFReconDrone, SpottedActors, COND_OwnerOnly);
}

void ABFReconDrone::InitializeDrone(ABFCharacter* Operator)
{
	if (!HasAuthority())
	{
		return;
	}

	OperatorCharacter = Operator;
	SetOwner(Operator);
	BatteryRemaining = MaxFlightTime;

	if (Operator)
	{
		Collision->IgnoreActorWhenMoving(Operator, true);
	}
}

EBFTeam ABFReconDrone::GetTeam() const
{
	return OperatorCharacter ? OperatorCharacter->GetTeam() : EBFTeam::Neutral;
}

void ABFReconDrone::SetControllingPlayer(ABFPlayerController* Controller)
{
	ViewingController = Controller;

	// Only take direct input while the player is actually looking through it.
	if (Controller)
	{
		EnableInput(Controller);
	}
	else if (ViewingController)
	{
		DisableInput(ViewingController);
	}
}

void ABFReconDrone::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);
	// Drone piloting is bound through the same Enhanced Input context as the
	// soldier, remapped on the drone Blueprint. Nothing to do in C++.
}

void ABFReconDrone::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!HasAuthority())
	{
		return;
	}

	BatteryRemaining = FMath::Max(0.f, BatteryRemaining - DeltaSeconds);
	if (BatteryRemaining <= 0.f)
	{
		Recall(true);
		return;
	}

	// The link drops if the operator dies or strays too far.
	if (!OperatorCharacter)
	{
		Recall(false);
		return;
	}

	if (const UBFHealthComponent* Health = OperatorCharacter->GetHealthComponent())
	{
		if (!Health->IsAlive())
		{
			Recall(false);
			return;
		}
	}

	if (FVector::DistSquared(GetActorLocation(), OperatorCharacter->GetActorLocation()) > FMath::Square(MaxLinkDistance))
	{
		Recall(false);
		return;
	}

	EnforceFlightEnvelope();

	SpotTimer += DeltaSeconds;
	if (SpotTimer >= SpotInterval)
	{
		SpotTimer = 0.f;
		UpdateSpotting();
	}
}

void ABFReconDrone::EnforceFlightEnvelope()
{
	// Simple ceiling so the drone cannot become a satellite.
	FVector Location = GetActorLocation();
	const FVector Start = Location;
	const FVector End = Location - FVector(0.f, 0.f, MaxAltitude * 1.5f);

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFDroneAltitude), false, this);
	FHitResult Hit;
	if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldStatic, Params))
	{
		const float Altitude = Location.Z - Hit.ImpactPoint.Z;
		if (Altitude > MaxAltitude)
		{
			Location.Z = Hit.ImpactPoint.Z + MaxAltitude;
			SetActorLocation(Location);
		}
	}
}

void ABFReconDrone::UpdateSpotting()
{
	SpottedActors.Reset();

	const EBFTeam MyTeam = GetTeam();
	if (MyTeam == EBFTeam::Neutral)
	{
		return;
	}

	const FVector Origin = GetActorLocation();
	const float RangeSq = FMath::Square(SpotRange);

	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		ABFCharacter* Char = *It;
		if (!Char || Char->GetTeam() == MyTeam || Char->GetTeam() == EBFTeam::Neutral)
		{
			continue;
		}

		if (const UBFHealthComponent* Health = Char->GetHealthComponent())
		{
			if (!Health->IsAlive())
			{
				continue;
			}
		}

		if (FVector::DistSquared(Char->GetActorLocation(), Origin) > RangeSq)
		{
			continue;
		}

		// Line of sight required: a soldier under a bunker roof or dense canopy
		// stays hidden, which keeps trenches meaningful.
		FCollisionQueryParams Params(SCENE_QUERY_STAT(BFDroneSpot), false, this);
		Params.AddIgnoredActor(Char);
		if (GetWorld()->LineTraceTestByChannel(Origin, Char->GetActorLocation() + FVector(0.f, 0.f, 40.f), ECC_Visibility, Params))
		{
			continue;
		}

		SpottedActors.Add(Char);
	}
}

void ABFReconDrone::Recall(bool bBatteryDead)
{
	if (!HasAuthority())
	{
		return;
	}

	if (OperatorCharacter)
	{
		if (ABFPlayerController* PC = Cast<ABFPlayerController>(OperatorCharacter->GetController()))
		{
			PC->ExitDroneView();
		}
	}

	BF_LOG(LogBrokenFront, Verbose, TEXT("Drone recalled (battery dead: %d)"), bBatteryDead ? 1 : 0);
	Destroy();
}
