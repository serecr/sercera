#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFEquipmentBase.generated.h"

class ABFCharacter;
class USkeletalMeshComponent;

/**
 * Base for the third slot: medical kits, repair tools, ammo bags, binoculars,
 * the recon drone launcher. Charge-based rather than ammo-based.
 */
UCLASS(Abstract)
class BROKENFRONT_API ABFEquipmentBase : public AActor
{
	GENERATED_BODY()

public:
	ABFEquipmentBase();

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	/** Server: bind to the owner. */
	void InitializeEquipment(ABFCharacter* NewOwner);

	UFUNCTION(BlueprintCallable, Category = "Equipment") virtual void PrimaryUse();
	UFUNCTION(BlueprintCallable, Category = "Equipment") virtual void StopUse() {}

	void SetEquipmentActive(bool bActive);

	UFUNCTION(BlueprintPure, Category = "Equipment") int32 GetCharges() const { return Charges; }
	UFUNCTION(BlueprintPure, Category = "Equipment") int32 GetMaxCharges() const { return MaxCharges; }
	UFUNCTION(BlueprintPure, Category = "Equipment") bool HasCharges() const { return Charges > 0; }
	UFUNCTION(BlueprintPure, Category = "Equipment") FText GetDisplayName() const { return DisplayName; }

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USkeletalMeshComponent> EquipmentMesh;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") FText DisplayName;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "1")) int32 MaxCharges = 3;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "0.1")) float UseCooldown = 1.2f;
	/** Range the equipment reaches for targets (allies, structures). */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") float UseRange = 220.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") int32 Charges = 3;
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State") TObjectPtr<ABFCharacter> OwningCharacter;

	/** Server implementation. Return true to consume a charge. */
	virtual bool ServerPerformUse_Internal() { return false; }

	UFUNCTION(Server, Reliable) void ServerUse();

	/** Traces for whatever this equipment acts on. */
	AActor* TraceUseTarget() const;

	bool IsOnCooldown() const;

private:
	float LastUseTime = -100.f;
	bool bActiveEquipment = false;
};
