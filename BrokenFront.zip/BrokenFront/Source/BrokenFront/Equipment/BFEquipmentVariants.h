#pragma once

#include "CoreMinimal.h"
#include "Equipment/BFEquipmentBase.h"
#include "BFEquipmentVariants.generated.h"

class ABFReconDrone;

/** Medic kit: heals and revives allies. */
UCLASS()
class BROKENFRONT_API ABFMedicalKit : public ABFEquipmentBase
{
	GENERATED_BODY()

public:
	ABFMedicalKit();

protected:
	virtual bool ServerPerformUse_Internal() override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Medic") float HealAmount = 45.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Medic") float ReviveHealthFraction = 0.4f;
	/** Self-heal is allowed but weaker, so Medics still need each other. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Medic") float SelfHealScale = 0.5f;
};

/** Engineer repair tool: restores destructibles and vehicles. */
UCLASS()
class BROKENFRONT_API ABFRepairTool : public ABFEquipmentBase
{
	GENERATED_BODY()

public:
	ABFRepairTool();

protected:
	virtual bool ServerPerformUse_Internal() override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Engineer") float RepairAmount = 180.f;
};

/** Support ammo bag: refills magazines for nearby allies. */
UCLASS()
class BROKENFRONT_API ABFAmmoBag : public ABFEquipmentBase
{
	GENERATED_BODY()

public:
	ABFAmmoBag();

protected:
	virtual bool ServerPerformUse_Internal() override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Support") int32 MagazinesPerUse = 3;
	/** Everyone in this radius gets resupplied, not just the aimed-at ally. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Support") float ResupplyRadius = 500.f;
};

/** Scout drone launcher: deploys the recon drone and hands the camera to the player. */
UCLASS()
class BROKENFRONT_API ABFDroneController : public ABFEquipmentBase
{
	GENERATED_BODY()

public:
	ABFDroneController();

	virtual void PrimaryUse() override;

protected:
	virtual bool ServerPerformUse_Internal() override;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Scout")
	TSubclassOf<ABFReconDrone> DroneClass;

private:
	UPROPERTY() TObjectPtr<ABFReconDrone> ActiveDrone;
};
