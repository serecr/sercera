#include "Equipment/BFEquipmentBase.h"

#include "Characters/BFCharacter.h"
#include "Components/SkeletalMeshComponent.h"
#include "Net/UnrealNetwork.h"

ABFEquipmentBase::ABFEquipmentBase()
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = true;
	SetReplicateMovement(false);

	EquipmentMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("EquipmentMesh"));
	EquipmentMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	EquipmentMesh->CastShadow = false;
	SetRootComponent(EquipmentMesh);
}

void ABFEquipmentBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFEquipmentBase, Charges);
	DOREPLIFETIME(ABFEquipmentBase, OwningCharacter);
}

void ABFEquipmentBase::InitializeEquipment(ABFCharacter* NewOwner)
{
	if (!HasAuthority())
	{
		return;
	}

	OwningCharacter = NewOwner;
	SetOwner(NewOwner);
	Charges = MaxCharges;

	if (NewOwner)
	{
		const FAttachmentTransformRules Rules(EAttachmentRule::SnapToTarget, true);
		USkeletalMeshComponent* Target = NewOwner->IsLocallyControlled() ? NewOwner->GetArmsMesh() : NewOwner->GetMesh();
		AttachToComponent(Target, Rules, TEXT("WeaponSocket"));
	}
}

void ABFEquipmentBase::SetEquipmentActive(bool bActive)
{
	bActiveEquipment = bActive;
	SetActorHiddenInGame(!bActive);
}

bool ABFEquipmentBase::IsOnCooldown() const
{
	return (GetWorld()->GetTimeSeconds() - LastUseTime) < UseCooldown;
}

AActor* ABFEquipmentBase::TraceUseTarget() const
{
	if (!OwningCharacter)
	{
		return nullptr;
	}

	FVector Start;
	FRotator Rotation;
	OwningCharacter->GetAimTransform(Start, Rotation);
	const FVector End = Start + Rotation.Vector() * UseRange;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFEquipmentTrace), false, OwningCharacter);
	FHitResult Hit;
	if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, BF_TRACE_INTERACT, Params))
	{
		return Hit.GetActor();
	}

	// Fall back to a wider sphere so healing an ally does not demand pixel-perfect aim.
	if (GetWorld()->SweepSingleByChannel(Hit, Start, End, FQuat::Identity, ECC_Pawn,
		FCollisionShape::MakeSphere(45.f), Params))
	{
		return Hit.GetActor();
	}

	return nullptr;
}

void ABFEquipmentBase::PrimaryUse()
{
	if (!bActiveEquipment || Charges <= 0 || IsOnCooldown())
	{
		return;
	}

	LastUseTime = GetWorld()->GetTimeSeconds();

	if (HasAuthority())
	{
		ServerUse_Implementation();
	}
	else
	{
		ServerUse();
	}
}

void ABFEquipmentBase::ServerUse_Implementation()
{
	if (Charges <= 0)
	{
		return;
	}

	if (ServerPerformUse_Internal())
	{
		--Charges;
	}
}
