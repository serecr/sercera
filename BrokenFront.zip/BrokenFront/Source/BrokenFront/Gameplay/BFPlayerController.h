#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "Core/BFTypes.h"
#include "Data/BFLoadout.h"
#include "BFPlayerController.generated.h"

class UBFHUDWidget;
class UBFDeployWidget;
class UBFScoreboardWidget;
class ABFReconDrone;
class ABFObjective;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFDeployAvailable, bool, bAvailable);

/**
 * Owns the local player's UI, the deploy request path, and the temporary
 * view switch to a recon drone. Nothing here decides gameplay outcomes.
 */
UCLASS()
class BROKENFRONT_API ABFPlayerController : public APlayerController
{
	GENERATED_BODY()

public:
	ABFPlayerController();

	virtual void BeginPlay() override;
	virtual void SetupInputComponent() override;
	virtual void OnPossess(APawn* InPawn) override;
	virtual void OnUnPossess() override;

	UPROPERTY(BlueprintAssignable, Category = "Deploy") FBFDeployAvailable OnDeployAvailable;

	// ---------- Deploy ----------
	UFUNCTION(BlueprintCallable, Category = "Deploy")
	void RequestDeploy(EBFSpawnKind PreferredKind);

	UFUNCTION(Server, Reliable) void ServerRequestDeploy(EBFSpawnKind PreferredKind);
	UFUNCTION(Client, Reliable) void ClientNotifyDeployAvailable();

	UFUNCTION(BlueprintCallable, Category = "Deploy")
	void SubmitLoadout(const FBFLoadout& Loadout);

	UFUNCTION(Server, Reliable) void ServerRequestTeamChange(EBFTeam DesiredTeam);

	// ---------- Radio ----------
	UFUNCTION(BlueprintCallable, Category = "Radio")
	void SendRadioCommand(EBFRadioCommand Command, EBFRadioChannel Channel);

	// ---------- Drone ----------
	UFUNCTION(BlueprintCallable, Category = "Drone")
	void EnterDroneView(ABFReconDrone* Drone);

	UFUNCTION(BlueprintCallable, Category = "Drone")
	void ExitDroneView();

	UFUNCTION(BlueprintPure, Category = "Drone")
	bool IsInDroneView() const { return ControlledDrone != nullptr; }

	// ---------- Commander ----------
	UFUNCTION(Server, Reliable)
	void ServerAssignObjective(ABFObjective* Objective);

	// ---------- UI ----------
	UFUNCTION(BlueprintCallable, Category = "UI") void ToggleScoreboard(bool bVisible);
	UFUNCTION() void ShowScoreboard() { ToggleScoreboard(true); }
	UFUNCTION() void HideScoreboard() { ToggleScoreboard(false); }
	UFUNCTION(BlueprintPure, Category = "UI") UBFHUDWidget* GetHUDWidget() const { return HUDWidget; }

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "UI") TSubclassOf<UBFHUDWidget> HUDWidgetClass;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "UI") TSubclassOf<UBFDeployWidget> DeployWidgetClass;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "UI") TSubclassOf<UBFScoreboardWidget> ScoreboardWidgetClass;

	UPROPERTY(BlueprintReadOnly, Category = "UI") TObjectPtr<UBFHUDWidget> HUDWidget;
	UPROPERTY(BlueprintReadOnly, Category = "UI") TObjectPtr<UBFDeployWidget> DeployWidget;
	UPROPERTY(BlueprintReadOnly, Category = "UI") TObjectPtr<UBFScoreboardWidget> ScoreboardWidget;

	void CreateHUDWidgets();
	void ShowDeployScreen(bool bVisible);

private:
	UPROPERTY() TObjectPtr<ABFReconDrone> ControlledDrone;
	UPROPERTY() TObjectPtr<APawn> StashedPawn;
};
