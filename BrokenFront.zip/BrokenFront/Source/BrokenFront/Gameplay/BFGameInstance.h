// Copyright (c) Broken Front. Fictional setting, no real-world factions.

#pragma once

#include "CoreMinimal.h"
#include "Engine/GameInstance.h"
#include "Interfaces/OnlineSessionInterface.h"
#include "Core/BFTypes.h"
#include "Data/BFLoadout.h"
#include "Gameplay/BFPlayerState.h"
#include "BFGameInstance.generated.h"

class UBFSaveGame;
class UBFGameSettings;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFServerListReady, const TArray<FBFServerEntry>&, Servers);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBFProfileChanged);

/**
 * Owns everything that must survive a level change: the local profile (nickname,
 * level, XP, statistics, class progression, cosmetics, saved loadouts), the settings
 * object, and session search for the server browser.
 *
 * Progression is client side persistence only. The server never trusts it: class
 * unlock levels are re-checked from the replicated PlayerState career level, and
 * loadouts are validated against the class data assets before a spawn is granted.
 */
UCLASS()
class BROKENFRONT_API UBFGameInstance : public UGameInstance
{
	GENERATED_BODY()

public:
	UBFGameInstance();

	virtual void Init() override;
	virtual void Shutdown() override;

	// ---------------------------------------------------------------- Profile

	UFUNCTION(BlueprintPure, Category = "Profile") FString GetNickname() const;
	UFUNCTION(BlueprintCallable, Category = "Profile") void SetNickname(const FString& NewNickname);

	UFUNCTION(BlueprintPure, Category = "Profile") int32 GetCareerLevel() const;
	UFUNCTION(BlueprintPure, Category = "Profile") int32 GetCareerXP() const;

	/** 0..1 progress towards the next career level, for the menu bar. */
	UFUNCTION(BlueprintPure, Category = "Profile") float GetLevelProgressPercent() const;

	UFUNCTION(BlueprintPure, Category = "Profile") FBFProfileStats GetProfileStats() const;

	UFUNCTION(BlueprintPure, Category = "Profile") int32 GetClassLevel(EBFSoldierClass SoldierClass) const;
	UFUNCTION(BlueprintPure, Category = "Profile") int32 GetClassXP(EBFSoldierClass SoldierClass) const;

	UFUNCTION(BlueprintPure, Category = "Profile") bool IsCosmeticUnlocked(FName CosmeticId) const;
	UFUNCTION(BlueprintCallable, Category = "Profile") void UnlockCosmetic(FName CosmeticId);
	UFUNCTION(BlueprintPure, Category = "Profile") TArray<FName> GetUnlockedCosmetics() const;

	/** Loadout screen persistence, per class. */
	UFUNCTION(BlueprintPure, Category = "Profile") FBFLoadout GetSavedLoadout(EBFSoldierClass SoldierClass) const;
	UFUNCTION(BlueprintCallable, Category = "Profile") void SaveLoadout(EBFSoldierClass SoldierClass, const FBFLoadout& Loadout);

	UFUNCTION(BlueprintPure, Category = "Profile") EBFSoldierClass GetLastPlayedClass() const;
	UFUNCTION(BlueprintCallable, Category = "Profile") void SetLastPlayedClass(EBFSoldierClass SoldierClass);

	/** Called at match end by UBFMatchManager for local players. Writes the save. */
	void CommitMatchResults(const FBFMatchRecord& Record, int32 EarnedXP, bool bWon);

	UFUNCTION(BlueprintCallable, Category = "Profile") void SaveProfile();

	/** XP needed to go from Level to Level+1. Gentle curve, no grind wall. */
	UFUNCTION(BlueprintPure, Category = "Profile") static int32 XPForLevel(int32 Level);

	UPROPERTY(BlueprintAssignable, Category = "Profile") FBFProfileChanged OnProfileChanged;

	// ---------------------------------------------------------------- Settings

	UFUNCTION(BlueprintPure, Category = "Settings") UBFGameSettings* GetSettings() const { return Settings; }

	// ---------------------------------------------------------------- Servers

	/** Kicks off an async session search. Result arrives on OnServerListReady. */
	UFUNCTION(BlueprintCallable, Category = "Servers") void RefreshServerList();

	UFUNCTION(BlueprintPure, Category = "Servers") bool IsSearchingServers() const { return bSearching; }

	UFUNCTION(BlueprintPure, Category = "Servers") const TArray<FBFServerEntry>& GetCachedServers() const { return CachedServers; }

	UPROPERTY(BlueprintAssignable, Category = "Servers") FBFServerListReady OnServerListReady;

	/**
	 * Creates an advertised session and travels to the map as a listen server.
	 * The advertised keys are exactly what the browser reads back, so a game hosted
	 * from the menu is discoverable without any extra setup.
	 */
	UFUNCTION(BlueprintCallable, Category = "Servers")
	void HostListenServer(const FString& ServerName, FName MapName, int32 MaxPlayers);

	/** Tears down an advertised session. Called on returning to the main menu. */
	UFUNCTION(BlueprintCallable, Category = "Servers") void EndHostedSession();

protected:
	void LoadProfile();
	void EnsureSettings();

	void HandleFindSessionsComplete(bool bSuccess);
	void HandleCreateSessionComplete(FName SessionName, bool bSuccess);

	/** Fills CachedServers from the completed search and broadcasts. */
	void PublishSearchResults();

	UPROPERTY(Transient) TObjectPtr<UBFSaveGame> Profile;
	UPROPERTY(Transient) TObjectPtr<UBFGameSettings> Settings;

	UPROPERTY(Transient) TArray<FBFServerEntry> CachedServers;

	bool bSearching = false;

	TSharedPtr<FOnlineSessionSearch> SessionSearch;
	FDelegateHandle FindSessionsHandle;
	FDelegateHandle CreateSessionHandle;

	/** Map we travel to once the session has been created. */
	FName PendingHostMap;
	int32 PendingHostMaxPlayers = 64;

	/** Max results asked of the online subsystem per refresh. */
	UPROPERTY(EditDefaultsOnly, Category = "Servers") int32 MaxSearchResults = 64;
};
