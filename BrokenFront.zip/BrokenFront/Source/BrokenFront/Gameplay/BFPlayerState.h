#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerState.h"
#include "Core/BFTypes.h"
#include "Data/BFLoadout.h"
#include "BFPlayerState.generated.h"

class UBFSoldierClassDataAsset;

DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBFPlayerStatsChanged);

/** Per-match record for the scoreboard. */
USTRUCT(BlueprintType)
struct FBFMatchRecord
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly) int32 Score = 0;
	UPROPERTY(BlueprintReadOnly) int32 Kills = 0;
	UPROPERTY(BlueprintReadOnly) int32 Deaths = 0;
	UPROPERTY(BlueprintReadOnly) int32 Assists = 0;
	UPROPERTY(BlueprintReadOnly) int32 Headshots = 0;
	UPROPERTY(BlueprintReadOnly) int32 Revives = 0;
	UPROPERTY(BlueprintReadOnly) int32 Captures = 0;
	UPROPERTY(BlueprintReadOnly) int32 Builds = 0;
};

/**
 * Team, squad, chosen loadout and match record. Also the bridge to persistent
 * progression: XP earned here is written to the save game at match end.
 */
UCLASS()
class BROKENFRONT_API ABFPlayerState : public APlayerState
{
	GENERATED_BODY()

public:
	ABFPlayerState();

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void CopyProperties(APlayerState* PlayerState) override;

	UPROPERTY(BlueprintAssignable, Category = "Player") FBFPlayerStatsChanged OnStatsChanged;

	UFUNCTION(BlueprintPure, Category = "Player") EBFTeam GetTeam() const { return Team; }
	UFUNCTION(BlueprintPure, Category = "Player") int32 GetSquadId() const { return SquadId; }
	UFUNCTION(BlueprintPure, Category = "Player") EBFSoldierClass GetSoldierClassType() const { return SelectedClassType; }
	UFUNCTION(BlueprintPure, Category = "Player") UBFSoldierClassDataAsset* GetSelectedClassAsset() const { return SelectedLoadout.SoldierClass; }
	UFUNCTION(BlueprintPure, Category = "Player") const FBFLoadout& GetSelectedLoadout() const { return SelectedLoadout; }
	UFUNCTION(BlueprintPure, Category = "Player") const FBFMatchRecord& GetMatchRecord() const { return MatchRecord; }
	UFUNCTION(BlueprintPure, Category = "Player") int32 GetMatchXP() const { return MatchXP; }
	UFUNCTION(BlueprintPure, Category = "Player") int32 GetCareerLevel() const { return CareerLevel; }
	UFUNCTION(BlueprintPure, Category = "Player") bool IsSquadLeader() const { return bSquadLeader; }

	/** Server. */
	void SetTeam(EBFTeam NewTeam);
	void SetSquad(int32 NewSquadId, bool bLeader);
	void SetCareerLevel(int32 NewLevel) { CareerLevel = NewLevel; }

	void AddScore(int32 Points);
	void RegisterKill(ABFPlayerState* Victim, bool bHeadshot);
	void RegisterDeath(ABFPlayerState* Killer);
	void RegisterAssist();
	void RegisterRevive();
	void RegisterCapture();
	void RegisterBuild();
	void ResetMatchRecord();

	/** Client -> server loadout selection, validated against the class asset. */
	UFUNCTION(Server, Reliable, WithValidation)
	void ServerSetLoadout(const FBFLoadout& NewLoadout);

	/** Local: called by the loadout screen before deploying. */
	UFUNCTION(BlueprintCallable, Category = "Player")
	void RequestLoadout(const FBFLoadout& NewLoadout);

protected:
	UPROPERTY(ReplicatedUsing = OnRep_Team, BlueprintReadOnly, Category = "Player")
	EBFTeam Team = EBFTeam::Neutral;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Player")
	int32 SquadId = INDEX_NONE;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Player")
	bool bSquadLeader = false;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Player")
	EBFSoldierClass SelectedClassType = EBFSoldierClass::Rifleman;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Player")
	FBFLoadout SelectedLoadout;

	UPROPERTY(ReplicatedUsing = OnRep_Stats, BlueprintReadOnly, Category = "Player")
	FBFMatchRecord MatchRecord;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Player")
	int32 MatchXP = 0;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Player")
	int32 CareerLevel = 1;

	UFUNCTION() void OnRep_Team();
	UFUNCTION() void OnRep_Stats();
};
