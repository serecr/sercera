#include "Gameplay/BFPlayerController.h"

#include "Blueprint/UserWidget.h"
#include "Characters/BFCharacter.h"
#include "Core/BFLog.h"
#include "Equipment/BFReconDrone.h"
#include "Gameplay/BFGameMode.h"
#include "Gameplay/BFPlayerState.h"
#include "Sectors/BFObjective.h"
#include "Systems/BFObjectiveManager.h"
#include "Systems/BFRadioComponent.h"
#include "UI/BFDeployWidget.h"
#include "UI/BFHUDWidget.h"
#include "UI/BFScoreboardWidget.h"

ABFPlayerController::ABFPlayerController()
{
	bReplicates = true;
	// Long sight lines on a large map: keep relevancy generous for the owning client.
	bAutoManageActiveCameraTarget = true;
}

void ABFPlayerController::BeginPlay()
{
	Super::BeginPlay();

	if (IsLocalController())
	{
		CreateHUDWidgets();
		ShowDeployScreen(true);
	}
}

void ABFPlayerController::SetupInputComponent()
{
	Super::SetupInputComponent();

	// Scoreboard and deploy screen are controller-level, not pawn-level, so they
	// keep working while dead.
	InputComponent->BindKey(EKeys::Tab, IE_Pressed, this, &ABFPlayerController::ShowScoreboard);
	InputComponent->BindKey(EKeys::Tab, IE_Released, this, &ABFPlayerController::HideScoreboard);
}

void ABFPlayerController::CreateHUDWidgets()
{
	if (HUDWidgetClass && !HUDWidget)
	{
		HUDWidget = CreateWidget<UBFHUDWidget>(this, HUDWidgetClass);
		if (HUDWidget)
		{
			HUDWidget->AddToViewport(0);
		}
	}

	if (DeployWidgetClass && !DeployWidget)
	{
		DeployWidget = CreateWidget<UBFDeployWidget>(this, DeployWidgetClass);
		if (DeployWidget)
		{
			DeployWidget->AddToViewport(10);
			DeployWidget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}

	if (ScoreboardWidgetClass && !ScoreboardWidget)
	{
		ScoreboardWidget = CreateWidget<UBFScoreboardWidget>(this, ScoreboardWidgetClass);
		if (ScoreboardWidget)
		{
			ScoreboardWidget->AddToViewport(5);
			ScoreboardWidget->SetVisibility(ESlateVisibility::Collapsed);
		}
	}
}

void ABFPlayerController::ShowDeployScreen(bool bVisible)
{
	if (!DeployWidget)
	{
		return;
	}

	DeployWidget->SetVisibility(bVisible ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
	bShowMouseCursor = bVisible;
	if (bVisible)
	{
		FInputModeGameAndUI Mode;
		Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
		SetInputMode(Mode);
	}
	else
	{
		SetInputMode(FInputModeGameOnly());
	}
}

void ABFPlayerController::OnPossess(APawn* InPawn)
{
	Super::OnPossess(InPawn);

	if (IsLocalController() && Cast<ABFCharacter>(InPawn))
	{
		ShowDeployScreen(false);
		if (HUDWidget)
		{
			HUDWidget->BindToPawn(Cast<ABFCharacter>(InPawn));
		}
	}
}

void ABFPlayerController::OnUnPossess()
{
	Super::OnUnPossess();

	if (IsLocalController() && HUDWidget)
	{
		HUDWidget->BindToPawn(nullptr);
	}
}

void ABFPlayerController::RequestDeploy(EBFSpawnKind PreferredKind)
{
	if (HasAuthority())
	{
		ServerRequestDeploy_Implementation(PreferredKind);
	}
	else
	{
		ServerRequestDeploy(PreferredKind);
	}
}

void ABFPlayerController::ServerRequestDeploy_Implementation(EBFSpawnKind PreferredKind)
{
	if (ABFGameMode* GM = GetWorld()->GetAuthGameMode<ABFGameMode>())
	{
		GM->RequestDeploy(this, PreferredKind);
	}
}

void ABFPlayerController::ClientNotifyDeployAvailable_Implementation()
{
	OnDeployAvailable.Broadcast(true);
	ShowDeployScreen(true);
}

void ABFPlayerController::SubmitLoadout(const FBFLoadout& Loadout)
{
	if (ABFPlayerState* PS = GetPlayerState<ABFPlayerState>())
	{
		PS->RequestLoadout(Loadout);
	}
}

void ABFPlayerController::ServerRequestTeamChange_Implementation(EBFTeam DesiredTeam)
{
	if (ABFGameMode* GM = GetWorld()->GetAuthGameMode<ABFGameMode>())
	{
		GM->RequestTeamChange(this, DesiredTeam);
	}
}

void ABFPlayerController::SendRadioCommand(EBFRadioCommand Command, EBFRadioChannel Channel)
{
	if (ABFCharacter* Char = Cast<ABFCharacter>(GetPawn()))
	{
		if (UBFRadioComponent* Radio = Char->GetRadio())
		{
			Radio->SendCommand(Command, Channel);
		}
	}
}

void ABFPlayerController::ServerAssignObjective_Implementation(ABFObjective* Objective)
{
	const ABFPlayerState* PS = GetPlayerState<ABFPlayerState>();
	if (!PS || PS->GetSoldierClassType() != EBFSoldierClass::Commander)
	{
		return;
	}

	if (UBFObjectiveManager* Manager = UBFObjectiveManager::Get(GetWorld()))
	{
		Manager->AssignCommanderObjective(PS->GetTeam(), Objective);
	}
}

void ABFPlayerController::EnterDroneView(ABFReconDrone* Drone)
{
	if (!Drone || ControlledDrone)
	{
		return;
	}

	ControlledDrone = Drone;
	StashedPawn = GetPawn();

	// The soldier stays in the world, exposed and vulnerable, while you fly.
	SetViewTargetWithBlend(Drone, 0.35f, EViewTargetBlendFunction::VTBlend_Cubic);
	Drone->SetControllingPlayer(this);
}

void ABFPlayerController::ExitDroneView()
{
	if (!ControlledDrone)
	{
		return;
	}

	ControlledDrone->SetControllingPlayer(nullptr);
	ControlledDrone = nullptr;

	if (APawn* Pawn = StashedPawn ? StashedPawn.Get() : GetPawn())
	{
		SetViewTargetWithBlend(Pawn, 0.3f, EViewTargetBlendFunction::VTBlend_Cubic);
	}
	StashedPawn = nullptr;
}

void ABFPlayerController::ToggleScoreboard(bool bVisible)
{
	if (ScoreboardWidget)
	{
		ScoreboardWidget->SetVisibility(bVisible ? ESlateVisibility::Visible : ESlateVisibility::Collapsed);
		if (bVisible)
		{
			ScoreboardWidget->RefreshScoreboard();
		}
	}
}
