#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameStateBase.h"
#include "Core/BFTypes.h"
#include "BFGameState.generated.h"

class ABFSector;
class ABFObjective;
class ABFFrontlineManager;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFMatchPhaseChanged, EBFMatchPhase, NewPhase);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBFSectorsUpdated);

/**
 * Everything the client needs to draw the HUD, minimap and scoreboard without
 * asking the server questions: sector snapshots, tickets, scores, phase, weather.
 */
UCLASS()
class BROKENFRONT_API ABFGameState : public AGameStateBase
{
	GENERATED_BODY()

public:
	ABFGameState();

	virtual void Tick(float DeltaSeconds) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Match") FBFMatchPhaseChanged OnMatchPhaseChanged;
	UPROPERTY(BlueprintAssignable, Category = "Match") FBFSectorsUpdated OnSectorsUpdated;

	// ---------- Registration (server) ----------
	void RegisterSector(ABFSector* Sector);
	void RegisterObjective(ABFObjective* Objective);
	void RefreshSectorSnapshots();

	// ---------- Match state ----------
	UFUNCTION(BlueprintPure, Category = "Match") EBFMatchPhase GetMatchPhase() const { return MatchPhase; }
	UFUNCTION(BlueprintPure, Category = "Match") float GetMatchTimeRemaining() const { return MatchTimeRemaining; }
	UFUNCTION(BlueprintPure, Category = "Match") EBFTeam GetWinningTeam() const { return WinningTeam; }
	UFUNCTION(BlueprintPure, Category = "Match") int32 GetTeamScore(EBFTeam Team) const;
	UFUNCTION(BlueprintPure, Category = "Match") float GetTickets(EBFTeam Team) const;
	UFUNCTION(BlueprintPure, Category = "Match") bool IsFriendlyFireEnabled() const { return bFriendlyFire; }
	UFUNCTION(BlueprintPure, Category = "Match") float GetFriendlyFireScale() const { return FriendlyFireScale; }

	UFUNCTION(BlueprintPure, Category = "Match") const TArray<FBFSectorSnapshot>& GetSectorSnapshots() const { return SectorSnapshots; }
	UFUNCTION(BlueprintPure, Category = "Match") TArray<ABFObjective*> GetActiveObjectivesForTeam(EBFTeam Team) const;
	UFUNCTION(BlueprintPure, Category = "Match") FBFSectorSnapshot GetSectorSnapshotAt(const FVector& WorldLocation) const;

	/** Server. */
	void SetMatchPhase(EBFMatchPhase NewPhase);
	void SetMatchTimeRemaining(float Seconds) { MatchTimeRemaining = Seconds; }
	void AddTeamScore(EBFTeam Team, int32 Points);
	void DrainTickets(EBFTeam Team, float Amount);
	void RequestMatchEnd(EBFTeam Winner, FName Reason);

	/** Server: how many build resources a team has left this match. */
	UFUNCTION(BlueprintPure, Category = "Build") int32 GetBuildResources(EBFTeam Team) const;
	bool ConsumeBuildResources(EBFTeam Team, int32 Amount);
	void RefundBuildResources(EBFTeam Team, int32 Amount);

	/** Count of living players per team, refreshed on the server every second. */
	UFUNCTION(BlueprintPure, Category = "Match") int32 GetAlivePlayers(EBFTeam Team) const;

protected:
	UPROPERTY(ReplicatedUsing = OnRep_MatchPhase, BlueprintReadOnly, Category = "Match")
	EBFMatchPhase MatchPhase = EBFMatchPhase::WaitingForPlayers;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	float MatchTimeRemaining = 0.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	EBFTeam WinningTeam = EBFTeam::Neutral;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	int32 IroncladScore = 0;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	int32 AshguardScore = 0;

	/** Reinforcement tickets. Hitting zero loses the match. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	float IroncladTickets = 800.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	float AshguardTickets = 800.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Build")
	int32 IroncladBuildResources = 600;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Build")
	int32 AshguardBuildResources = 600;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	int32 IroncladAlive = 0;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Match")
	int32 AshguardAlive = 0;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules")
	bool bFriendlyFire = true;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Rules", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float FriendlyFireScale = 0.5f;

	/** Replicated compact view of every sector, rebuilt whenever the front moves. */
	UPROPERTY(ReplicatedUsing = OnRep_SectorSnapshots, BlueprintReadOnly, Category = "Frontline")
	TArray<FBFSectorSnapshot> SectorSnapshots;

	UFUNCTION() void OnRep_MatchPhase();
	UFUNCTION() void OnRep_SectorSnapshots();

private:
	UPROPERTY() TArray<TObjectPtr<ABFSector>> Sectors;
	UPROPERTY() TArray<TObjectPtr<ABFObjective>> Objectives;

	float AliveRecountTimer = 0.f;
	void RecountAlivePlayers();
};
