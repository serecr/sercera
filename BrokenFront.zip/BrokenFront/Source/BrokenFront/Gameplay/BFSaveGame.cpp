#include "Gameplay/BFSaveGame.h"

FBFClassProgress& UBFSaveGame::FindOrAddClass(EBFSoldierClass InClass)
{
	for (FBFClassProgress& Entry : ClassProgress)
	{
		if (Entry.SoldierClass == InClass)
		{
			return Entry;
		}
	}

	FBFClassProgress NewEntry;
	NewEntry.SoldierClass = InClass;
	const int32 Index = ClassProgress.Add(NewEntry);
	return ClassProgress[Index];
}
