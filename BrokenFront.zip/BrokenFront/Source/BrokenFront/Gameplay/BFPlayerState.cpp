#include "Gameplay/BFPlayerState.h"

#include "Data/BFSoldierClassDataAsset.h"
#include "Data/BFWeaponDataAsset.h"
#include "Net/UnrealNetwork.h"

ABFPlayerState::ABFPlayerState()
{
	NetUpdateFrequency = 4.f; // scoreboard data, not movement
}

void ABFPlayerState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABFPlayerState, Team);
	DOREPLIFETIME(ABFPlayerState, SquadId);
	DOREPLIFETIME(ABFPlayerState, bSquadLeader);
	DOREPLIFETIME(ABFPlayerState, SelectedClassType);
	DOREPLIFETIME(ABFPlayerState, SelectedLoadout);
	DOREPLIFETIME(ABFPlayerState, MatchRecord);
	DOREPLIFETIME(ABFPlayerState, MatchXP);
	DOREPLIFETIME(ABFPlayerState, CareerLevel);
}

void ABFPlayerState::CopyProperties(APlayerState* PlayerState)
{
	Super::CopyProperties(PlayerState);

	// Survives seamless travel between maps.
	if (ABFPlayerState* Other = Cast<ABFPlayerState>(PlayerState))
	{
		Other->Team = Team;
		Other->SquadId = SquadId;
		Other->bSquadLeader = bSquadLeader;
		Other->SelectedClassType = SelectedClassType;
		Other->SelectedLoadout = SelectedLoadout;
		Other->CareerLevel = CareerLevel;
	}
}

void ABFPlayerState::SetTeam(EBFTeam NewTeam)
{
	if (HasAuthority())
	{
		Team = NewTeam;
		OnRep_Team();
	}
}

void ABFPlayerState::SetSquad(int32 NewSquadId, bool bLeader)
{
	if (HasAuthority())
	{
		SquadId = NewSquadId;
		bSquadLeader = bLeader;
	}
}

void ABFPlayerState::RequestLoadout(const FBFLoadout& NewLoadout)
{
	// Optimistic local set so the loadout screen reads back immediately.
	SelectedLoadout = NewLoadout;
	if (NewLoadout.SoldierClass)
	{
		SelectedClassType = NewLoadout.SoldierClass->ClassType;
	}

	if (!HasAuthority())
	{
		ServerSetLoadout(NewLoadout);
	}
}

bool ABFPlayerState::ServerSetLoadout_Validate(const FBFLoadout& NewLoadout)
{
	return NewLoadout.SoldierClass != nullptr;
}

void ABFPlayerState::ServerSetLoadout_Implementation(const FBFLoadout& NewLoadout)
{
	UBFSoldierClassDataAsset* ClassAsset = NewLoadout.SoldierClass;
	if (!ClassAsset)
	{
		return;
	}

	// Validate: the weapons must be on the class's allow list and unlocked.
	FBFLoadout Validated;
	Validated.SoldierClass = ClassAsset;
	Validated.UniformId = NewLoadout.UniformId;
	Validated.CosmeticIds = NewLoadout.CosmeticIds;

	auto IsAllowed = [this](const TArray<TSoftObjectPtr<UBFWeaponDataAsset>>& List, UBFWeaponDataAsset* Candidate) -> bool
	{
		if (!Candidate)
		{
			return false;
		}
		if (Candidate->UnlockLevel > CareerLevel)
		{
			return false;
		}
		for (const TSoftObjectPtr<UBFWeaponDataAsset>& Entry : List)
		{
			if (Entry.Get() == Candidate || Entry.ToSoftObjectPath() == FSoftObjectPath(Candidate))
			{
				return true;
			}
		}
		return false;
	};

	if (IsAllowed(ClassAsset->AllowedPrimaries, NewLoadout.Primary))
	{
		Validated.Primary = NewLoadout.Primary;
	}
	else if (ClassAsset->AllowedPrimaries.Num() > 0)
	{
		Validated.Primary = ClassAsset->AllowedPrimaries[0].LoadSynchronous();
	}

	if (IsAllowed(ClassAsset->AllowedSecondaries, NewLoadout.Secondary))
	{
		Validated.Secondary = NewLoadout.Secondary;
	}
	else if (ClassAsset->AllowedSecondaries.Num() > 0)
	{
		Validated.Secondary = ClassAsset->AllowedSecondaries[0].LoadSynchronous();
	}

	if (NewLoadout.Equipment && ClassAsset->AllowedEquipment.Contains(NewLoadout.Equipment))
	{
		Validated.Equipment = NewLoadout.Equipment;
	}
	else if (ClassAsset->AllowedEquipment.Num() > 0)
	{
		Validated.Equipment = ClassAsset->AllowedEquipment[0];
	}

	SelectedLoadout = Validated;
	SelectedClassType = ClassAsset->ClassType;
}

void ABFPlayerState::AddScore(int32 Points)
{
	if (!HasAuthority() || Points == 0)
	{
		return;
	}

	MatchRecord.Score += Points;
	MatchXP += Points;
	SetScore(static_cast<float>(MatchRecord.Score));
	OnStatsChanged.Broadcast();
}

void ABFPlayerState::RegisterKill(ABFPlayerState* Victim, bool bHeadshot)
{
	if (!HasAuthority())
	{
		return;
	}

	// Team kills cost you score instead of granting it.
	if (Victim && Victim->GetTeam() == Team)
	{
		AddScore(-50);
		return;
	}

	++MatchRecord.Kills;
	if (bHeadshot)
	{
		++MatchRecord.Headshots;
	}
	AddScore(bHeadshot ? 120 : 100);
}

void ABFPlayerState::RegisterDeath(ABFPlayerState* /*Killer*/)
{
	if (HasAuthority())
	{
		++MatchRecord.Deaths;
		OnStatsChanged.Broadcast();
	}
}

void ABFPlayerState::RegisterAssist()
{
	if (HasAuthority())
	{
		++MatchRecord.Assists;
		AddScore(35);
	}
}

void ABFPlayerState::RegisterRevive()
{
	if (HasAuthority())
	{
		++MatchRecord.Revives;
		AddScore(150);
	}
}

void ABFPlayerState::RegisterCapture()
{
	if (HasAuthority())
	{
		++MatchRecord.Captures;
		AddScore(250);
	}
}

void ABFPlayerState::RegisterBuild()
{
	if (HasAuthority())
	{
		++MatchRecord.Builds;
		AddScore(25);
	}
}

void ABFPlayerState::ResetMatchRecord()
{
	if (HasAuthority())
	{
		MatchRecord = FBFMatchRecord();
		MatchXP = 0;
		SetScore(0.f);
		OnStatsChanged.Broadcast();
	}
}

void ABFPlayerState::OnRep_Team()
{
	OnStatsChanged.Broadcast();
}

void ABFPlayerState::OnRep_Stats()
{
	OnStatsChanged.Broadcast();
}
