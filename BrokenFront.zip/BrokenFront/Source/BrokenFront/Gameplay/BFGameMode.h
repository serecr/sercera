#pragma once

#include "CoreMinimal.h"
#include "GameFramework/GameMode.h"
#include "Core/BFTypes.h"
#include "BFGameMode.generated.h"

class ABFPlayerState;
class ABFCharacter;
class UBFSoldierClassDataAsset;

/**
 * Server-authoritative match rules: team balancing, squads, deployment and
 * respawn timing. Designed for 32-64 players, so per-player work is kept cheap
 * and nothing iterates all actors every frame.
 */
UCLASS()
class BROKENFRONT_API ABFGameMode : public AGameMode
{
	GENERATED_BODY()

public:
	ABFGameMode();

	virtual void Tick(float DeltaSeconds) override;
	virtual void PostLogin(APlayerController* NewPlayer) override;
	virtual void Logout(AController* Exiting) override;
	virtual void RestartPlayer(AController* NewPlayer) override;
	virtual bool ShouldSpawnAtStartSpot(AController* Player) override { return false; }
	virtual AActor* ChoosePlayerStart_Implementation(AController* Player) override;
	virtual UClass* GetDefaultPawnClassForController_Implementation(AController* InController) override;

	/** Called by the game state / frontline manager. */
	void EndMatchWithWinner(EBFTeam Winner, FName Reason);

	/** Player asked to deploy from the deploy screen. */
	UFUNCTION(BlueprintCallable, Category = "Match")
	void RequestDeploy(APlayerController* Controller, EBFSpawnKind PreferredKind);

	/** Swaps a player's team, rebalancing squads. */
	UFUNCTION(BlueprintCallable, Category = "Match")
	bool RequestTeamChange(APlayerController* Controller, EBFTeam DesiredTeam);

	UFUNCTION(BlueprintPure, Category = "Match")
	bool CanTeamTakeClass(EBFTeam Team, const UBFSoldierClassDataAsset* ClassAsset) const;

protected:
	/** Seconds before a dead player may deploy again. Scales up as tickets drain. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float BaseRespawnDelay = 12.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float MaxRespawnDelay = 25.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config", meta = (ClampMin = "1", ClampMax = "8"))
	int32 SquadSize = 6;

	/** Default loadout applied when a player deploys without choosing one. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TObjectPtr<UBFSoldierClassDataAsset> DefaultSoldierClass;

	UFUNCTION() void HandleCharacterDied(AActor* Killer, const FName& HitZone);

private:
	/** Team with fewer players wins the assignment; ties go to Ironclad. */
	EBFTeam PickBalancedTeam() const;

	/** Finds a squad with room on the given team, or opens a new one. */
	void AssignSquad(ABFPlayerState* PlayerState);

	float ComputeRespawnDelay(EBFTeam Team) const;
	void ScheduleRespawn(APlayerController* Controller);

	TMap<TWeakObjectPtr<APlayerController>, FTimerHandle> RespawnTimers;
};
