#include "Gameplay/BFGameState.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Core/BFLog.h"
#include "EngineUtils.h"
#include "Gameplay/BFGameMode.h"
#include "Net/UnrealNetwork.h"
#include "Sectors/BFObjective.h"
#include "Sectors/BFSector.h"

ABFGameState::ABFGameState()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.25f;
	NetUpdateFrequency = 10.f;
}

void ABFGameState::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABFGameState, MatchPhase);
	DOREPLIFETIME(ABFGameState, MatchTimeRemaining);
	DOREPLIFETIME(ABFGameState, WinningTeam);
	DOREPLIFETIME(ABFGameState, IroncladScore);
	DOREPLIFETIME(ABFGameState, AshguardScore);
	DOREPLIFETIME(ABFGameState, IroncladTickets);
	DOREPLIFETIME(ABFGameState, AshguardTickets);
	DOREPLIFETIME(ABFGameState, IroncladBuildResources);
	DOREPLIFETIME(ABFGameState, AshguardBuildResources);
	DOREPLIFETIME(ABFGameState, IroncladAlive);
	DOREPLIFETIME(ABFGameState, AshguardAlive);
	DOREPLIFETIME(ABFGameState, SectorSnapshots);
}

void ABFGameState::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!HasAuthority())
	{
		return;
	}

	AliveRecountTimer += DeltaSeconds;
	if (AliveRecountTimer >= 1.f)
	{
		AliveRecountTimer = 0.f;
		RecountAlivePlayers();

		// Sector progress changes constantly while contested; refresh the compact view.
		RefreshSectorSnapshots();
	}
}

void ABFGameState::RecountAlivePlayers()
{
	int32 Ironclad = 0;
	int32 Ashguard = 0;

	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		const ABFCharacter* Char = *It;
		if (!Char)
		{
			continue;
		}

		const UBFHealthComponent* Health = Char->GetHealthComponent();
		if (Health && !Health->IsAlive())
		{
			continue;
		}

		switch (Char->GetTeam())
		{
		case EBFTeam::Ironclad: ++Ironclad; break;
		case EBFTeam::Ashguard: ++Ashguard; break;
		default: break;
		}
	}

	IroncladAlive = Ironclad;
	AshguardAlive = Ashguard;
}

void ABFGameState::RegisterSector(ABFSector* Sector)
{
	if (Sector)
	{
		Sectors.AddUnique(Sector);
		RefreshSectorSnapshots();
	}
}

void ABFGameState::RegisterObjective(ABFObjective* Objective)
{
	if (Objective)
	{
		Objectives.AddUnique(Objective);
	}
}

void ABFGameState::RefreshSectorSnapshots()
{
	if (!HasAuthority())
	{
		return;
	}

	SectorSnapshots.Reset(Sectors.Num());
	for (const TObjectPtr<ABFSector>& Sector : Sectors)
	{
		if (Sector)
		{
			SectorSnapshots.Add(Sector->BuildSnapshot());
		}
	}

	SectorSnapshots.Sort([](const FBFSectorSnapshot& A, const FBFSectorSnapshot& B)
	{
		return A.LineIndex < B.LineIndex;
	});

	OnSectorsUpdated.Broadcast();
}

FBFSectorSnapshot ABFGameState::GetSectorSnapshotAt(const FVector& WorldLocation) const
{
	// Nearest capture point wins. Good enough for a HUD readout and free of volume queries.
	const FBFSectorSnapshot* Best = nullptr;
	float BestDistSq = TNumericLimits<float>::Max();

	for (const FBFSectorSnapshot& Snapshot : SectorSnapshots)
	{
		const float DistSq = FVector::DistSquared(Snapshot.WorldLocation, WorldLocation);
		if (DistSq < BestDistSq)
		{
			BestDistSq = DistSq;
			Best = &Snapshot;
		}
	}

	return Best ? *Best : FBFSectorSnapshot();
}

TArray<ABFObjective*> ABFGameState::GetActiveObjectivesForTeam(EBFTeam Team) const
{
	TArray<ABFObjective*> Result;
	for (const TObjectPtr<ABFObjective>& Objective : Objectives)
	{
		if (Objective && Objective->GetStatus() == EBFObjectiveStatus::Active && Objective->GetAssignedTeam() == Team)
		{
			Result.Add(Objective.Get());
		}
	}
	return Result;
}

int32 ABFGameState::GetTeamScore(EBFTeam Team) const
{
	switch (Team)
	{
	case EBFTeam::Ironclad: return IroncladScore;
	case EBFTeam::Ashguard: return AshguardScore;
	default: return 0;
	}
}

float ABFGameState::GetTickets(EBFTeam Team) const
{
	switch (Team)
	{
	case EBFTeam::Ironclad: return IroncladTickets;
	case EBFTeam::Ashguard: return AshguardTickets;
	default: return 0.f;
	}
}

int32 ABFGameState::GetAlivePlayers(EBFTeam Team) const
{
	switch (Team)
	{
	case EBFTeam::Ironclad: return IroncladAlive;
	case EBFTeam::Ashguard: return AshguardAlive;
	default: return 0;
	}
}

int32 ABFGameState::GetBuildResources(EBFTeam Team) const
{
	switch (Team)
	{
	case EBFTeam::Ironclad: return IroncladBuildResources;
	case EBFTeam::Ashguard: return AshguardBuildResources;
	default: return 0;
	}
}

bool ABFGameState::ConsumeBuildResources(EBFTeam Team, int32 Amount)
{
	if (!HasAuthority() || Amount <= 0)
	{
		return false;
	}

	int32* Pool = (Team == EBFTeam::Ironclad) ? &IroncladBuildResources
		: (Team == EBFTeam::Ashguard) ? &AshguardBuildResources : nullptr;

	if (!Pool || *Pool < Amount)
	{
		return false;
	}

	*Pool -= Amount;
	return true;
}

void ABFGameState::RefundBuildResources(EBFTeam Team, int32 Amount)
{
	if (!HasAuthority() || Amount <= 0)
	{
		return;
	}

	if (Team == EBFTeam::Ironclad) { IroncladBuildResources += Amount; }
	else if (Team == EBFTeam::Ashguard) { AshguardBuildResources += Amount; }
}

void ABFGameState::AddTeamScore(EBFTeam Team, int32 Points)
{
	if (!HasAuthority())
	{
		return;
	}

	if (Team == EBFTeam::Ironclad) { IroncladScore += Points; }
	else if (Team == EBFTeam::Ashguard) { AshguardScore += Points; }
}

void ABFGameState::DrainTickets(EBFTeam Team, float Amount)
{
	if (!HasAuthority() || Amount <= 0.f || MatchPhase != EBFMatchPhase::InProgress)
	{
		return;
	}

	float* Pool = (Team == EBFTeam::Ironclad) ? &IroncladTickets
		: (Team == EBFTeam::Ashguard) ? &AshguardTickets : nullptr;

	if (!Pool)
	{
		return;
	}

	*Pool = FMath::Max(0.f, *Pool - Amount);

	if (*Pool <= 0.f)
	{
		RequestMatchEnd(BFTeam::Opposite(Team), TEXT("TicketsExhausted"));
	}
}

void ABFGameState::SetMatchPhase(EBFMatchPhase NewPhase)
{
	if (!HasAuthority() || MatchPhase == NewPhase)
	{
		return;
	}

	MatchPhase = NewPhase;
	OnMatchPhaseChanged.Broadcast(MatchPhase);
}

void ABFGameState::RequestMatchEnd(EBFTeam Winner, FName Reason)
{
	if (!HasAuthority() || MatchPhase == EBFMatchPhase::PostMatch)
	{
		return;
	}

	WinningTeam = Winner;
	BF_LOG(LogBrokenFront, Log, TEXT("Match ending. Winner: team %d, reason: %s"),
		static_cast<int32>(Winner), *Reason.ToString());

	if (ABFGameMode* GM = GetWorld()->GetAuthGameMode<ABFGameMode>())
	{
		GM->EndMatchWithWinner(Winner, Reason);
	}
	else
	{
		SetMatchPhase(EBFMatchPhase::PostMatch);
	}
}

void ABFGameState::OnRep_MatchPhase()
{
	OnMatchPhaseChanged.Broadcast(MatchPhase);
}

void ABFGameState::OnRep_SectorSnapshots()
{
	OnSectorsUpdated.Broadcast();
}
