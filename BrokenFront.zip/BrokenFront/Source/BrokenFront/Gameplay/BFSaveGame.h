// Copyright (c) Broken Front. Fictional setting, no real-world factions.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "Core/BFTypes.h"
#include "Data/BFLoadout.h"
#include "BFSaveGame.generated.h"

/** Per-class progression record. Classes unlock cosmetics and loadout slots as they level. */
USTRUCT(BlueprintType)
struct FBFClassProgress
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly) EBFSoldierClass SoldierClass = EBFSoldierClass::Rifleman;
	UPROPERTY(BlueprintReadOnly) int32 XP = 0;
	UPROPERTY(BlueprintReadOnly) int32 Level = 1;
	UPROPERTY(BlueprintReadOnly) int32 MatchesPlayed = 0;
	UPROPERTY(BlueprintReadOnly) float SecondsPlayed = 0.f;
};

/**
 * Local player profile. Everything here is cosmetic / progression only so that a
 * tampered save can never grant a gameplay advantage: the server re-validates every
 * loadout against the class data assets before spawning (see ABFPlayerState).
 */
UCLASS()
class BROKENFRONT_API UBFSaveGame : public USaveGame
{
	GENERATED_BODY()

public:
	static const TCHAR* SlotName() { return TEXT("BrokenFrontProfile"); }
	static constexpr int32 CurrentVersion = 1;

	UPROPERTY() int32 SaveVersion = CurrentVersion;

	UPROPERTY(BlueprintReadOnly) FString Nickname = TEXT("Recruit");
	UPROPERTY(BlueprintReadOnly) int32 CareerXP = 0;
	UPROPERTY(BlueprintReadOnly) int32 CareerLevel = 1;

	UPROPERTY(BlueprintReadOnly) FBFProfileStats Stats;

	UPROPERTY(BlueprintReadOnly) TArray<FBFClassProgress> ClassProgress;

	/** Loadout the player last confirmed for each class, restored on next match. */
	UPROPERTY(BlueprintReadOnly) TMap<EBFSoldierClass, FBFLoadout> SavedLoadouts;

	UPROPERTY(BlueprintReadOnly) TArray<FName> UnlockedCosmetics;

	UPROPERTY(BlueprintReadOnly) EBFSoldierClass LastPlayedClass = EBFSoldierClass::Rifleman;

	FBFClassProgress& FindOrAddClass(EBFSoldierClass InClass);
};
