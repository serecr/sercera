#include "Gameplay/BFGameMode.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Core/BFLog.h"
#include "Data/BFSoldierClassDataAsset.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerStart.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerController.h"
#include "Gameplay/BFPlayerState.h"
#include "Systems/BFMatchManager.h"
#include "Systems/BFSpawnManager.h"
#include "TimerManager.h"

ABFGameMode::ABFGameMode()
{
	PrimaryActorTick.bCanEverTick = true;

	GameStateClass = ABFGameState::StaticClass();
	PlayerStateClass = ABFPlayerState::StaticClass();
	PlayerControllerClass = ABFPlayerController::StaticClass();
	DefaultPawnClass = ABFCharacter::StaticClass();

	bDelayedStart = false;
	bUseSeamlessTravel = true;
	// Players choose when to deploy from the deploy screen.
	bStartPlayersAsSpectators = true;
}

void ABFGameMode::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	// The match manager owns all phase timing; drive it from here.
	if (UBFMatchManager* MatchManager = UBFMatchManager::Get(GetWorld()))
	{
		MatchManager->Tick(DeltaSeconds);
	}
}

void ABFGameMode::PostLogin(APlayerController* NewPlayer)
{
	Super::PostLogin(NewPlayer);

	if (ABFPlayerState* PS = NewPlayer ? NewPlayer->GetPlayerState<ABFPlayerState>() : nullptr)
	{
		PS->SetTeam(PickBalancedTeam());
		AssignSquad(PS);
		PS->ResetMatchRecord();

		if (!PS->GetSelectedClassAsset() && DefaultSoldierClass)
		{
			FBFLoadout Default;
			Default.SoldierClass = DefaultSoldierClass;
			if (DefaultSoldierClass->AllowedPrimaries.Num() > 0)
			{
				Default.Primary = DefaultSoldierClass->AllowedPrimaries[0].LoadSynchronous();
			}
			if (DefaultSoldierClass->AllowedSecondaries.Num() > 0)
			{
				Default.Secondary = DefaultSoldierClass->AllowedSecondaries[0].LoadSynchronous();
			}
			if (DefaultSoldierClass->AllowedEquipment.Num() > 0)
			{
				Default.Equipment = DefaultSoldierClass->AllowedEquipment[0];
			}
			PS->ServerSetLoadout(Default);
		}

		BF_LOG(LogBrokenFront, Log, TEXT("%s joined team %d, squad %d"),
			*PS->GetPlayerName(), static_cast<int32>(PS->GetTeam()), PS->GetSquadId());
	}

	if (UBFMatchManager* MatchManager = UBFMatchManager::Get(GetWorld()))
	{
		MatchManager->NotifyPlayerJoined();
	}
}

void ABFGameMode::Logout(AController* Exiting)
{
	if (APlayerController* PC = Cast<APlayerController>(Exiting))
	{
		if (FTimerHandle* Handle = RespawnTimers.Find(PC))
		{
			GetWorldTimerManager().ClearTimer(*Handle);
			RespawnTimers.Remove(PC);
		}
	}

	if (UBFMatchManager* MatchManager = UBFMatchManager::Get(GetWorld()))
	{
		MatchManager->NotifyPlayerLeft();
	}

	Super::Logout(Exiting);
}

EBFTeam ABFGameMode::PickBalancedTeam() const
{
	int32 Ironclad = 0;
	int32 Ashguard = 0;

	if (const AGameStateBase* GS = GameState)
	{
		for (APlayerState* PS : GS->PlayerArray)
		{
			if (const ABFPlayerState* BFPS = Cast<ABFPlayerState>(PS))
			{
				if (BFPS->GetTeam() == EBFTeam::Ironclad) { ++Ironclad; }
				else if (BFPS->GetTeam() == EBFTeam::Ashguard) { ++Ashguard; }
			}
		}
	}

	return (Ashguard < Ironclad) ? EBFTeam::Ashguard : EBFTeam::Ironclad;
}

void ABFGameMode::AssignSquad(ABFPlayerState* PlayerState)
{
	if (!PlayerState)
	{
		return;
	}

	TMap<int32, int32> SquadCounts;
	if (const AGameStateBase* GS = GameState)
	{
		for (APlayerState* PS : GS->PlayerArray)
		{
			const ABFPlayerState* BFPS = Cast<ABFPlayerState>(PS);
			if (BFPS && BFPS != PlayerState && BFPS->GetTeam() == PlayerState->GetTeam() && BFPS->GetSquadId() != INDEX_NONE)
			{
				SquadCounts.FindOrAdd(BFPS->GetSquadId())++;
			}
		}
	}

	// Fill the lowest-numbered squad with room. Keeps squads dense, which matters
	// because squad spawn is the primary way players get back into a fight.
	for (int32 SquadId = 0; SquadId < 16; ++SquadId)
	{
		const int32* Count = SquadCounts.Find(SquadId);
		const int32 Occupancy = Count ? *Count : 0;
		if (Occupancy < SquadSize)
		{
			PlayerState->SetSquad(SquadId, Occupancy == 0);
			return;
		}
	}

	PlayerState->SetSquad(0, false);
}

bool ABFGameMode::CanTeamTakeClass(EBFTeam Team, const UBFSoldierClassDataAsset* ClassAsset) const
{
	if (!ClassAsset)
	{
		return false;
	}

	if (!ClassAsset->bUniquePerTeam && ClassAsset->MaxPerTeam <= 0)
	{
		return true;
	}

	int32 Count = 0;
	if (const AGameStateBase* GS = GameState)
	{
		for (APlayerState* PS : GS->PlayerArray)
		{
			const ABFPlayerState* BFPS = Cast<ABFPlayerState>(PS);
			if (BFPS && BFPS->GetTeam() == Team && BFPS->GetSoldierClassType() == ClassAsset->ClassType)
			{
				++Count;
			}
		}
	}

	const int32 Limit = ClassAsset->bUniquePerTeam ? 1 : ClassAsset->MaxPerTeam;
	return Count < Limit;
}

bool ABFGameMode::RequestTeamChange(APlayerController* Controller, EBFTeam DesiredTeam)
{
	ABFPlayerState* PS = Controller ? Controller->GetPlayerState<ABFPlayerState>() : nullptr;
	if (!PS || DesiredTeam == EBFTeam::Neutral || PS->GetTeam() == DesiredTeam)
	{
		return false;
	}

	// Refuse a swap that would unbalance the match by more than one player.
	int32 Ironclad = 0;
	int32 Ashguard = 0;
	for (APlayerState* Other : GameState->PlayerArray)
	{
		if (const ABFPlayerState* BFPS = Cast<ABFPlayerState>(Other))
		{
			if (BFPS->GetTeam() == EBFTeam::Ironclad) { ++Ironclad; }
			else if (BFPS->GetTeam() == EBFTeam::Ashguard) { ++Ashguard; }
		}
	}

	const int32 TargetCount = (DesiredTeam == EBFTeam::Ironclad) ? Ironclad : Ashguard;
	const int32 OtherCount = (DesiredTeam == EBFTeam::Ironclad) ? Ashguard : Ironclad;
	if (TargetCount > OtherCount)
	{
		return false;
	}

	// Kill the current pawn so the player cannot teleport across the front.
	if (APawn* Pawn = Controller->GetPawn())
	{
		if (ABFCharacter* Char = Cast<ABFCharacter>(Pawn))
		{
			if (UBFHealthComponent* Health = Char->GetHealthComponent())
			{
				Health->Kill(nullptr, NAME_None);
			}
		}
	}

	PS->SetTeam(DesiredTeam);
	AssignSquad(PS);
	return true;
}

UClass* ABFGameMode::GetDefaultPawnClassForController_Implementation(AController* InController)
{
	return DefaultPawnClass ? DefaultPawnClass : ABFCharacter::StaticClass();
}

AActor* ABFGameMode::ChoosePlayerStart_Implementation(AController* Player)
{
	// Deployment uses the spawn manager, not PlayerStarts. This exists only as a
	// fallback for maps that have not been set up yet.
	for (TActorIterator<APlayerStart> It(GetWorld()); It; ++It)
	{
		return *It;
	}
	return nullptr;
}

void ABFGameMode::RestartPlayer(AController* NewPlayer)
{
	APlayerController* PC = Cast<APlayerController>(NewPlayer);
	if (!PC)
	{
		Super::RestartPlayer(NewPlayer);
		return;
	}

	bool bFound = false;
	FTransform SpawnTransform;

	if (UBFSpawnManager* SpawnManager = UBFSpawnManager::Get(GetWorld()))
	{
		SpawnTransform = SpawnManager->FindBestSpawnTransform(PC, bFound);
	}

	if (!bFound)
	{
		// Nowhere to deploy: keep the player in the deploy screen and try again shortly.
		BF_LOG(LogBrokenFront, Warning, TEXT("Deployment deferred for %s: no available spawn."), *GetNameSafe(PC));
		ScheduleRespawn(PC);
		return;
	}

	// Face the spawn's forward direction, flattened.
	FRotator SpawnRotation = SpawnTransform.Rotator();
	SpawnRotation.Pitch = 0.f;
	SpawnRotation.Roll = 0.f;

	RestartPlayerAtTransform(NewPlayer, FTransform(SpawnRotation, SpawnTransform.GetLocation()));

	if (ABFCharacter* Char = Cast<ABFCharacter>(PC->GetPawn()))
	{
		if (UBFHealthComponent* Health = Char->GetHealthComponent())
		{
			Health->OnDeath.RemoveDynamic(this, &ABFGameMode::HandleCharacterDied);
			Health->OnDeath.AddDynamic(this, &ABFGameMode::HandleCharacterDied);
		}
	}
}

void ABFGameMode::HandleCharacterDied(AActor* Killer, const FName& /*HitZone*/)
{
	// Charge the team a reinforcement ticket and queue the respawn.
	// The health component broadcasts from the dying pawn, so find it via the killer-agnostic path.
	for (FConstPlayerControllerIterator It = GetWorld()->GetPlayerControllerIterator(); It; ++It)
	{
		APlayerController* PC = It->Get();
		ABFCharacter* Char = PC ? Cast<ABFCharacter>(PC->GetPawn()) : nullptr;
		if (!Char)
		{
			continue;
		}

		const UBFHealthComponent* Health = Char->GetHealthComponent();
		if (Health && Health->IsDead())
		{
			if (ABFGameState* GS = GetGameState<ABFGameState>())
			{
				GS->DrainTickets(Char->GetTeam(), 1.f);
			}
			ScheduleRespawn(PC);
		}
	}
}

float ABFGameMode::ComputeRespawnDelay(EBFTeam Team) const
{
	const ABFGameState* GS = GetGameState<ABFGameState>();
	if (!GS)
	{
		return BaseRespawnDelay;
	}

	// The further a team is from full strength, the longer the wave: it gives the
	// winning side a moment of breathing room and makes pushes feel decisive.
	const float Tickets = GS->GetTickets(Team);
	const float Alpha = 1.f - FMath::Clamp(Tickets / 800.f, 0.f, 1.f);
	return FMath::Lerp(BaseRespawnDelay, MaxRespawnDelay, Alpha);
}

void ABFGameMode::ScheduleRespawn(APlayerController* Controller)
{
	if (!Controller)
	{
		return;
	}

	const ABFPlayerState* PS = Controller->GetPlayerState<ABFPlayerState>();
	const float Delay = ComputeRespawnDelay(PS ? PS->GetTeam() : EBFTeam::Neutral);

	FTimerHandle& Handle = RespawnTimers.FindOrAdd(Controller);
	GetWorldTimerManager().ClearTimer(Handle);

	TWeakObjectPtr<APlayerController> WeakPC(Controller);
	GetWorldTimerManager().SetTimer(Handle, FTimerDelegate::CreateLambda([this, WeakPC]()
	{
		if (APlayerController* PC = WeakPC.Get())
		{
			if (ABFPlayerController* BFPC = Cast<ABFPlayerController>(PC))
			{
				BFPC->ClientNotifyDeployAvailable();
			}
		}
	}), Delay, false);
}

void ABFGameMode::RequestDeploy(APlayerController* Controller, EBFSpawnKind PreferredKind)
{
	if (!Controller)
	{
		return;
	}

	const ABFGameState* GS = GetGameState<ABFGameState>();
	if (GS && GS->GetMatchPhase() == EBFMatchPhase::PostMatch)
	{
		return;
	}

	// Already alive: nothing to do.
	if (const ABFCharacter* Char = Cast<ABFCharacter>(Controller->GetPawn()))
	{
		const UBFHealthComponent* Health = Char->GetHealthComponent();
		if (Health && Health->IsAlive())
		{
			return;
		}
	}

	if (PreferredKind == EBFSpawnKind::Squad)
	{
		if (UBFSpawnManager* SpawnManager = UBFSpawnManager::Get(GetWorld()))
		{
			bool bFound = false;
			const FTransform Transform = SpawnManager->FindSpawnOfKind(Controller, EBFSpawnKind::Squad, bFound);
			if (bFound)
			{
				FRotator Rotation = Transform.Rotator();
				Rotation.Pitch = 0.f;
				Rotation.Roll = 0.f;
				RestartPlayerAtTransform(Controller, FTransform(Rotation, Transform.GetLocation()));
				return;
			}
		}
	}

	RestartPlayer(Controller);
}

void ABFGameMode::EndMatchWithWinner(EBFTeam Winner, FName Reason)
{
	if (UBFMatchManager* MatchManager = UBFMatchManager::Get(GetWorld()))
	{
		MatchManager->EndMatch(Winner, Reason);
	}
}
