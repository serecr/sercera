#include "Gameplay/BFGameInstance.h"

#include "Core/BFLog.h"
#include "Gameplay/BFSaveGame.h"
#include "Settings/BFGameSettings.h"
#include "Kismet/GameplayStatics.h"
#include "OnlineSubsystem.h"
#include "OnlineSubsystemUtils.h"
#include "OnlineSessionSettings.h"

UBFGameInstance::UBFGameInstance()
{
}

void UBFGameInstance::Init()
{
	Super::Init();

	LoadProfile();
	EnsureSettings();

	if (Settings)
	{
		// Apply the stored graphics / audio / input configuration before the first level.
		Settings->ApplyAll(this);
	}

	BF_LOG(LogBFGame, Log, TEXT("Profile ready: %s, career level %d"), *GetNickname(), GetCareerLevel());
}

void UBFGameInstance::Shutdown()
{
	SaveProfile();

	if (Settings)
	{
		Settings->SaveToDisk();
	}

	// Never leave a dangling search delegate on the subsystem.
	if (FindSessionsHandle.IsValid())
	{
		if (const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld()))
		{
			Sessions->ClearOnFindSessionsCompleteDelegate_Handle(FindSessionsHandle);
		}
		FindSessionsHandle.Reset();
	}

	Super::Shutdown();
}

// ------------------------------------------------------------------ Profile

void UBFGameInstance::LoadProfile()
{
	if (UGameplayStatics::DoesSaveGameExist(UBFSaveGame::SlotName(), 0))
	{
		Profile = Cast<UBFSaveGame>(UGameplayStatics::LoadGameFromSlot(UBFSaveGame::SlotName(), 0));
	}

	if (!Profile)
	{
		Profile = Cast<UBFSaveGame>(UGameplayStatics::CreateSaveGameObject(UBFSaveGame::StaticClass()));

		// A fresh profile still has to be usable: seed every class at level 1 and
		// hand out the starter cosmetics so the loadout screen is never empty.
		if (Profile)
		{
			const UEnum* ClassEnum = StaticEnum<EBFSoldierClass>();
			const int32 Count = ClassEnum ? ClassEnum->NumEnums() - 1 : 0;
			for (int32 i = 0; i < Count; ++i)
			{
				Profile->FindOrAddClass(static_cast<EBFSoldierClass>(ClassEnum->GetValueByIndex(i)));
			}

			Profile->UnlockedCosmetics.Add(TEXT("Uniform.Standard"));
			Profile->UnlockedCosmetics.Add(TEXT("Helmet.Standard"));
			UGameplayStatics::SaveGameToSlot(Profile, UBFSaveGame::SlotName(), 0);
		}
	}
	else if (Profile->SaveVersion < UBFSaveGame::CurrentVersion)
	{
		// Forward migration point. Fields added later default correctly, so we only
		// need to stamp the version and rewrite the slot.
		Profile->SaveVersion = UBFSaveGame::CurrentVersion;
		UGameplayStatics::SaveGameToSlot(Profile, UBFSaveGame::SlotName(), 0);
	}
}

void UBFGameInstance::EnsureSettings()
{
	if (!Settings)
	{
		Settings = NewObject<UBFGameSettings>(this, UBFGameSettings::StaticClass(), TEXT("BFGameSettings"));
		Settings->LoadFromDisk();
	}
}

FString UBFGameInstance::GetNickname() const
{
	return Profile ? Profile->Nickname : TEXT("Recruit");
}

void UBFGameInstance::SetNickname(const FString& NewNickname)
{
	if (!Profile)
	{
		return;
	}

	FString Clean = NewNickname.TrimStartAndEnd();

	// Keep it sane: length clamp and no control characters. Purely cosmetic field,
	// but it is shown on the scoreboard so it should not be able to break layout.
	Clean.ReplaceInline(TEXT("\n"), TEXT(""));
	Clean.ReplaceInline(TEXT("\r"), TEXT(""));
	Clean.ReplaceInline(TEXT("\t"), TEXT(" "));

	if (Clean.Len() > 20)
	{
		Clean.LeftInline(20);
	}

	if (Clean.IsEmpty())
	{
		Clean = TEXT("Recruit");
	}

	Profile->Nickname = Clean;
	SaveProfile();
	OnProfileChanged.Broadcast();
}

int32 UBFGameInstance::GetCareerLevel() const
{
	return Profile ? FMath::Max(1, Profile->CareerLevel) : 1;
}

int32 UBFGameInstance::GetCareerXP() const
{
	return Profile ? Profile->CareerXP : 0;
}

int32 UBFGameInstance::XPForLevel(int32 Level)
{
	// 2000 at level 1, growing mildly. Reaching level 50 is a long campaign but not
	// an exponential wall, which fits a team objective game rather than a grinder.
	const int32 Clamped = FMath::Max(1, Level);
	return 2000 + (Clamped - 1) * 350;
}

float UBFGameInstance::GetLevelProgressPercent() const
{
	if (!Profile)
	{
		return 0.f;
	}

	// CareerXP is total lifetime XP, so subtract everything spent on earlier levels.
	int32 Consumed = 0;
	for (int32 Level = 1; Level < GetCareerLevel(); ++Level)
	{
		Consumed += XPForLevel(Level);
	}

	const int32 Needed = XPForLevel(GetCareerLevel());
	const int32 Into = FMath::Max(0, Profile->CareerXP - Consumed);

	return Needed > 0 ? FMath::Clamp(static_cast<float>(Into) / static_cast<float>(Needed), 0.f, 1.f) : 0.f;
}

FBFProfileStats UBFGameInstance::GetProfileStats() const
{
	return Profile ? Profile->Stats : FBFProfileStats();
}

int32 UBFGameInstance::GetClassLevel(EBFSoldierClass SoldierClass) const
{
	if (!Profile)
	{
		return 1;
	}

	for (const FBFClassProgress& Entry : Profile->ClassProgress)
	{
		if (Entry.SoldierClass == SoldierClass)
		{
			return FMath::Max(1, Entry.Level);
		}
	}
	return 1;
}

int32 UBFGameInstance::GetClassXP(EBFSoldierClass SoldierClass) const
{
	if (!Profile)
	{
		return 0;
	}

	for (const FBFClassProgress& Entry : Profile->ClassProgress)
	{
		if (Entry.SoldierClass == SoldierClass)
		{
			return Entry.XP;
		}
	}
	return 0;
}

bool UBFGameInstance::IsCosmeticUnlocked(FName CosmeticId) const
{
	return Profile && Profile->UnlockedCosmetics.Contains(CosmeticId);
}

void UBFGameInstance::UnlockCosmetic(FName CosmeticId)
{
	if (Profile && !CosmeticId.IsNone() && !Profile->UnlockedCosmetics.Contains(CosmeticId))
	{
		Profile->UnlockedCosmetics.Add(CosmeticId);
		SaveProfile();
		OnProfileChanged.Broadcast();
	}
}

TArray<FName> UBFGameInstance::GetUnlockedCosmetics() const
{
	return Profile ? Profile->UnlockedCosmetics : TArray<FName>();
}

FBFLoadout UBFGameInstance::GetSavedLoadout(EBFSoldierClass SoldierClass) const
{
	if (Profile)
	{
		if (const FBFLoadout* Found = Profile->SavedLoadouts.Find(SoldierClass))
		{
			return *Found;
		}
	}

	FBFLoadout Default;
	Default.SoldierClass = SoldierClass;
	return Default;
}

void UBFGameInstance::SaveLoadout(EBFSoldierClass SoldierClass, const FBFLoadout& Loadout)
{
	if (!Profile)
	{
		return;
	}

	FBFLoadout Stored = Loadout;
	Stored.SoldierClass = SoldierClass;
	Profile->SavedLoadouts.Add(SoldierClass, Stored);
	SaveProfile();
}

EBFSoldierClass UBFGameInstance::GetLastPlayedClass() const
{
	return Profile ? Profile->LastPlayedClass : EBFSoldierClass::Rifleman;
}

void UBFGameInstance::SetLastPlayedClass(EBFSoldierClass SoldierClass)
{
	if (Profile)
	{
		Profile->LastPlayedClass = SoldierClass;
	}
}

void UBFGameInstance::CommitMatchResults(const FBFMatchRecord& Record, int32 EarnedXP, bool bWon)
{
	if (!Profile)
	{
		return;
	}

	const int32 ClampedXP = FMath::Clamp(EarnedXP, 0, 100000);

	Profile->CareerXP += ClampedXP;

	// Level up as many times as the XP allows, so a long match can grant more than one.
	int32 Consumed = 0;
	for (int32 Level = 1; Level < Profile->CareerLevel; ++Level)
	{
		Consumed += XPForLevel(Level);
	}

	while (Profile->CareerXP - Consumed >= XPForLevel(Profile->CareerLevel))
	{
		Consumed += XPForLevel(Profile->CareerLevel);
		++Profile->CareerLevel;
	}

	FBFProfileStats& Stats = Profile->Stats;
	Stats.MatchesPlayed += 1;
	Stats.MatchesWon += bWon ? 1 : 0;
	Stats.Kills += Record.Kills;
	Stats.Deaths += Record.Deaths;
	Stats.Assists += Record.Assists;
	Stats.Revives += Record.Revives;
	Stats.SectorsCaptured += Record.Captures;
	Stats.StructuresBuilt += Record.Builds;

	FBFClassProgress& ClassEntry = Profile->FindOrAddClass(Profile->LastPlayedClass);
	ClassEntry.XP += ClampedXP;
	ClassEntry.MatchesPlayed += 1;
	while (ClassEntry.XP >= XPForLevel(ClassEntry.Level) * 0.6f)
	{
		// Class levels advance faster than career levels: they gate class specific
		// cosmetics and sidearms rather than the whole roster.
		ClassEntry.XP -= FMath::RoundToInt(XPForLevel(ClassEntry.Level) * 0.6f);
		++ClassEntry.Level;
	}

	SaveProfile();
	OnProfileChanged.Broadcast();

	BF_LOG(LogBFGame, Log, TEXT("Match committed: %+d XP, career level %d, %s"),
		ClampedXP, Profile->CareerLevel, bWon ? TEXT("victory") : TEXT("defeat"));
}

void UBFGameInstance::SaveProfile()
{
	if (Profile)
	{
		UGameplayStatics::SaveGameToSlot(Profile, UBFSaveGame::SlotName(), 0);
	}
}

// ------------------------------------------------------------------ Servers

void UBFGameInstance::RefreshServerList()
{
	if (bSearching)
	{
		return;
	}

	const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld());
	if (!Sessions.IsValid())
	{
		// No online subsystem available (very stripped build). Report an empty list
		// rather than leaving the browser spinning forever.
		CachedServers.Reset();
		OnServerListReady.Broadcast(CachedServers);
		return;
	}

	SessionSearch = MakeShared<FOnlineSessionSearch>();
	SessionSearch->MaxSearchResults = MaxSearchResults;
	SessionSearch->bIsLanQuery = false;
	SessionSearch->QuerySettings.Set(SEARCH_PRESENCE, true, EOnlineComparisonOp::Equals);

	bSearching = true;

	FindSessionsHandle = Sessions->AddOnFindSessionsCompleteDelegate_Handle(
		FOnFindSessionsCompleteDelegate::CreateUObject(this, &UBFGameInstance::HandleFindSessionsComplete));

	if (!Sessions->FindSessions(0, SessionSearch.ToSharedRef()))
	{
		HandleFindSessionsComplete(false);
	}
}

void UBFGameInstance::HandleFindSessionsComplete(bool bSuccess)
{
	if (const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld()))
	{
		Sessions->ClearOnFindSessionsCompleteDelegate_Handle(FindSessionsHandle);
	}
	FindSessionsHandle.Reset();

	bSearching = false;

	if (bSuccess)
	{
		PublishSearchResults();
	}
	else
	{
		CachedServers.Reset();
		BF_LOG(LogBFGame, Warning, TEXT("Session search failed"));
	}

	OnServerListReady.Broadcast(CachedServers);
}

void UBFGameInstance::PublishSearchResults()
{
	CachedServers.Reset();

	if (!SessionSearch.IsValid())
	{
		return;
	}

	for (const FOnlineSessionSearchResult& Result : SessionSearch->SearchResults)
	{
		if (!Result.IsValid())
		{
			continue;
		}

		FBFServerEntry Entry;

		// Hosts advertise these keys in HostListenServer / the dedicated server startup.
		FString Value;
		Entry.ServerName = Result.Session.OwningUserName;
		if (Result.Session.SessionSettings.Get(TEXT("BF_SERVERNAME"), Value) && !Value.IsEmpty())
		{
			Entry.ServerName = Value;
		}
		if (Result.Session.SessionSettings.Get(TEXT("BF_MAP"), Value))
		{
			Entry.MapName = Value;
		}
		if (Result.Session.SessionSettings.Get(TEXT("BF_MODE"), Value))
		{
			Entry.GameMode = Value;
		}
		if (Result.Session.SessionSettings.Get(TEXT("BF_FRONTLINE"), Value))
		{
			Entry.FrontlineState = Value;
		}

		Entry.MaxPlayers = Result.Session.SessionSettings.NumPublicConnections;
		Entry.PlayerCount = FMath::Max(0, Entry.MaxPlayers - Result.Session.NumOpenPublicConnections);
		Entry.PingMs = Result.PingInMs;

		if (const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld()))
		{
			FString ConnectInfo;
			if (Sessions->GetResolvedConnectString(Result, NAME_GamePort, ConnectInfo))
			{
				Entry.ConnectString = ConnectInfo;
			}
		}

		CachedServers.Add(Entry);
	}

	BF_LOG(LogBFGame, Log, TEXT("Server browser: %d results"), CachedServers.Num());
}

void UBFGameInstance::HostListenServer(const FString& ServerName, FName MapName, int32 MaxPlayers)
{
	PendingHostMap = MapName;
	PendingHostMaxPlayers = FMath::Clamp(MaxPlayers, 2, 64);

	const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld());
	if (!Sessions.IsValid())
	{
		// No subsystem: still start the listen server, it is simply not advertised.
		HandleCreateSessionComplete(NAME_GameSession, true);
		return;
	}

	// Drop any stale session first, otherwise creation fails with AlreadyExists.
	if (Sessions->GetNamedSession(NAME_GameSession))
	{
		Sessions->DestroySession(NAME_GameSession);
	}

	FOnlineSessionSettings SessionSettings;
	SessionSettings.bIsLANMatch = false;
	SessionSettings.bIsDedicated = false;
	SessionSettings.NumPublicConnections = PendingHostMaxPlayers;
	SessionSettings.NumPrivateConnections = 0;
	SessionSettings.bShouldAdvertise = true;
	SessionSettings.bAllowJoinInProgress = true;
	SessionSettings.bAllowJoinViaPresence = true;
	SessionSettings.bUsesPresence = true;
	SessionSettings.bAllowInvites = true;

	const FString CleanName = ServerName.IsEmpty()
		? FString::Printf(TEXT("%s's front"), *GetNickname())
		: ServerName;

	SessionSettings.Set(TEXT("BF_SERVERNAME"), CleanName, EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
	SessionSettings.Set(TEXT("BF_MAP"), MapName.ToString(), EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
	SessionSettings.Set(TEXT("BF_MODE"), FString(TEXT("Frontline")), EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
	SessionSettings.Set(TEXT("BF_FRONTLINE"), FString(TEXT("Balanced")), EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);

	CreateSessionHandle = Sessions->AddOnCreateSessionCompleteDelegate_Handle(
		FOnCreateSessionCompleteDelegate::CreateUObject(this, &UBFGameInstance::HandleCreateSessionComplete));

	if (!Sessions->CreateSession(0, NAME_GameSession, SessionSettings))
	{
		HandleCreateSessionComplete(NAME_GameSession, false);
	}
}

void UBFGameInstance::HandleCreateSessionComplete(FName SessionName, bool bSuccess)
{
	if (const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld()))
	{
		Sessions->ClearOnCreateSessionCompleteDelegate_Handle(CreateSessionHandle);
	}
	CreateSessionHandle.Reset();

	if (!bSuccess)
	{
		BF_LOG(LogBFGame, Warning, TEXT("Session creation failed, hosting unadvertised"));
	}

	if (UWorld* World = GetWorld())
	{
		const FString Travel = FString::Printf(TEXT("/Game/Maps/%s?listen?MaxPlayers=%d"),
			*PendingHostMap.ToString(), PendingHostMaxPlayers);
		World->ServerTravel(Travel, true);
	}
}

void UBFGameInstance::EndHostedSession()
{
	if (const IOnlineSessionPtr Sessions = Online::GetSessionInterface(GetWorld()))
	{
		if (Sessions->GetNamedSession(NAME_GameSession))
		{
			Sessions->DestroySession(NAME_GameSession);
		}
	}
}
