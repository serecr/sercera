#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Core/BFTypes.h"
#include "BFFootstepComponent.generated.h"

class USoundBase;

/** Per-surface footstep bank. Designers fill one row per surface type. */
USTRUCT(BlueprintType)
struct FBFFootstepSurfaceSet
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) EBFSurfaceType Surface = EBFSurfaceType::Default;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> WalkSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> SprintSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> CrouchSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> LandSound;
	/** Metres at which an enemy can hear this step at full stride. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) float AudibleRange = 2200.f;
};

/**
 * Drives spatialised footsteps from the animation notify OR from a distance
 * accumulator when no animation is available yet (so audio works day one).
 */
UCLASS(ClassGroup = (BrokenFront), meta = (BlueprintSpawnableComponent))
class BROKENFRONT_API UBFFootstepComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBFFootstepComponent();

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** Call from an AnimNotify for frame-accurate steps; falls back to the stride accumulator otherwise. */
	UFUNCTION(BlueprintCallable, Category = "Footsteps")
	void PlayFootstep();

	UFUNCTION(BlueprintCallable, Category = "Footsteps")
	void PlayLanding(float FallSpeed);

	UFUNCTION(BlueprintPure, Category = "Footsteps")
	EBFSurfaceType GetCurrentSurface() const { return CurrentSurface; }

	/** Disable the automatic accumulator once real footstep notifies exist. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	bool bUseStrideAccumulator = true;

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<FBFFootstepSurfaceSet> SurfaceSets;

	/** Centimetres of travel per step while walking. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config", meta = (ClampMin = "20.0"))
	float StrideLength = 165.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float SprintVolumeScale = 1.35f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float CrouchVolumeScale = 0.45f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float ProneVolumeScale = 0.2f;

private:
	float DistanceAccumulator = 0.f;
	FVector LastLocation = FVector::ZeroVector;
	EBFSurfaceType CurrentSurface = EBFSurfaceType::Default;

	const FBFFootstepSurfaceSet* FindSet(EBFSurfaceType Surface) const;
	EBFSurfaceType TraceSurface() const;
};
