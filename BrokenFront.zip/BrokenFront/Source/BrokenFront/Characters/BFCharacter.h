#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Core/BFTypes.h"
#include "BFCharacter.generated.h"

class UCameraComponent;
class USkeletalMeshComponent;
class USpringArmComponent;
class UInputAction;
class UInputMappingContext;
struct FInputActionValue;
class UBFHealthComponent;
class UBFInventoryComponent;
class UBFMudComponent;
class UBFFootstepComponent;
class UBFRadioComponent;
class UBFBuildComponent;
class UBFSoldierClassDataAsset;
class ABFWeaponBase;

/**
 * The player soldier. First person only during gameplay: the owning client sees
 * ArmsMesh (arms + weapon), everyone else sees the full body mesh. Server owns
 * every gameplay decision; the camera, sway and mud are local-only polish.
 */
UCLASS()
class BROKENFRONT_API ABFCharacter : public ACharacter
{
	GENERATED_BODY()

public:
	ABFCharacter();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void PossessedBy(AController* NewController) override;
	virtual void OnRep_PlayerState() override;
	virtual void SetupPlayerInputComponent(class UInputComponent* PlayerInputComponent) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void Landed(const FHitResult& Hit) override;
	virtual FVector GetPawnViewLocation() const override;

	// ---------- Accessors ----------
	UFUNCTION(BlueprintPure, Category = "BrokenFront") UCameraComponent* GetFirstPersonCamera() const { return FirstPersonCamera; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") USkeletalMeshComponent* GetArmsMesh() const { return ArmsMesh; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") UBFHealthComponent* GetHealthComponent() const { return HealthComponent; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") UBFInventoryComponent* GetInventory() const { return Inventory; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") UBFBuildComponent* GetBuildComponent() const { return BuildComponent; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") UBFRadioComponent* GetRadio() const { return Radio; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") UBFMudComponent* GetMud() const { return MudComponent; }

	UFUNCTION(BlueprintPure, Category = "BrokenFront") EBFStance GetStance() const { return Stance; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") bool IsSprinting() const { return bSprinting; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") bool IsAiming() const { return bAiming; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") bool IsBraced() const { return bBraced; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") float GetLeanAmount() const { return LeanAmount; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") float GetStamina() const { return Stamina; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") float GetStaminaPercent() const { return MaxStamina > 0.f ? Stamina / MaxStamina : 0.f; }
	UFUNCTION(BlueprintPure, Category = "BrokenFront") EBFTeam GetTeam() const;
	UFUNCTION(BlueprintPure, Category = "BrokenFront") bool IsIndoors() const { return bIndoors; }

	/** Where the weapon should trace from: camera location + rotation. */
	UFUNCTION(BlueprintPure, Category = "BrokenFront")
	void GetAimTransform(FVector& OutLocation, FRotator& OutRotation) const;

	/** Applied by the weapon on the owning client; smoothly recovers. */
	void AddRecoil(float Pitch, float Yaw);

	/** Server: applies a class data asset (stats, speeds, build resources). */
	void ApplySoldierClass(UBFSoldierClassDataAsset* ClassAsset);

	UFUNCTION(BlueprintPure, Category = "BrokenFront")
	UBFSoldierClassDataAsset* GetSoldierClass() const { return SoldierClass; }

	/** Server: called by the game mode before destroying/ragdolling this pawn. */
	void HandleDeath(AActor* Killer, FName HitZone);

	// ---------- Input handlers (public so Blueprint child classes can rebind) ----------
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_Move(const FInputActionValue& Value);
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_Look(const FInputActionValue& Value);
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_JumpStart();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_JumpStop();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_SprintStart();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_SprintStop();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_CrouchToggle();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_ProneToggle();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_LeanLeft(const FInputActionValue& Value);
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_LeanRight(const FInputActionValue& Value);
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_FireStart();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_FireStop();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_AimStart();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_AimStop();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_Reload();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_CycleFireMode();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_NextWeapon();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_PrevWeapon();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_SelectPrimary();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_SelectSecondary();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_SelectEquipment();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_Inspect();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_Interact();
	UFUNCTION(BlueprintCallable, Category = "Input") void Input_UseEquipment();

protected:
	// ---------- Components ----------
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USkeletalMeshComponent> ArmsMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UCameraComponent> FirstPersonCamera;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBFHealthComponent> HealthComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBFInventoryComponent> Inventory;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBFMudComponent> MudComponent;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBFFootstepComponent> Footsteps;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBFRadioComponent> Radio;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBFBuildComponent> BuildComponent;

	// ---------- Enhanced Input ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input")
	TSoftObjectPtr<UInputMappingContext> DefaultMappingContext;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Move;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Look;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Jump;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Sprint;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Crouch;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Prone;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_LeanLeft;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_LeanRight;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Fire;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Aim;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Reload;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_FireMode;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_NextWeapon;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_PrevWeapon;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Primary;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Secondary;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Equipment;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Inspect;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_Interact;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Input") TObjectPtr<UInputAction> IA_UseEquipment;

	// ---------- Movement tuning ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float WalkSpeed = 340.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float SprintSpeed = 620.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float CrouchSpeed = 190.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float ProneSpeed = 80.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float AimSpeedScale = 0.62f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float StandingHalfHeight = 90.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float CrouchHalfHeight = 60.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float ProneHalfHeight = 34.f;
	/** Seconds to blend between stance capsule heights. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Movement") float StanceBlendSpeed = 6.f;

	// ---------- Stamina ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Stamina") float MaxStamina = 100.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Stamina") float SprintStaminaDrain = 12.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Stamina") float StaminaRegen = 9.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Stamina") float StaminaRegenDelay = 1.2f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Stamina") float JumpStaminaCost = 14.f;
	/** Below this you cannot start sprinting again. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Stamina") float SprintStaminaThreshold = 15.f;

	// ---------- Camera feel (deliberately restrained) ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float BaseFOV = 90.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float SwayAmplitude = 0.55f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float SwayFrequency = 6.2f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float AimSwayScale = 0.25f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float BreathAmplitude = 0.12f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float MaxLeanAngle = 16.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float LeanBlendSpeed = 7.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float LeanLateralOffset = 28.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Camera") float MouseSensitivity = 1.f;

	// ---------- Interaction ----------
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Interaction") float InteractRange = 220.f;

	// ---------- Replicated state ----------
	UPROPERTY(ReplicatedUsing = OnRep_Stance, BlueprintReadOnly, Category = "State")
	EBFStance Stance = EBFStance::Standing;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	bool bSprinting = false;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	bool bAiming = false;

	/** Resting the weapon on a parapet / sandbag: big accuracy bonus. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	bool bBraced = false;

	/** -1 left .. +1 right, replicated at low precision for remote lean poses. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float LeanAmount = 0.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	TObjectPtr<UBFSoldierClassDataAsset> SoldierClass;

	UFUNCTION() void OnRep_Stance();

	// ---------- Server RPCs ----------
	UFUNCTION(Server, Reliable) void ServerSetStance(EBFStance NewStance);
	UFUNCTION(Server, Reliable) void ServerSetSprinting(bool bNewSprinting);
	UFUNCTION(Server, Reliable) void ServerSetAiming(bool bNewAiming);
	UFUNCTION(Server, Unreliable) void ServerSetLean(float NewLean);
	UFUNCTION(Server, Reliable) void ServerInteract(AActor* Target);

	UFUNCTION() void OnHealthDowned(bool bIsDowned);
	UFUNCTION() void OnHealthDeath(AActor* Killer, const FName& HitZone);

private:
	// Local-only camera state.
	float SwayTime = 0.f;
	FVector2D CurrentSwayOffset = FVector2D::ZeroVector;
	FVector2D RecoilOffset = FVector2D::ZeroVector;
	FVector2D RecoilRecoveryTarget = FVector2D::ZeroVector;
	float TargetLean = 0.f;
	float CurrentCapsuleHalfHeight = 90.f;
	float TimeSinceStaminaUse = 0.f;
	float Stamina = 100.f;
	bool bIndoors = false;
	float IndoorsCheckTimer = 0.f;
	FVector BaseCameraLocalLocation = FVector::ZeroVector;

	void UpdateStance(float DeltaSeconds);
	void UpdateStamina(float DeltaSeconds);
	void UpdateCameraFeel(float DeltaSeconds);
	void UpdateRecoil(float DeltaSeconds);
	void UpdateBracing();
	void UpdateIndoors();
	void ApplyMovementSpeed();
	bool CanEnterStance(EBFStance NewStance) const;
	AActor* TraceInteractable() const;
	float GetStanceHalfHeight(EBFStance InStance) const;
};
