#include "Characters/BFFootstepComponent.h"
#include "Characters/BFCharacter.h"
#include "Systems/BFAudioManager.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "PhysicalMaterials/PhysicalMaterial.h"

UBFFootstepComponent::UBFFootstepComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.05f;
	SetIsReplicatedByDefault(false);
}

void UBFFootstepComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char)
	{
		return;
	}

	CurrentSurface = TraceSurface();

	if (!bUseStrideAccumulator)
	{
		return;
	}

	const UCharacterMovementComponent* Move = Char->GetCharacterMovement();
	const FVector Location = Char->GetActorLocation();

	if (LastLocation.IsNearlyZero())
	{
		LastLocation = Location;
		return;
	}

	if (Move && !Move->IsFalling() && Move->Velocity.Size2D() > 40.f)
	{
		DistanceAccumulator += FVector::Dist2D(Location, LastLocation);

		float EffectiveStride = StrideLength;
		if (const ABFCharacter* BFChar = Cast<ABFCharacter>(Char))
		{
			if (BFChar->GetStance() == EBFStance::Crouched) { EffectiveStride *= 0.7f; }
			else if (BFChar->GetStance() == EBFStance::Prone) { EffectiveStride *= 0.45f; }
			else if (BFChar->IsSprinting()) { EffectiveStride *= 1.25f; }
		}

		if (DistanceAccumulator >= EffectiveStride)
		{
			DistanceAccumulator = 0.f;
			PlayFootstep();
		}
	}
	else
	{
		DistanceAccumulator = FMath::Max(0.f, DistanceAccumulator - 60.f * DeltaTime);
	}

	LastLocation = Location;
}

const FBFFootstepSurfaceSet* UBFFootstepComponent::FindSet(EBFSurfaceType Surface) const
{
	const FBFFootstepSurfaceSet* Exact = SurfaceSets.FindByPredicate(
		[Surface](const FBFFootstepSurfaceSet& Set) { return Set.Surface == Surface; });

	if (Exact)
	{
		return Exact;
	}

	return SurfaceSets.FindByPredicate(
		[](const FBFFootstepSurfaceSet& Set) { return Set.Surface == EBFSurfaceType::Default; });
}

EBFSurfaceType UBFFootstepComponent::TraceSurface() const
{
	const ACharacter* Char = Cast<ACharacter>(GetOwner());
	const UWorld* World = GetWorld();
	if (!Char || !World)
	{
		return EBFSurfaceType::Default;
	}

	// Prefer the movement component's cached floor - free and already computed.
	if (const UCharacterMovementComponent* Move = Char->GetCharacterMovement())
	{
		const FFindFloorResult& Floor = Move->CurrentFloor;
		if (Floor.bBlockingHit && Floor.HitResult.PhysMaterial.IsValid())
		{
			const int32 Index = static_cast<int32>(Floor.HitResult.PhysMaterial->SurfaceType);
			if (Index >= 1 && Index <= 6)
			{
				return static_cast<EBFSurfaceType>(Index);
			}
			return EBFSurfaceType::Default;
		}
	}

	const FVector Start = Char->GetActorLocation();
	const FVector End = Start - FVector(0.f, 0.f, 150.f);
	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFFootstepSurface), false, Char);
	Params.bReturnPhysicalMaterial = true;

	FHitResult Hit;
	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params) && Hit.PhysMaterial.IsValid())
	{
		const int32 Index = static_cast<int32>(Hit.PhysMaterial->SurfaceType);
		if (Index >= 1 && Index <= 6)
		{
			return static_cast<EBFSurfaceType>(Index);
		}
	}

	return EBFSurfaceType::Default;
}

void UBFFootstepComponent::PlayFootstep()
{
	const ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char)
	{
		return;
	}

	const FBFFootstepSurfaceSet* Set = FindSet(CurrentSurface);
	if (!Set)
	{
		return;
	}

	EBFStance Stance = EBFStance::Standing;
	bool bSprinting = false;
	if (const ABFCharacter* BFChar = Cast<ABFCharacter>(Char))
	{
		Stance = BFChar->GetStance();
		bSprinting = BFChar->IsSprinting();
	}

	TSoftObjectPtr<USoundBase> SoundPtr = Set->WalkSound;
	float Volume = 1.f;

	if (Stance == EBFStance::Prone)
	{
		SoundPtr = Set->CrouchSound.IsNull() ? Set->WalkSound : Set->CrouchSound;
		Volume = ProneVolumeScale;
	}
	else if (Stance == EBFStance::Crouched)
	{
		SoundPtr = Set->CrouchSound.IsNull() ? Set->WalkSound : Set->CrouchSound;
		Volume = CrouchVolumeScale;
	}
	else if (bSprinting)
	{
		SoundPtr = Set->SprintSound.IsNull() ? Set->WalkSound : Set->SprintSound;
		Volume = SprintVolumeScale;
	}

	if (USoundBase* Sound = SoundPtr.LoadSynchronous())
	{
		// Routed through the audio manager so bunker occlusion and weather ducking apply.
		ABFAudioManager::PlaySpatialised(GetWorld(), Sound, Char->GetActorLocation(), Volume);
	}
}

void UBFFootstepComponent::PlayLanding(float FallSpeed)
{
	const FBFFootstepSurfaceSet* Set = FindSet(CurrentSurface);
	const AActor* Owner = GetOwner();
	if (!Set || !Owner)
	{
		return;
	}

	if (USoundBase* Sound = Set->LandSound.LoadSynchronous())
	{
		const float Volume = FMath::GetMappedRangeValueClamped(FVector2D(200.f, 1200.f), FVector2D(0.4f, 1.4f), FMath::Abs(FallSpeed));
		ABFAudioManager::PlaySpatialised(GetWorld(), Sound, Owner->GetActorLocation(), Volume);
	}
}
