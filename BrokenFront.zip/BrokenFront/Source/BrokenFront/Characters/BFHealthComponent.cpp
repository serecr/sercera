#include "Characters/BFHealthComponent.h"
#include "Core/BFLog.h"
#include "GameFramework/Pawn.h"
#include "Net/UnrealNetwork.h"

UBFHealthComponent::UBFHealthComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.1f; // health does not need 120 Hz
	SetIsReplicatedByDefault(true);
}

void UBFHealthComponent::BeginPlay()
{
	Super::BeginPlay();

	if (AActor* Owner = GetOwner())
	{
		if (Owner->HasAuthority())
		{
			Owner->OnTakePointDamage.AddDynamic(this, &UBFHealthComponent::HandlePointDamage);
			Owner->OnTakeRadialDamage.AddDynamic(this, &UBFHealthComponent::HandleRadialDamage);
			Health = MaxHealth;
		}
	}
}

void UBFHealthComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UBFHealthComponent, Health);
	DOREPLIFETIME(UBFHealthComponent, MaxHealth);
	DOREPLIFETIME(UBFHealthComponent, bDowned);
	DOREPLIFETIME(UBFHealthComponent, bDead);
	DOREPLIFETIME_CONDITION(UBFHealthComponent, BleedOutRemaining, COND_OwnerOnly);
}

void UBFHealthComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	AActor* Owner = GetOwner();
	if (!Owner || !Owner->HasAuthority() || bDead)
	{
		return;
	}

	if (bDowned)
	{
		BleedOutRemaining = FMath::Max(0.f, BleedOutRemaining - DeltaTime);
		if (BleedOutRemaining <= 0.f)
		{
			Kill(LastDamageInstigator.Get(), LastHitZone);
		}
		return;
	}

	TimeSinceLastDamage += DeltaTime;

	const float RegenFloor = MaxHealth * RegenFloorFraction;
	if (RegenPerSecond > 0.f && TimeSinceLastDamage >= RegenDelayAfterDamage && Health < MaxHealth && Health >= RegenFloor)
	{
		const float Target = FMath::Min(MaxHealth, Health + RegenPerSecond * DeltaTime);
		if (!FMath::IsNearlyEqual(Target, Health))
		{
			const float Delta = Target - Health;
			Health = Target;
			OnHealthChanged.Broadcast(Health, Delta, nullptr);
		}
	}
}

void UBFHealthComponent::InitializeMaxHealth(float NewMaxHealth, bool bRefill)
{
	if (!GetOwner() || !GetOwner()->HasAuthority())
	{
		return;
	}

	MaxHealth = FMath::Max(1.f, NewMaxHealth);
	if (bRefill)
	{
		Health = MaxHealth;
		OnHealthChanged.Broadcast(Health, MaxHealth, nullptr);
	}
	else
	{
		Health = FMath::Min(Health, MaxHealth);
	}
}

void UBFHealthComponent::ApplyHealthDelta(float Delta, AActor* EventInstigator, FName HitZone)
{
	AActor* Owner = GetOwner();
	if (!Owner || !Owner->HasAuthority() || bDead || FMath::IsNearlyZero(Delta))
	{
		return;
	}

	// Healing a downed soldier does nothing until they are revived - that is the Medic's job.
	if (bDowned && Delta > 0.f)
	{
		return;
	}

	if (Delta < 0.f)
	{
		TimeSinceLastDamage = 0.f;
		LastDamageInstigator = EventInstigator;
		LastHitZone = HitZone;
	}

	const float OldHealth = Health;
	Health = FMath::Clamp(Health + Delta, 0.f, MaxHealth);
	const float AppliedDelta = Health - OldHealth;

	if (!FMath::IsNearlyZero(AppliedDelta))
	{
		OnHealthChanged.Broadcast(Health, AppliedDelta, EventInstigator);
	}

	if (Health <= 0.f)
	{
		const bool bOverkill = (-Delta) >= LethalOverkillThreshold;
		if (bEnableDownedState && !bOverkill)
		{
			EnterDownedState(EventInstigator, HitZone);
		}
		else
		{
			Kill(EventInstigator, HitZone);
		}
	}
}

void UBFHealthComponent::EnterDownedState(AActor* EventInstigator, FName HitZone)
{
	bDowned = true;
	Health = 0.f;
	BleedOutRemaining = BleedOutDuration;
	LastDamageInstigator = EventInstigator;
	LastHitZone = HitZone;

	OnDownedStateChanged.Broadcast(true);
	BF_LOG(LogBFCombat, Verbose, TEXT("%s is downed, %.0fs to bleed out"), *GetNameSafe(GetOwner()), BleedOutDuration);
}

bool UBFHealthComponent::Revive(AActor* Reviver, float HealthFraction)
{
	AActor* Owner = GetOwner();
	if (!Owner || !Owner->HasAuthority() || !bDowned || bDead)
	{
		return false;
	}

	bDowned = false;
	BleedOutRemaining = 0.f;
	Health = FMath::Clamp(MaxHealth * HealthFraction, 1.f, MaxHealth);

	OnDownedStateChanged.Broadcast(false);
	OnHealthChanged.Broadcast(Health, Health, Reviver);
	return true;
}

void UBFHealthComponent::Kill(AActor* Killer, FName HitZone)
{
	AActor* Owner = GetOwner();
	if (!Owner || !Owner->HasAuthority() || bDead)
	{
		return;
	}

	bDead = true;
	bDowned = false;
	Health = 0.f;
	BleedOutRemaining = 0.f;

	OnDeath.Broadcast(Killer, HitZone);
}

void UBFHealthComponent::ResetForRespawn()
{
	if (!GetOwner() || !GetOwner()->HasAuthority())
	{
		return;
	}

	bDead = false;
	bDowned = false;
	BleedOutRemaining = 0.f;
	TimeSinceLastDamage = BIG_NUMBER;
	LastDamageInstigator = nullptr;
	Health = MaxHealth;
	OnHealthChanged.Broadcast(Health, MaxHealth, nullptr);
}

void UBFHealthComponent::HandlePointDamage(AActor* /*DamagedActor*/, float Damage, AController* InstigatedBy,
	FVector /*HitLocation*/, UPrimitiveComponent* /*HitComponent*/, FName BoneName,
	FVector /*ShotDirection*/, const UDamageType* /*DamageType*/, AActor* /*DamageCauser*/)
{
	ApplyHealthDelta(-Damage, InstigatedBy ? InstigatedBy->GetPawn() : nullptr, BoneName);
}

void UBFHealthComponent::HandleRadialDamage(AActor* /*DamagedActor*/, float Damage, const UDamageType* /*DamageType*/,
	FVector /*Origin*/, const FHitResult& /*HitInfo*/, AController* InstigatedBy, AActor* /*DamageCauser*/)
{
	ApplyHealthDelta(-Damage, InstigatedBy ? InstigatedBy->GetPawn() : nullptr, NAME_None);
}

void UBFHealthComponent::OnRep_Health(float OldHealth)
{
	OnHealthChanged.Broadcast(Health, Health - OldHealth, nullptr);
}

void UBFHealthComponent::OnRep_Downed()
{
	OnDownedStateChanged.Broadcast(bDowned);
}
