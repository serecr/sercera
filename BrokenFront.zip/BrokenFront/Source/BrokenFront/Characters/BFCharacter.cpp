#include "Characters/BFCharacter.h"

#include "Camera/CameraComponent.h"
#include "Characters/BFFootstepComponent.h"
#include "Characters/BFHealthComponent.h"
#include "Characters/BFMudComponent.h"
#include "Components/CapsuleComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Core/BFInteractable.h"
#include "Core/BFLog.h"
#include "Data/BFSoldierClassDataAsset.h"
#include "EnhancedInputComponent.h"
#include "EnhancedInputSubsystems.h"
#include "Engine/LocalPlayer.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "GameFramework/PlayerController.h"
#include "Gameplay/BFPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "Systems/BFBuildComponent.h"
#include "Systems/BFRadioComponent.h"
#include "Weapons/BFInventoryComponent.h"
#include "Weapons/BFWeaponBase.h"

ABFCharacter::ABFCharacter()
{
	PrimaryActorTick.bCanEverTick = true;

	bUseControllerRotationYaw = true;

	UCapsuleComponent* Capsule = GetCapsuleComponent();
	Capsule->InitCapsuleSize(38.f, StandingHalfHeight);
	Capsule->SetCollisionResponseToChannel(ECC_Camera, ECR_Ignore);

	UCharacterMovementComponent* Move = GetCharacterMovement();
	Move->MaxWalkSpeed = WalkSpeed;
	Move->MaxWalkSpeedCrouched = CrouchSpeed;
	Move->NavAgentProps.bCanCrouch = true;
	Move->JumpZVelocity = 420.f;
	Move->AirControl = 0.18f;
	Move->BrakingDecelerationWalking = 1600.f;
	Move->GroundFriction = 7.f;
	Move->SetWalkableFloorAngle(50.f); // trench walls and crater slopes
	Move->bUseFlatBaseForFloorChecks = true;
	Move->RotationRate = FRotator(0.f, 720.f, 0.f);

	// The full body mesh is what other players see. The owner sees only the arms.
	GetMesh()->SetOwnerNoSee(true);
	GetMesh()->SetCollisionObjectType(ECC_Pawn);
	GetMesh()->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
	GetMesh()->SetCollisionResponseToAllChannels(ECR_Ignore);
	GetMesh()->SetCollisionResponseToChannel(ECC_GameTraceChannel1, ECR_Block); // weapon trace, per-bone damage
	GetMesh()->SetCollisionResponseToChannel(ECC_Visibility, ECR_Block);
	GetMesh()->bReceivesDecals = false;

	FirstPersonCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
	FirstPersonCamera->SetupAttachment(Capsule);
	FirstPersonCamera->SetRelativeLocation(FVector(6.f, 0.f, StandingHalfHeight - 18.f));
	FirstPersonCamera->bUsePawnControlRotation = true;
	FirstPersonCamera->FieldOfView = BaseFOV;

	ArmsMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("ArmsMesh"));
	ArmsMesh->SetupAttachment(FirstPersonCamera);
	ArmsMesh->SetOnlyOwnerSee(true);
	ArmsMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	ArmsMesh->bCastDynamicShadow = false;
	ArmsMesh->CastShadow = false;
	ArmsMesh->SetRelativeLocation(FVector(0.f, 0.f, -12.f));

	HealthComponent = CreateDefaultSubobject<UBFHealthComponent>(TEXT("HealthComponent"));
	Inventory = CreateDefaultSubobject<UBFInventoryComponent>(TEXT("Inventory"));
	MudComponent = CreateDefaultSubobject<UBFMudComponent>(TEXT("MudComponent"));
	Footsteps = CreateDefaultSubobject<UBFFootstepComponent>(TEXT("Footsteps"));
	Radio = CreateDefaultSubobject<UBFRadioComponent>(TEXT("Radio"));
	BuildComponent = CreateDefaultSubobject<UBFBuildComponent>(TEXT("BuildComponent"));

	NetUpdateFrequency = 66.f;
	MinNetUpdateFrequency = 22.f;
	NetCullDistanceSquared = 1500000000.f; // large map, long sight lines
}

void ABFCharacter::BeginPlay()
{
	Super::BeginPlay();

	CurrentCapsuleHalfHeight = StandingHalfHeight;
	Stamina = MaxStamina;
	BaseCameraLocalLocation = FirstPersonCamera->GetRelativeLocation();

	if (HealthComponent)
	{
		HealthComponent->OnDownedStateChanged.AddDynamic(this, &ABFCharacter::OnHealthDowned);
		HealthComponent->OnDeath.AddDynamic(this, &ABFCharacter::OnHealthDeath);
	}

	if (MudComponent)
	{
		MudComponent->RegisterMesh(ArmsMesh);
		MudComponent->RegisterMesh(GetMesh());
	}

	if (IsLocallyControlled())
	{
		if (APlayerController* PC = Cast<APlayerController>(GetController()))
		{
			if (ULocalPlayer* LP = PC->GetLocalPlayer())
			{
				if (UEnhancedInputLocalPlayerSubsystem* Subsystem = LP->GetSubsystem<UEnhancedInputLocalPlayerSubsystem>())
				{
					if (UInputMappingContext* Context = DefaultMappingContext.LoadSynchronous())
					{
						Subsystem->AddMappingContext(Context, 0);
					}
				}
			}
		}
	}
}

void ABFCharacter::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ABFCharacter, Stance);
	DOREPLIFETIME(ABFCharacter, bSprinting);
	DOREPLIFETIME(ABFCharacter, bAiming);
	DOREPLIFETIME(ABFCharacter, bBraced);
	DOREPLIFETIME(ABFCharacter, SoldierClass);
	DOREPLIFETIME_CONDITION(ABFCharacter, LeanAmount, COND_SkipOwner);
}

void ABFCharacter::PossessedBy(AController* NewController)
{
	Super::PossessedBy(NewController);

	// Apply the loadout chosen in the deploy screen.
	if (HasAuthority())
	{
		if (ABFPlayerState* PS = GetPlayerState<ABFPlayerState>())
		{
			ApplySoldierClass(PS->GetSelectedClassAsset());
			if (Inventory)
			{
				Inventory->ServerApplyLoadout(PS->GetSelectedLoadout());
			}
		}
	}
}

void ABFCharacter::OnRep_PlayerState()
{
	Super::OnRep_PlayerState();
	// Team colours / nameplates are rebuilt by the HUD when the PlayerState lands.
}

void ABFCharacter::ApplySoldierClass(UBFSoldierClassDataAsset* ClassAsset)
{
	if (!HasAuthority() || !ClassAsset)
	{
		return;
	}

	SoldierClass = ClassAsset;

	WalkSpeed = ClassAsset->WalkSpeed;
	SprintSpeed = ClassAsset->SprintSpeed;
	MaxStamina = ClassAsset->MaxStamina;
	Stamina = MaxStamina;

	if (HealthComponent)
	{
		HealthComponent->InitializeMaxHealth(ClassAsset->MaxHealth, true);
	}

	if (BuildComponent)
	{
		BuildComponent->ConfigureFromClass(ClassAsset);
	}

	ApplyMovementSpeed();
}

EBFTeam ABFCharacter::GetTeam() const
{
	if (const ABFPlayerState* PS = GetPlayerState<ABFPlayerState>())
	{
		return PS->GetTeam();
	}
	return EBFTeam::Neutral;
}

FVector ABFCharacter::GetPawnViewLocation() const
{
	return FirstPersonCamera ? FirstPersonCamera->GetComponentLocation() : Super::GetPawnViewLocation();
}

void ABFCharacter::GetAimTransform(FVector& OutLocation, FRotator& OutRotation) const
{
	if (const AController* C = GetController())
	{
		// Controller rotation is the authoritative aim on both ends; camera sway is cosmetic only.
		OutLocation = GetPawnViewLocation();
		OutRotation = C->GetControlRotation();
		return;
	}

	OutLocation = GetPawnViewLocation();
	OutRotation = GetActorRotation();
}

void ABFCharacter::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	UpdateStance(DeltaSeconds);
	UpdateStamina(DeltaSeconds);
	UpdateBracing();

	IndoorsCheckTimer += DeltaSeconds;
	if (IndoorsCheckTimer > 0.4f)
	{
		IndoorsCheckTimer = 0.f;
		UpdateIndoors();
	}

	if (IsLocallyControlled())
	{
		UpdateRecoil(DeltaSeconds);
		UpdateCameraFeel(DeltaSeconds);
	}
}

// ------------------------------------------------------------------ Stance

float ABFCharacter::GetStanceHalfHeight(EBFStance InStance) const
{
	switch (InStance)
	{
	case EBFStance::Crouched: return CrouchHalfHeight;
	case EBFStance::Prone:    return ProneHalfHeight;
	default:                  return StandingHalfHeight;
	}
}

bool ABFCharacter::CanEnterStance(EBFStance NewStance) const
{
	if (NewStance == Stance)
	{
		return false;
	}

	if (HealthComponent && (HealthComponent->IsDead() || HealthComponent->IsDowned()))
	{
		return false;
	}

	// Standing up needs headroom - critical inside trenches and tunnels.
	const float TargetHalfHeight = GetStanceHalfHeight(NewStance);
	if (TargetHalfHeight > CurrentCapsuleHalfHeight)
	{
		const float Radius = GetCapsuleComponent()->GetScaledCapsuleRadius();
		const FVector Base = GetActorLocation() - FVector(0.f, 0.f, CurrentCapsuleHalfHeight);
		const FVector Centre = Base + FVector(0.f, 0.f, TargetHalfHeight);

		FCollisionQueryParams Params(SCENE_QUERY_STAT(BFStanceHeadroom), false, this);
		if (GetWorld()->OverlapBlockingTestByChannel(Centre, FQuat::Identity, ECC_Pawn,
			FCollisionShape::MakeCapsule(Radius, TargetHalfHeight - 2.f), Params))
		{
			return false;
		}
	}

	return true;
}

void ABFCharacter::UpdateStance(float DeltaSeconds)
{
	const float Target = GetStanceHalfHeight(Stance);
	if (!FMath::IsNearlyEqual(CurrentCapsuleHalfHeight, Target, 0.1f))
	{
		CurrentCapsuleHalfHeight = FMath::FInterpTo(CurrentCapsuleHalfHeight, Target, DeltaSeconds, StanceBlendSpeed);
		GetCapsuleComponent()->SetCapsuleHalfHeight(CurrentCapsuleHalfHeight, true);

		// Keep the eye line glued to the top of the capsule for a natural crouch/prone drop.
		FVector CamLocal = BaseCameraLocalLocation;
		CamLocal.Z = CurrentCapsuleHalfHeight - 18.f;
		FirstPersonCamera->SetRelativeLocation(CamLocal);
	}
}

void ABFCharacter::OnRep_Stance()
{
	ApplyMovementSpeed();
}

void ABFCharacter::Input_CrouchToggle()
{
	const EBFStance Desired = (Stance == EBFStance::Crouched) ? EBFStance::Standing : EBFStance::Crouched;
	if (CanEnterStance(Desired))
	{
		Stance = Desired;
		ApplyMovementSpeed();
		ServerSetStance(Desired);
	}
}

void ABFCharacter::Input_ProneToggle()
{
	const EBFStance Desired = (Stance == EBFStance::Prone) ? EBFStance::Crouched : EBFStance::Prone;
	if (CanEnterStance(Desired))
	{
		Stance = Desired;
		if (Desired == EBFStance::Prone)
		{
			bSprinting = false;
			ServerSetSprinting(false);
		}
		ApplyMovementSpeed();
		ServerSetStance(Desired);
	}
}

void ABFCharacter::ServerSetStance_Implementation(EBFStance NewStance)
{
	if (CanEnterStance(NewStance))
	{
		Stance = NewStance;
		ApplyMovementSpeed();
	}
}

void ABFCharacter::ApplyMovementSpeed()
{
	UCharacterMovementComponent* Move = GetCharacterMovement();
	if (!Move)
	{
		return;
	}

	float Speed = WalkSpeed;
	switch (Stance)
	{
	case EBFStance::Crouched: Speed = CrouchSpeed; break;
	case EBFStance::Prone:    Speed = ProneSpeed; break;
	default:                  Speed = bSprinting ? SprintSpeed : WalkSpeed; break;
	}

	if (bAiming)
	{
		Speed *= AimSpeedScale;
	}

	// Heavier weapons slow you down; the value comes from the weapon data asset.
	if (Inventory)
	{
		if (const ABFWeaponBase* Weapon = Inventory->GetCurrentWeapon())
		{
			Speed *= Weapon->GetWeightSpeedScale();
		}
	}

	Move->MaxWalkSpeed = Speed;
	Move->MaxWalkSpeedCrouched = FMath::Min(Speed, CrouchSpeed);
}

// ------------------------------------------------------------------ Stamina

void ABFCharacter::UpdateStamina(float DeltaSeconds)
{
	const UCharacterMovementComponent* Move = GetCharacterMovement();
	const bool bActuallySprinting = bSprinting && Move && Move->Velocity.Size2D() > WalkSpeed * 0.9f && !Move->IsFalling();

	if (bActuallySprinting)
	{
		Stamina = FMath::Max(0.f, Stamina - SprintStaminaDrain * DeltaSeconds);
		TimeSinceStaminaUse = 0.f;

		if (Stamina <= 0.f && IsLocallyControlled())
		{
			Input_SprintStop();
		}
	}
	else
	{
		TimeSinceStaminaUse += DeltaSeconds;
		if (TimeSinceStaminaUse >= StaminaRegenDelay)
		{
			Stamina = FMath::Min(MaxStamina, Stamina + StaminaRegen * DeltaSeconds);
		}
	}
}

void ABFCharacter::Input_SprintStart()
{
	if (Stance == EBFStance::Prone || Stamina < SprintStaminaThreshold)
	{
		return;
	}

	if (Stance == EBFStance::Crouched)
	{
		if (!CanEnterStance(EBFStance::Standing))
		{
			return;
		}
		Stance = EBFStance::Standing;
		ServerSetStance(EBFStance::Standing);
	}

	bSprinting = true;
	bAiming = false;
	ServerSetSprinting(true);
	ServerSetAiming(false);
	if (Inventory) { Inventory->SetAiming(false); }
	ApplyMovementSpeed();
}

void ABFCharacter::Input_SprintStop()
{
	if (!bSprinting)
	{
		return;
	}
	bSprinting = false;
	ServerSetSprinting(false);
	ApplyMovementSpeed();
}

void ABFCharacter::ServerSetSprinting_Implementation(bool bNewSprinting)
{
	bSprinting = bNewSprinting && Stance != EBFStance::Prone && Stamina > 0.f;
	ApplyMovementSpeed();
}

// ------------------------------------------------------------------ Movement input

void ABFCharacter::Input_Move(const FInputActionValue& Value)
{
	const FVector2D Axis = Value.Get<FVector2D>();
	if (Axis.IsNearlyZero())
	{
		return;
	}

	AddMovementInput(GetActorForwardVector(), Axis.Y);
	AddMovementInput(GetActorRightVector(), Axis.X);

	// Sprinting only holds while pushing forward.
	if (bSprinting && Axis.Y < 0.3f)
	{
		Input_SprintStop();
	}
}

void ABFCharacter::Input_Look(const FInputActionValue& Value)
{
	const FVector2D Axis = Value.Get<FVector2D>();
	AddControllerYawInput(Axis.X * MouseSensitivity);
	AddControllerPitchInput(Axis.Y * MouseSensitivity);
}

void ABFCharacter::Input_JumpStart()
{
	if (Stance != EBFStance::Standing)
	{
		// Pressing jump from cover stands you up first - matches trench movement expectations.
		if (CanEnterStance(EBFStance::Standing))
		{
			Stance = EBFStance::Standing;
			ServerSetStance(EBFStance::Standing);
			ApplyMovementSpeed();
		}
		return;
	}

	if (Stamina < JumpStaminaCost)
	{
		return;
	}

	Stamina -= JumpStaminaCost;
	TimeSinceStaminaUse = 0.f;
	Jump();
}

void ABFCharacter::Input_JumpStop()
{
	StopJumping();
}

void ABFCharacter::Landed(const FHitResult& Hit)
{
	const float FallSpeed = FMath::Abs(GetCharacterMovement()->Velocity.Z);
	Super::Landed(Hit);

	if (Footsteps)
	{
		Footsteps->PlayLanding(FallSpeed);
	}

	// Hard landings hurt. Server only.
	if (HasAuthority() && FallSpeed > 900.f && HealthComponent)
	{
		const float Damage = (FallSpeed - 900.f) * 0.12f;
		HealthComponent->ApplyHealthDelta(-Damage, this, TEXT("legs"));
	}
}

// ------------------------------------------------------------------ Lean

void ABFCharacter::Input_LeanLeft(const FInputActionValue& Value)
{
	TargetLean = -FMath::Clamp(Value.Get<float>(), 0.f, 1.f);
}

void ABFCharacter::Input_LeanRight(const FInputActionValue& Value)
{
	TargetLean = FMath::Clamp(Value.Get<float>(), 0.f, 1.f);
}

void ABFCharacter::ServerSetLean_Implementation(float NewLean)
{
	LeanAmount = FMath::Clamp(NewLean, -1.f, 1.f);
}

// ------------------------------------------------------------------ Aim / fire

void ABFCharacter::Input_AimStart()
{
	if (Stance == EBFStance::Prone && false) { return; }

	bAiming = true;
	if (bSprinting) { Input_SprintStop(); }
	ServerSetAiming(true);
	if (Inventory) { Inventory->SetAiming(true); }
	ApplyMovementSpeed();
}

void ABFCharacter::Input_AimStop()
{
	bAiming = false;
	ServerSetAiming(false);
	if (Inventory) { Inventory->SetAiming(false); }
	ApplyMovementSpeed();
}

void ABFCharacter::ServerSetAiming_Implementation(bool bNewAiming)
{
	bAiming = bNewAiming;
	if (Inventory) { Inventory->SetAiming(bNewAiming); }
	ApplyMovementSpeed();
}

void ABFCharacter::Input_FireStart()      { if (Inventory) { Inventory->StartFire(); } }
void ABFCharacter::Input_FireStop()       { if (Inventory) { Inventory->StopFire(); } }
void ABFCharacter::Input_Reload()         { if (Inventory) { Inventory->Reload(); } }
void ABFCharacter::Input_CycleFireMode()  { if (Inventory) { Inventory->CycleFireMode(); } }
void ABFCharacter::Input_NextWeapon()     { if (Inventory) { Inventory->CycleWeapon(1); } }
void ABFCharacter::Input_PrevWeapon()     { if (Inventory) { Inventory->CycleWeapon(-1); } }
void ABFCharacter::Input_SelectPrimary()  { if (Inventory) { Inventory->SelectSlot(EBFWeaponSlot::Primary); } }
void ABFCharacter::Input_SelectSecondary(){ if (Inventory) { Inventory->SelectSlot(EBFWeaponSlot::Secondary); } }
void ABFCharacter::Input_SelectEquipment(){ if (Inventory) { Inventory->SelectSlot(EBFWeaponSlot::Equipment); } }
void ABFCharacter::Input_Inspect()        { if (Inventory) { Inventory->InspectWeapon(); } }
void ABFCharacter::Input_UseEquipment()   { if (Inventory) { Inventory->UseEquipment(); } }

// ------------------------------------------------------------------ Interaction

AActor* ABFCharacter::TraceInteractable() const
{
	FVector Start;
	FRotator Rot;
	GetAimTransform(Start, Rot);
	const FVector End = Start + Rot.Vector() * InteractRange;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFInteract), false, this);
	FHitResult Hit;
	if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, BF_TRACE_INTERACT, Params))
	{
		AActor* HitActor = Hit.GetActor();
		if (HitActor && HitActor->Implements<UBFInteractable>())
		{
			return HitActor;
		}
	}
	return nullptr;
}

void ABFCharacter::Input_Interact()
{
	if (AActor* Target = TraceInteractable())
	{
		ServerInteract(Target);
	}
	else if (BuildComponent && BuildComponent->IsPreviewActive())
	{
		BuildComponent->ConfirmPlacement();
	}
}

void ABFCharacter::ServerInteract_Implementation(AActor* Target)
{
	if (!Target || !Target->Implements<UBFInteractable>())
	{
		return;
	}

	// Anti-cheat: re-validate distance on the server.
	if (FVector::DistSquared(Target->GetActorLocation(), GetActorLocation()) > FMath::Square(InteractRange + 150.f))
	{
		return;
	}

	if (IBFInteractable::Execute_CanInteract(Target, this))
	{
		IBFInteractable::Execute_Interact(Target, this);
	}
}

// ------------------------------------------------------------------ Camera feel

void ABFCharacter::AddRecoil(float Pitch, float Yaw)
{
	RecoilOffset.X += Pitch;
	RecoilOffset.Y += Yaw;

	if (APlayerController* PC = Cast<APlayerController>(GetController()))
	{
		PC->AddPitchInput(-Pitch);
		PC->AddYawInput(Yaw);
	}

	// Remember how much to pull back down as the weapon settles.
	RecoilRecoveryTarget.X += Pitch * 0.7f;
	RecoilRecoveryTarget.Y += Yaw * 0.5f;
}

void ABFCharacter::UpdateRecoil(float DeltaSeconds)
{
	if (RecoilRecoveryTarget.IsNearlyZero(0.001f))
	{
		return;
	}

	const bool bFiring = Inventory && Inventory->IsFiring();
	if (bFiring)
	{
		return; // only recover between bursts
	}

	APlayerController* PC = Cast<APlayerController>(GetController());
	if (!PC)
	{
		RecoilRecoveryTarget = FVector2D::ZeroVector;
		return;
	}

	const float RecoverySpeed = 6.f;
	const FVector2D Step = RecoilRecoveryTarget * FMath::Clamp(RecoverySpeed * DeltaSeconds, 0.f, 1.f);

	PC->AddPitchInput(Step.X);
	PC->AddYawInput(-Step.Y);
	RecoilRecoveryTarget -= Step;
}

void ABFCharacter::UpdateCameraFeel(float DeltaSeconds)
{
	if (!FirstPersonCamera)
	{
		return;
	}

	// --- Lean: rotate the camera and slide it sideways, blocked by geometry. ---
	float AllowedLean = TargetLean;
	if (!FMath::IsNearlyZero(AllowedLean))
	{
		const FVector Probe = FirstPersonCamera->GetComponentLocation()
			+ GetActorRightVector() * (LeanLateralOffset * 1.6f * FMath::Sign(AllowedLean));
		FCollisionQueryParams Params(SCENE_QUERY_STAT(BFLeanProbe), false, this);
		if (GetWorld()->LineTraceTestByChannel(FirstPersonCamera->GetComponentLocation(), Probe, ECC_Visibility, Params))
		{
			AllowedLean *= 0.35f; // hugging a trench wall - only a small peek
		}
	}

	LeanAmount = FMath::FInterpTo(LeanAmount, AllowedLean, DeltaSeconds, LeanBlendSpeed);
	if (!HasAuthority() && FMath::Abs(LeanAmount - AllowedLean) > 0.02f)
	{
		ServerSetLean(LeanAmount);
	}

	// --- Sway: restrained, driven by actual horizontal speed. ---
	const float Speed2D = GetCharacterMovement() ? GetCharacterMovement()->Velocity.Size2D() : 0.f;
	const float SpeedAlpha = FMath::Clamp(Speed2D / FMath::Max(SprintSpeed, 1.f), 0.f, 1.f);
	const float AimScale = bAiming ? AimSwayScale : 1.f;

	SwayTime += DeltaSeconds * SwayFrequency * FMath::Max(SpeedAlpha, 0.15f);

	// Figure-eight: vertical runs at double frequency. Classic, and it reads as footfalls.
	const FVector2D WalkSway(
		FMath::Sin(SwayTime * 2.f) * SwayAmplitude * SpeedAlpha * AimScale,
		FMath::Sin(SwayTime) * SwayAmplitude * 1.4f * SpeedAlpha * AimScale);

	// Idle breathing keeps the frame alive when standing still in a quiet trench.
	const float BreathPhase = GetWorld()->GetTimeSeconds() * 1.1f;
	const float StaminaPenalty = 1.f + (1.f - GetStaminaPercent()) * 2.0f;
	const FVector2D Breath(
		FMath::Sin(BreathPhase) * BreathAmplitude * StaminaPenalty * AimScale,
		FMath::Cos(BreathPhase * 0.7f) * BreathAmplitude * 0.6f * StaminaPenalty * AimScale);

	CurrentSwayOffset = FMath::Vector2DInterpTo(CurrentSwayOffset, WalkSway + Breath, DeltaSeconds, 9.f);

	FRotator CamRot(CurrentSwayOffset.X, 0.f, -LeanAmount * MaxLeanAngle + CurrentSwayOffset.Y * 0.3f);
	FirstPersonCamera->SetRelativeRotation(CamRot);

	FVector CamLoc = FirstPersonCamera->GetRelativeLocation();
	CamLoc.Y = LeanAmount * LeanLateralOffset;
	CamLoc.Z = CurrentCapsuleHalfHeight - 18.f - FMath::Abs(LeanAmount) * 6.f;
	FirstPersonCamera->SetRelativeLocation(CamLoc);

	// --- FOV: ADS pulls in, sprint pushes out very slightly. ---
	float TargetFOV = BaseFOV;
	if (bAiming && Inventory)
	{
		TargetFOV = Inventory->GetCurrentAimFOV(BaseFOV);
	}
	else if (bSprinting)
	{
		TargetFOV = BaseFOV + 4.f;
	}

	const float FOVSpeed = bAiming ? (1.f / FMath::Max(Inventory ? Inventory->GetCurrentADSTime() : 0.25f, 0.01f)) : 8.f;
	FirstPersonCamera->FieldOfView = FMath::FInterpTo(FirstPersonCamera->FieldOfView, TargetFOV, DeltaSeconds, FOVSpeed);
}

// ------------------------------------------------------------------ Bracing / indoors

void ABFCharacter::UpdateBracing()
{
	// Resting on a parapet: something solid at chest height right in front, while crouched or prone.
	const bool bStanceAllows = (Stance != EBFStance::Standing) || bAiming;
	if (!bStanceAllows)
	{
		if (bBraced && HasAuthority()) { bBraced = false; }
		return;
	}

	const FVector Start = GetActorLocation() + FVector(0.f, 0.f, CurrentCapsuleHalfHeight * 0.45f);
	const FVector End = Start + GetActorForwardVector() * 110.f;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFBrace), false, this);
	const bool bNewBraced = GetWorld()->LineTraceTestByChannel(Start, End, BF_TRACE_COVER, Params);

	if (bNewBraced != bBraced)
	{
		bBraced = bNewBraced;
		if (Inventory)
		{
			Inventory->SetBraced(bBraced);
		}
	}
}

void ABFCharacter::UpdateIndoors()
{
	// Cheap sky check: if we cannot see straight up, treat as bunker/tunnel for audio.
	const FVector Start = GetPawnViewLocation();
	const FVector End = Start + FVector(0.f, 0.f, 4000.f);
	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFIndoors), false, this);
	bIndoors = GetWorld()->LineTraceTestByChannel(Start, End, ECC_Visibility, Params);
}

// ------------------------------------------------------------------ Death

void ABFCharacter::OnHealthDowned(bool bIsDowned)
{
	if (bIsDowned)
	{
		if (HasAuthority())
		{
			Stance = EBFStance::Prone;
			bSprinting = false;
			bAiming = false;
			ApplyMovementSpeed();
			GetCharacterMovement()->DisableMovement();
		}

		if (Inventory)
		{
			Inventory->StopFire();
		}
	}
	else if (HasAuthority())
	{
		GetCharacterMovement()->SetMovementMode(MOVE_Walking);
		Stance = EBFStance::Crouched;
		ApplyMovementSpeed();
	}
}

void ABFCharacter::OnHealthDeath(AActor* Killer, const FName& HitZone)
{
	HandleDeath(Killer, HitZone);
}

void ABFCharacter::HandleDeath(AActor* Killer, FName HitZone)
{
	if (Inventory)
	{
		Inventory->StopFire();
	}

	// Ragdoll the visible body on every machine.
	GetMesh()->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	GetMesh()->SetCollisionProfileName(TEXT("Ragdoll"));
	GetMesh()->SetSimulatePhysics(true);
	GetCapsuleComponent()->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	GetCharacterMovement()->DisableMovement();

	if (ArmsMesh)
	{
		ArmsMesh->SetVisibility(false, true);
	}

	if (HasAuthority())
	{
		if (Inventory)
		{
			Inventory->ServerDropOrDestroyWeapons();
		}
		DetachFromControllerPendingDestroy();
		SetLifeSpan(12.f);
	}
}

// ------------------------------------------------------------------ Input binding

void ABFCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
	Super::SetupPlayerInputComponent(PlayerInputComponent);

	UEnhancedInputComponent* EIC = Cast<UEnhancedInputComponent>(PlayerInputComponent);
	if (!EIC)
	{
		BF_LOG(LogBrokenFront, Error, TEXT("Enhanced Input is required. Check DefaultInput.ini."));
		return;
	}

	if (IA_Move)       { EIC->BindAction(IA_Move, ETriggerEvent::Triggered, this, &ABFCharacter::Input_Move); }
	if (IA_Look)       { EIC->BindAction(IA_Look, ETriggerEvent::Triggered, this, &ABFCharacter::Input_Look); }
	if (IA_Jump)       { EIC->BindAction(IA_Jump, ETriggerEvent::Started, this, &ABFCharacter::Input_JumpStart);
	                     EIC->BindAction(IA_Jump, ETriggerEvent::Completed, this, &ABFCharacter::Input_JumpStop); }
	if (IA_Sprint)     { EIC->BindAction(IA_Sprint, ETriggerEvent::Started, this, &ABFCharacter::Input_SprintStart);
	                     EIC->BindAction(IA_Sprint, ETriggerEvent::Completed, this, &ABFCharacter::Input_SprintStop); }
	if (IA_Crouch)     { EIC->BindAction(IA_Crouch, ETriggerEvent::Started, this, &ABFCharacter::Input_CrouchToggle); }
	if (IA_Prone)      { EIC->BindAction(IA_Prone, ETriggerEvent::Started, this, &ABFCharacter::Input_ProneToggle); }
	if (IA_LeanLeft)   { EIC->BindAction(IA_LeanLeft, ETriggerEvent::Triggered, this, &ABFCharacter::Input_LeanLeft);
	                     EIC->BindAction(IA_LeanLeft, ETriggerEvent::Completed, this, &ABFCharacter::Input_LeanLeft); }
	if (IA_LeanRight)  { EIC->BindAction(IA_LeanRight, ETriggerEvent::Triggered, this, &ABFCharacter::Input_LeanRight);
	                     EIC->BindAction(IA_LeanRight, ETriggerEvent::Completed, this, &ABFCharacter::Input_LeanRight); }
	if (IA_Fire)       { EIC->BindAction(IA_Fire, ETriggerEvent::Started, this, &ABFCharacter::Input_FireStart);
	                     EIC->BindAction(IA_Fire, ETriggerEvent::Completed, this, &ABFCharacter::Input_FireStop); }
	if (IA_Aim)        { EIC->BindAction(IA_Aim, ETriggerEvent::Started, this, &ABFCharacter::Input_AimStart);
	                     EIC->BindAction(IA_Aim, ETriggerEvent::Completed, this, &ABFCharacter::Input_AimStop); }
	if (IA_Reload)     { EIC->BindAction(IA_Reload, ETriggerEvent::Started, this, &ABFCharacter::Input_Reload); }
	if (IA_FireMode)   { EIC->BindAction(IA_FireMode, ETriggerEvent::Started, this, &ABFCharacter::Input_CycleFireMode); }
	if (IA_NextWeapon) { EIC->BindAction(IA_NextWeapon, ETriggerEvent::Started, this, &ABFCharacter::Input_NextWeapon); }
	if (IA_PrevWeapon) { EIC->BindAction(IA_PrevWeapon, ETriggerEvent::Started, this, &ABFCharacter::Input_PrevWeapon); }
	if (IA_Primary)    { EIC->BindAction(IA_Primary, ETriggerEvent::Started, this, &ABFCharacter::Input_SelectPrimary); }
	if (IA_Secondary)  { EIC->BindAction(IA_Secondary, ETriggerEvent::Started, this, &ABFCharacter::Input_SelectSecondary); }
	if (IA_Equipment)  { EIC->BindAction(IA_Equipment, ETriggerEvent::Started, this, &ABFCharacter::Input_SelectEquipment); }
	if (IA_Inspect)    { EIC->BindAction(IA_Inspect, ETriggerEvent::Started, this, &ABFCharacter::Input_Inspect); }
	if (IA_Interact)   { EIC->BindAction(IA_Interact, ETriggerEvent::Started, this, &ABFCharacter::Input_Interact); }
	if (IA_UseEquipment){ EIC->BindAction(IA_UseEquipment, ETriggerEvent::Started, this, &ABFCharacter::Input_UseEquipment); }
}
