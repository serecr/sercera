#include "Characters/BFMudComponent.h"
#include "Characters/BFCharacter.h"
#include "Systems/BFWeatherManager.h"
#include "Components/MeshComponent.h"
#include "Engine/World.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Kismet/GameplayStatics.h"
#include "PhysicalMaterials/PhysicalMaterial.h"

UBFMudComponent::UBFMudComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 0.25f; // cosmetic, cheap
	SetIsReplicatedByDefault(false);
}

void UBFMudComponent::BeginPlay()
{
	Super::BeginPlay();

	// Dedicated servers never render, so skip the work entirely.
	if (GetNetMode() == NM_DedicatedServer)
	{
		SetComponentTickEnabled(false);
	}
}

void UBFMudComponent::RegisterMesh(UMeshComponent* Mesh)
{
	if (Mesh)
	{
		TrackedMeshes.AddUnique(Mesh);
		LastAppliedMud = -1.f;
	}
}

void UBFMudComponent::UnregisterMesh(UMeshComponent* Mesh)
{
	TrackedMeshes.Remove(Mesh);
}

void UBFMudComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	const ACharacter* Char = Cast<ACharacter>(GetOwner());
	if (!Char)
	{
		return;
	}

	const EBFSurfaceType Surface = QuerySurfaceUnderFeet();

	float RainIntensity = 0.f;
	float WeatherMudRate = 0.f;
	if (const ABFWeatherManager* Weather = ABFWeatherManager::Get(GetWorld()))
	{
		RainIntensity = Weather->GetSnapshot().RainIntensity;
		WeatherMudRate = Weather->GetCurrentMudRate();
	}

	float StanceScale = 1.f;
	if (const ABFCharacter* BFChar = Cast<ABFCharacter>(Char))
	{
		switch (BFChar->GetStance())
		{
		case EBFStance::Prone:    StanceScale = ProneMultiplier; break;
		case EBFStance::Crouched: StanceScale = CrouchMultiplier; break;
		default: break;
		}
	}

	const bool bOnGround = Char->GetCharacterMovement() && !Char->GetCharacterMovement()->IsFalling();

	float Delta = 0.f;
	if (bOnGround)
	{
		switch (Surface)
		{
		case EBFSurfaceType::Mud:
			Delta += (MudGainPerSecond + WeatherMudRate) * StanceScale;
			break;
		case EBFSurfaceType::Water:
			Delta -= WaterWashPerSecond;
			break;
		case EBFSurfaceType::Grass:
			Delta += WeatherMudRate * 0.4f * StanceScale;
			break;
		default:
			Delta -= DryCleanPerSecond;
			break;
		}
	}

	// Rain slowly rinses the top layer once you are out of the mud.
	if (RainIntensity > 0.05f && Surface != EBFSurfaceType::Mud)
	{
		Delta -= RainWashPerSecond * RainIntensity;
	}

	MudLevel = FMath::Clamp(MudLevel + Delta * DeltaTime, 0.f, 1.f);

	// Wetness follows rain and water quickly, dries slowly.
	const float TargetWet = FMath::Max(RainIntensity, Surface == EBFSurfaceType::Water ? 1.f : 0.f);
	const float WetSpeed = TargetWet > WetLevel ? 0.5f : 0.06f;
	WetLevel = FMath::FInterpConstantTo(WetLevel, TargetWet, DeltaTime, WetSpeed);

	ApplyToMaterials();
}

EBFSurfaceType UBFMudComponent::QuerySurfaceUnderFeet() const
{
	const AActor* Owner = GetOwner();
	const UWorld* World = GetWorld();
	if (!Owner || !World)
	{
		return EBFSurfaceType::Default;
	}

	const FVector Start = Owner->GetActorLocation();
	const FVector End = Start - FVector(0.f, 0.f, 200.f);

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFMudSurface), false, Owner);
	Params.bReturnPhysicalMaterial = true;

	FHitResult Hit;
	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params) && Hit.PhysMaterial.IsValid())
	{
		// SurfaceType1..6 map to the BF surface list in DefaultEngine.ini, in order.
		const EPhysicalSurface Surface = Hit.PhysMaterial->SurfaceType;
		const int32 Index = static_cast<int32>(Surface);
		if (Index >= 1 && Index <= 6)
		{
			return static_cast<EBFSurfaceType>(Index);
		}
	}

	return EBFSurfaceType::Default;
}

void UBFMudComponent::ApplyToMaterials()
{
	if (FMath::IsNearlyEqual(LastAppliedMud, MudLevel, 0.005f))
	{
		return;
	}
	LastAppliedMud = MudLevel;

	for (const TObjectPtr<UMeshComponent>& Mesh : TrackedMeshes)
	{
		if (!Mesh)
		{
			continue;
		}

		const int32 NumMaterials = Mesh->GetNumMaterials();
		for (int32 Index = 0; Index < NumMaterials; ++Index)
		{
			if (UMaterialInstanceDynamic* MID = Mesh->CreateAndSetMaterialInstanceDynamic(Index))
			{
				MID->SetScalarParameterValue(MudParameterName, MudLevel);
				MID->SetScalarParameterValue(WetParameterName, WetLevel);
			}
		}
	}
}
