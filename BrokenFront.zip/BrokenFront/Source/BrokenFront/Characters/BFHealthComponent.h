#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "BFHealthComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FBFHealthChanged, float, NewHealth, float, Delta, AActor*, Instigator);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFDownedStateChanged, bool, bIsDowned);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBFDeath, AActor*, Killer, const FName&, HitZone);

/**
 * Server-authoritative health with a downed ("bleeding out") window so Medics matter.
 * Nothing here is class specific; the class data asset supplies MaxHealth.
 */
UCLASS(ClassGroup = (BrokenFront), meta = (BlueprintSpawnableComponent))
class BROKENFRONT_API UBFHealthComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBFHealthComponent();

	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Health") FBFHealthChanged OnHealthChanged;
	UPROPERTY(BlueprintAssignable, Category = "Health") FBFDownedStateChanged OnDownedStateChanged;
	UPROPERTY(BlueprintAssignable, Category = "Health") FBFDeath OnDeath;

	UFUNCTION(BlueprintPure, Category = "Health") float GetHealth() const { return Health; }
	UFUNCTION(BlueprintPure, Category = "Health") float GetMaxHealth() const { return MaxHealth; }
	UFUNCTION(BlueprintPure, Category = "Health") float GetHealthPercent() const { return MaxHealth > 0.f ? Health / MaxHealth : 0.f; }
	UFUNCTION(BlueprintPure, Category = "Health") bool IsDowned() const { return bDowned; }
	UFUNCTION(BlueprintPure, Category = "Health") bool IsDead() const { return bDead; }
	UFUNCTION(BlueprintPure, Category = "Health") bool IsAlive() const { return !bDead; }
	UFUNCTION(BlueprintPure, Category = "Health") float GetBleedOutRemaining() const { return BleedOutRemaining; }

	/** Server only. Overrides MaxHealth (called when a class is applied) and optionally refills. */
	void InitializeMaxHealth(float NewMaxHealth, bool bRefill = true);

	/** Server only. Negative delta damages, positive heals. Routes through the downed logic. */
	void ApplyHealthDelta(float Delta, AActor* EventInstigator, FName HitZone = NAME_None);

	/** Server only. Brings a downed pawn back with a fraction of max health. */
	UFUNCTION(BlueprintCallable, Category = "Health")
	bool Revive(AActor* Reviver, float HealthFraction = 0.35f);

	/** Server only. Finishes off a downed pawn (bleed out, execution, or give-up). */
	UFUNCTION(BlueprintCallable, Category = "Health")
	void Kill(AActor* Killer, FName HitZone = NAME_None);

	/** Server only. Resets state for a fresh respawn. */
	void ResetForRespawn();

protected:
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	UFUNCTION() void HandlePointDamage(AActor* DamagedActor, float Damage, class AController* InstigatedBy,
		FVector HitLocation, class UPrimitiveComponent* HitComponent, FName BoneName,
		FVector ShotDirection, const class UDamageType* DamageType, AActor* DamageCauser);

	UFUNCTION() void HandleRadialDamage(AActor* DamagedActor, float Damage, const class UDamageType* DamageType,
		FVector Origin, const FHitResult& HitInfo, class AController* InstigatedBy, AActor* DamageCauser);

	UFUNCTION() void OnRep_Health(float OldHealth);
	UFUNCTION() void OnRep_Downed();

	UPROPERTY(ReplicatedUsing = OnRep_Health, BlueprintReadOnly, Category = "Health")
	float Health = 100.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Health")
	float MaxHealth = 100.f;

	UPROPERTY(ReplicatedUsing = OnRep_Downed, BlueprintReadOnly, Category = "Health")
	bool bDowned = false;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Health")
	bool bDead = false;

	/** Replicated so the HUD can draw an honest bleed-out ring on the owning client. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "Health")
	float BleedOutRemaining = 0.f;

	/** Seconds a downed soldier survives waiting for a Medic. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config", meta = (ClampMin = "1.0"))
	float BleedOutDuration = 35.f;

	/** Damage beyond this in a single hit skips the downed state entirely. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float LethalOverkillThreshold = 85.f;

	/** Regeneration only applies above this fraction; below it a Medic is required. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config", meta = (ClampMin = "0.0", ClampMax = "1.0"))
	float RegenFloorFraction = 0.4f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float RegenPerSecond = 4.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float RegenDelayAfterDamage = 6.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	bool bEnableDownedState = true;

private:
	float TimeSinceLastDamage = 0.f;
	TWeakObjectPtr<AActor> LastDamageInstigator;
	FName LastHitZone = NAME_None;

	void EnterDownedState(AActor* EventInstigator, FName HitZone);
};
