#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Core/BFTypes.h"
#include "BFMudComponent.generated.h"

class UMeshComponent;

/**
 * Accumulates dirt on the soldier's uniform, hands and weapon.
 * Purely cosmetic and client-side driven: the value is computed locally from
 * replicated inputs (weather, surface, crouch/prone) so it costs zero bandwidth.
 */
UCLASS(ClassGroup = (BrokenFront), meta = (BlueprintSpawnableComponent))
class BROKENFRONT_API UBFMudComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBFMudComponent();

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/** 0 = clean, 1 = caked. */
	UFUNCTION(BlueprintPure, Category = "Mud") float GetMudLevel() const { return MudLevel; }

	/** Register a mesh whose material should receive the "MudAmount" scalar parameter. */
	UFUNCTION(BlueprintCallable, Category = "Mud")
	void RegisterMesh(UMeshComponent* Mesh);

	UFUNCTION(BlueprintCallable, Category = "Mud")
	void UnregisterMesh(UMeshComponent* Mesh);

	/** Instantly add dirt, e.g. a nearby shell burst throwing up soil. */
	UFUNCTION(BlueprintCallable, Category = "Mud")
	void AddMudBurst(float Amount) { MudLevel = FMath::Clamp(MudLevel + Amount, 0.f, 1.f); }

	/** Wipe clean, used on respawn. */
	UFUNCTION(BlueprintCallable, Category = "Mud")
	void ResetMud() { MudLevel = 0.f; ApplyToMaterials(); }

protected:
	/** Dirt gained per second while standing on mud. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float MudGainPerSecond = 0.045f;
	/** Extra gain while prone - you are lying in it. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float ProneMultiplier = 3.0f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float CrouchMultiplier = 1.4f;
	/** Rain both muddies the ground and rinses the uniform; net effect is authored per weather. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float RainWashPerSecond = 0.02f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float DryCleanPerSecond = 0.012f;
	/** Water (puddles, flooded trench floor) rinses fast. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float WaterWashPerSecond = 0.12f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") FName MudParameterName = TEXT("MudAmount");
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") FName WetParameterName = TEXT("WetAmount");

private:
	UPROPERTY() TArray<TObjectPtr<UMeshComponent>> TrackedMeshes;

	float MudLevel = 0.f;
	float WetLevel = 0.f;
	float LastAppliedMud = -1.f;

	void ApplyToMaterials();
	EBFSurfaceType QuerySurfaceUnderFeet() const;
};
