// Copyright (c) Broken Front. Fictional setting, no real-world factions.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "Core/BFTypes.h"
#include "BFGameSettings.generated.h"

class USoundMix;
class USoundClass;
class UInputMappingContext;

/** One rebindable action. Keys are stored by name so the config file stays readable. */
USTRUCT(BlueprintType)
struct FBFKeyBinding
{
	GENERATED_BODY()

	/** Matches the Enhanced Input action name, e.g. "IA_Fire". */
	UPROPERTY(BlueprintReadWrite) FName ActionName;

	UPROPERTY(BlueprintReadWrite) FKey PrimaryKey;

	UPROPERTY(BlueprintReadWrite) FKey SecondaryKey;
};

/**
 * All player facing options, split exactly as the options menu presents them.
 *
 * Stored in Saved/Config/<Platform>/BrokenFrontSettings.ini via the standard config
 * system, so options survive a reinstall of the game content but stay per machine.
 * Graphics values are pushed into UGameUserSettings and a small set of console
 * variables; nothing here is gameplay affecting, which keeps competitive parity.
 */
UCLASS(Config = BrokenFrontSettings, DefaultConfig, BlueprintType)
class BROKENFRONT_API UBFGameSettings : public UObject
{
	GENERATED_BODY()

public:
	UBFGameSettings();

	// ------------------------------------------------------------- Graphics

	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") FIntPoint Resolution = FIntPoint(1920, 1080);

	/** 0 = Fullscreen, 1 = Windowed Fullscreen, 2 = Windowed. Matches EWindowMode. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 WindowMode = 1;

	/** 0 = unlimited. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 FrameRateLimit = 144;

	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") EBFQualityPreset QualityPreset = EBFQualityPreset::High;

	/** Individual sliders, 0..3. Only respected when QualityPreset is Custom. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 ShadowQuality = 2;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 EffectsQuality = 2;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 ViewDistanceQuality = 2;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 TextureQuality = 2;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 PostProcessQuality = 2;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 FoliageQuality = 2;

	/** 0 = off, 1 = FXAA, 2 = TSR (default), 3 = TSR high. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 AntiAliasingMode = 2;

	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") bool bVSync = false;

	/** Screen percentage, 50..100. Lets weaker machines keep the trench detail. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Graphics") int32 ResolutionScale = 100;

	// ---------------------------------------------------------------- Audio

	UPROPERTY(Config, BlueprintReadWrite, Category = "Audio") float MasterVolume = 1.f;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Audio") float MusicVolume = 0.6f;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Audio") float EffectsVolume = 1.f;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Audio") float VoiceVolume = 1.f;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Audio") float RadioVolume = 0.85f;

	// ------------------------------------------------------------- Controls

	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") float MouseSensitivity = 1.f;

	/** Separate multiplier while aiming down sights, the usual shooter request. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") float ADSSensitivityScale = 0.65f;

	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") bool bInvertY = false;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") bool bToggleCrouch = true;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") bool bToggleSprint = false;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") bool bToggleADS = false;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") bool bHoldToLean = true;

	UPROPERTY(Config, BlueprintReadWrite, Category = "Controls") TArray<FBFKeyBinding> KeyBindings;

	// ------------------------------------------------------------- Gameplay

	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") bool bShowHUD = true;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") bool bShowCrosshair = true;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") bool bShowMinimap = true;

	/** 0..1 scale on all camera shake and view sway. Accessibility, not an advantage. */
	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") float CameraShakeScale = 1.f;

	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") bool bSubtitles = false;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") bool bRadioSubtitles = true;
	UPROPERTY(Config, BlueprintReadWrite, Category = "Gameplay") float FieldOfView = 90.f;

	// ---------------------------------------------------------------- API

	/** Applies graphics, audio and gameplay values. Safe to call at any time. */
	UFUNCTION(BlueprintCallable, Category = "Settings") void ApplyAll(UObject* WorldContext);

	UFUNCTION(BlueprintCallable, Category = "Settings") void ApplyGraphics();
	UFUNCTION(BlueprintCallable, Category = "Settings") void ApplyAudio(UObject* WorldContext);
	UFUNCTION(BlueprintCallable, Category = "Settings") void ApplyGameplay(UObject* WorldContext);

	/** Sets every individual slider from the chosen preset and applies it. */
	UFUNCTION(BlueprintCallable, Category = "Settings") void SetQualityPreset(EBFQualityPreset NewPreset);

	/** Fills the individual sliders from a preset without touching the live renderer. */
	UFUNCTION(BlueprintCallable, Category = "Settings") void ApplyPresetToFields(EBFQualityPreset Preset);

	UFUNCTION(BlueprintCallable, Category = "Settings") void ResetToDefaults();

	UFUNCTION(BlueprintCallable, Category = "Settings") void SaveToDisk();
	UFUNCTION(BlueprintCallable, Category = "Settings") void LoadFromDisk();

	UFUNCTION(BlueprintPure, Category = "Settings") TArray<FIntPoint> GetSupportedResolutions() const;

	/** Rebinds one action at runtime and stores it. */
	UFUNCTION(BlueprintCallable, Category = "Settings") void SetKeyBinding(FName ActionName, const FKey& NewKey, bool bSecondary);

	UFUNCTION(BlueprintPure, Category = "Settings") FKey GetKeyBinding(FName ActionName, bool bSecondary) const;

	/** Sound classes are optional: if unset the volume values are simply ignored. */
	UPROPERTY(EditDefaultsOnly, Category = "Audio") TSoftObjectPtr<USoundMix> SettingsSoundMix;
	UPROPERTY(EditDefaultsOnly, Category = "Audio") TSoftObjectPtr<USoundClass> MasterSoundClass;
	UPROPERTY(EditDefaultsOnly, Category = "Audio") TSoftObjectPtr<USoundClass> MusicSoundClass;
	UPROPERTY(EditDefaultsOnly, Category = "Audio") TSoftObjectPtr<USoundClass> EffectsSoundClass;
	UPROPERTY(EditDefaultsOnly, Category = "Audio") TSoftObjectPtr<USoundClass> VoiceSoundClass;
	UPROPERTY(EditDefaultsOnly, Category = "Audio") TSoftObjectPtr<USoundClass> RadioSoundClass;

private:
	void ApplyPresetValues(EBFQualityPreset Preset);
	void ApplyConsoleVariables();
	void ApplyOneSoundClass(UObject* WorldContext, const TSoftObjectPtr<USoundClass>& Class, float Volume);
};
