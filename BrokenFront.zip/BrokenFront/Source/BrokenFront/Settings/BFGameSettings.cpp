#include "Settings/BFGameSettings.h"

#include "Core/BFLog.h"
#include "GameFramework/GameUserSettings.h"
#include "Scalability.h"
#include "RHI.h"
#include "Engine/Engine.h"
#include "Kismet/GameplayStatics.h"
#include "Sound/SoundMix.h"
#include "Sound/SoundClass.h"
#include "HAL/IConsoleManager.h"

UBFGameSettings::UBFGameSettings()
{
	// Default binds. These are the ones the options menu exposes for rebinding; the
	// Enhanced Input mapping context in Content ships with the same defaults so the
	// game is fully playable before the player ever opens the menu.
	auto Add = [this](const TCHAR* Action, FKey Primary)
	{
		FBFKeyBinding Binding;
		Binding.ActionName = FName(Action);
		Binding.PrimaryKey = Primary;
		KeyBindings.Add(Binding);
	};

	Add(TEXT("IA_Fire"), EKeys::LeftMouseButton);
	Add(TEXT("IA_Aim"), EKeys::RightMouseButton);
	Add(TEXT("IA_Reload"), EKeys::R);
	Add(TEXT("IA_Jump"), EKeys::SpaceBar);
	Add(TEXT("IA_Crouch"), EKeys::LeftControl);
	Add(TEXT("IA_Prone"), EKeys::Z);
	Add(TEXT("IA_Sprint"), EKeys::LeftShift);
	Add(TEXT("IA_LeanLeft"), EKeys::Q);
	Add(TEXT("IA_LeanRight"), EKeys::E);
	Add(TEXT("IA_Interact"), EKeys::F);
	Add(TEXT("IA_Inspect"), EKeys::T);
	Add(TEXT("IA_NextWeapon"), EKeys::MouseScrollUp);
	Add(TEXT("IA_Slot1"), EKeys::One);
	Add(TEXT("IA_Slot2"), EKeys::Two);
	Add(TEXT("IA_Slot3"), EKeys::Three);
	Add(TEXT("IA_UseEquipment"), EKeys::G);
	Add(TEXT("IA_FireMode"), EKeys::B);
	Add(TEXT("IA_Radio"), EKeys::V);
	Add(TEXT("IA_Map"), EKeys::M);
	Add(TEXT("IA_Scoreboard"), EKeys::Tab);
	Add(TEXT("IA_Build"), EKeys::Four);
}

// -------------------------------------------------------------------- Apply

void UBFGameSettings::ApplyAll(UObject* WorldContext)
{
	ApplyGraphics();
	ApplyAudio(WorldContext);
	ApplyGameplay(WorldContext);
}

void UBFGameSettings::ApplyGraphics()
{
	UGameUserSettings* User = GEngine ? GEngine->GetGameUserSettings() : nullptr;
	if (!User)
	{
		return;
	}

	User->SetScreenResolution(Resolution);
	User->SetFullscreenMode(static_cast<EWindowMode::Type>(FMath::Clamp(WindowMode, 0, 2)));
	User->SetFrameRateLimit(FrameRateLimit <= 0 ? 0.f : static_cast<float>(FrameRateLimit));
	User->SetVSyncEnabled(bVSync);

	if (QualityPreset != EBFQualityPreset::Custom)
	{
		ApplyPresetValues(QualityPreset);
	}

	Scalability::FQualityLevels Levels = Scalability::GetQualityLevels();
	Levels.SetViewDistanceQuality(FMath::Clamp(ViewDistanceQuality, 0, 3));
	Levels.SetShadowQuality(FMath::Clamp(ShadowQuality, 0, 3));
	Levels.SetGlobalIlluminationQuality(FMath::Clamp(PostProcessQuality, 0, 3));
	Levels.SetReflectionQuality(FMath::Clamp(PostProcessQuality, 0, 3));
	Levels.SetPostProcessQuality(FMath::Clamp(PostProcessQuality, 0, 3));
	Levels.SetTextureQuality(FMath::Clamp(TextureQuality, 0, 3));
	Levels.SetEffectsQuality(FMath::Clamp(EffectsQuality, 0, 3));
	Levels.SetFoliageQuality(FMath::Clamp(FoliageQuality, 0, 3));
	Levels.SetShadingQuality(FMath::Clamp(PostProcessQuality, 0, 3));
	Levels.ResolutionQuality = FMath::Clamp(static_cast<float>(ResolutionScale), 50.f, 100.f);
	Scalability::SetQualityLevels(Levels);

	ApplyConsoleVariables();

	User->ApplySettings(false);
	User->SaveSettings();

	BF_LOG(LogBFGame, Log, TEXT("Graphics applied: preset %d, %dx%d, cap %d"),
		static_cast<int32>(QualityPreset), Resolution.X, Resolution.Y, FrameRateLimit);
}

void UBFGameSettings::ApplyPresetValues(EBFQualityPreset Preset)
{
	// LOW targets a stable framerate on old hardware: the trench silhouettes and the
	// frontline readability must survive, everything decorative can go.
	switch (Preset)
	{
	case EBFQualityPreset::Low:
		ShadowQuality = 0; EffectsQuality = 0; ViewDistanceQuality = 1;
		TextureQuality = 0; PostProcessQuality = 0; FoliageQuality = 0;
		AntiAliasingMode = 1; ResolutionScale = 80;
		break;

	case EBFQualityPreset::Medium:
		ShadowQuality = 1; EffectsQuality = 1; ViewDistanceQuality = 2;
		TextureQuality = 1; PostProcessQuality = 1; FoliageQuality = 1;
		AntiAliasingMode = 2; ResolutionScale = 90;
		break;

	case EBFQualityPreset::High:
		ShadowQuality = 2; EffectsQuality = 2; ViewDistanceQuality = 2;
		TextureQuality = 2; PostProcessQuality = 2; FoliageQuality = 2;
		AntiAliasingMode = 2; ResolutionScale = 100;
		break;

	case EBFQualityPreset::Epic:
		ShadowQuality = 3; EffectsQuality = 3; ViewDistanceQuality = 3;
		TextureQuality = 3; PostProcessQuality = 3; FoliageQuality = 3;
		AntiAliasingMode = 3; ResolutionScale = 100;
		break;

	default:
		break;
	}
}

void UBFGameSettings::ApplyConsoleVariables()
{
	auto SetCVar = [](const TCHAR* Name, int32 Value)
	{
		if (IConsoleVariable* Var = IConsoleManager::Get().FindConsoleVariable(Name))
		{
			Var->Set(Value, ECVF_SetByGameSetting);
		}
	};
	auto SetCVarFloat = [](const TCHAR* Name, float Value)
	{
		if (IConsoleVariable* Var = IConsoleManager::Get().FindConsoleVariable(Name))
		{
			Var->Set(Value, ECVF_SetByGameSetting);
		}
	};

	// Anti aliasing: 0 none, 1 FXAA, 2 TSR, 4 TSR with a higher history.
	const int32 AAMethod = (AntiAliasingMode <= 0) ? 0 : (AntiAliasingMode == 1 ? 1 : 4);
	SetCVar(TEXT("r.AntiAliasingMethod"), AAMethod);
	if (AntiAliasingMode >= 3)
	{
		SetCVarFloat(TEXT("r.TSR.History.ScreenPercentage"), 200.f);
	}

	// Lumen and Virtual Shadow Maps are the two big spends. Below High we fall back to
	// screen space GI and conventional shadow maps, which is a large win on low end GPUs
	// and costs us only indirect bounce quality inside bunkers and tunnels.
	const bool bHeavyLighting = (ShadowQuality >= 2);
	SetCVar(TEXT("r.Lumen.DiffuseIndirect.Allow"), bHeavyLighting ? 1 : 0);
	SetCVar(TEXT("r.Lumen.Reflections.Allow"), (PostProcessQuality >= 2) ? 1 : 0);
	SetCVar(TEXT("r.Shadow.Virtual.Enable"), bHeavyLighting ? 1 : 0);

	// Niagara scalability: effect systems read this to drop particle counts and to
	// cull distant smoke and rain entirely.
	SetCVar(TEXT("fx.Niagara.QualityLevel"), FMath::Clamp(EffectsQuality, 0, 3));
	SetCVarFloat(TEXT("r.Streaming.PoolSize"),
		TextureQuality >= 3 ? 3000.f : (TextureQuality == 2 ? 2000.f : (TextureQuality == 1 ? 1200.f : 700.f)));

	// View distance on a World Partition map is mostly a streaming decision.
	SetCVarFloat(TEXT("r.ViewDistanceScale"),
		ViewDistanceQuality >= 3 ? 1.4f : (ViewDistanceQuality == 2 ? 1.f : (ViewDistanceQuality == 1 ? 0.75f : 0.55f)));

	SetCVarFloat(TEXT("foliage.LODDistanceScale"),
		FoliageQuality >= 3 ? 1.25f : (FoliageQuality == 2 ? 1.f : (FoliageQuality == 1 ? 0.7f : 0.45f)));

	SetCVar(TEXT("r.VolumetricCloud"), (PostProcessQuality >= 1) ? 1 : 0);
	SetCVar(TEXT("r.VolumetricFog"), (EffectsQuality >= 1) ? 1 : 0);
}

void UBFGameSettings::ApplyAudio(UObject* WorldContext)
{
	if (!WorldContext)
	{
		return;
	}

	ApplyOneSoundClass(WorldContext, MasterSoundClass, MasterVolume);
	ApplyOneSoundClass(WorldContext, MusicSoundClass, MusicVolume * MasterVolume);
	ApplyOneSoundClass(WorldContext, EffectsSoundClass, EffectsVolume * MasterVolume);
	ApplyOneSoundClass(WorldContext, VoiceSoundClass, VoiceVolume * MasterVolume);
	ApplyOneSoundClass(WorldContext, RadioSoundClass, RadioVolume * MasterVolume);
}

void UBFGameSettings::ApplyOneSoundClass(UObject* WorldContext, const TSoftObjectPtr<USoundClass>& SoundClass, float Volume)
{
	USoundMix* Mix = SettingsSoundMix.LoadSynchronous();
	USoundClass* Class = SoundClass.LoadSynchronous();

	if (!Mix || !Class)
	{
		// Audio assets are authored in the editor. Until they exist the volumes are
		// simply stored, so a content-less build still runs.
		return;
	}

	UGameplayStatics::SetSoundMixClassOverride(WorldContext, Mix, Class, FMath::Clamp(Volume, 0.f, 1.f), 1.f, 0.2f, true);
	UGameplayStatics::PushSoundMixModifier(WorldContext, Mix);
}

void UBFGameSettings::ApplyGameplay(UObject* WorldContext)
{
	// Gameplay options are read directly by the HUD, the camera and the input handlers
	// through GetSettings(), so there is nothing to push here beyond clamping.
	CameraShakeScale = FMath::Clamp(CameraShakeScale, 0.f, 1.f);
	FieldOfView = FMath::Clamp(FieldOfView, 70.f, 110.f);
	MouseSensitivity = FMath::Clamp(MouseSensitivity, 0.1f, 5.f);
	ADSSensitivityScale = FMath::Clamp(ADSSensitivityScale, 0.1f, 2.f);
}

void UBFGameSettings::SetQualityPreset(EBFQualityPreset NewPreset)
{
	QualityPreset = NewPreset;
	if (NewPreset != EBFQualityPreset::Custom)
	{
		ApplyPresetValues(NewPreset);
	}
	ApplyGraphics();
	SaveToDisk();
}

void UBFGameSettings::ApplyPresetToFields(EBFQualityPreset Preset)
{
	QualityPreset = Preset;
	ApplyPresetValues(Preset);
}

void UBFGameSettings::ResetToDefaults()
{
	if (const UBFGameSettings* Defaults = GetDefault<UBFGameSettings>())
	{
		Resolution = Defaults->Resolution;
		WindowMode = Defaults->WindowMode;
		FrameRateLimit = Defaults->FrameRateLimit;
		QualityPreset = Defaults->QualityPreset;
		bVSync = Defaults->bVSync;
		ResolutionScale = Defaults->ResolutionScale;
		AntiAliasingMode = Defaults->AntiAliasingMode;

		MasterVolume = Defaults->MasterVolume;
		MusicVolume = Defaults->MusicVolume;
		EffectsVolume = Defaults->EffectsVolume;
		VoiceVolume = Defaults->VoiceVolume;
		RadioVolume = Defaults->RadioVolume;

		MouseSensitivity = Defaults->MouseSensitivity;
		ADSSensitivityScale = Defaults->ADSSensitivityScale;
		bInvertY = Defaults->bInvertY;
		bToggleCrouch = Defaults->bToggleCrouch;
		bToggleSprint = Defaults->bToggleSprint;
		bToggleADS = Defaults->bToggleADS;
		bHoldToLean = Defaults->bHoldToLean;
		KeyBindings = Defaults->KeyBindings;

		bShowHUD = Defaults->bShowHUD;
		bShowCrosshair = Defaults->bShowCrosshair;
		bShowMinimap = Defaults->bShowMinimap;
		CameraShakeScale = Defaults->CameraShakeScale;
		bSubtitles = Defaults->bSubtitles;
		bRadioSubtitles = Defaults->bRadioSubtitles;
		FieldOfView = Defaults->FieldOfView;
	}

	ApplyPresetValues(QualityPreset);
	SaveToDisk();
}

void UBFGameSettings::SaveToDisk()
{
	SaveConfig();
}

void UBFGameSettings::LoadFromDisk()
{
	LoadConfig();

	// A first run has no ini: seed the resolution from the actual desktop so the game
	// does not open in a letterboxed window.
	if (UGameUserSettings* User = GEngine ? GEngine->GetGameUserSettings() : nullptr)
	{
		if (Resolution.X <= 0 || Resolution.Y <= 0)
		{
			Resolution = User->GetDesktopResolution();
		}
	}
}

TArray<FIntPoint> UBFGameSettings::GetSupportedResolutions() const
{
	TArray<FIntPoint> Out;
	FScreenResolutionArray Resolutions;

	if (RHIGetAvailableResolutions(Resolutions, true))
	{
		for (const FScreenResolutionRHI& Res : Resolutions)
		{
			const FIntPoint Point(Res.Width, Res.Height);
			if (Point.X >= 1280 && !Out.Contains(Point))
			{
				Out.Add(Point);
			}
		}
	}

	if (Out.Num() == 0)
	{
		Out.Append({ FIntPoint(1280, 720), FIntPoint(1600, 900), FIntPoint(1920, 1080),
					 FIntPoint(2560, 1440), FIntPoint(3840, 2160) });
	}

	Out.Sort([](const FIntPoint& A, const FIntPoint& B) { return A.X * A.Y < B.X * B.Y; });
	return Out;
}

void UBFGameSettings::SetKeyBinding(FName ActionName, const FKey& NewKey, bool bSecondary)
{
	for (FBFKeyBinding& Binding : KeyBindings)
	{
		if (Binding.ActionName == ActionName)
		{
			if (bSecondary) { Binding.SecondaryKey = NewKey; }
			else { Binding.PrimaryKey = NewKey; }
			SaveToDisk();
			return;
		}
	}

	FBFKeyBinding NewBinding;
	NewBinding.ActionName = ActionName;
	if (bSecondary) { NewBinding.SecondaryKey = NewKey; } else { NewBinding.PrimaryKey = NewKey; }
	KeyBindings.Add(NewBinding);
	SaveToDisk();
}

FKey UBFGameSettings::GetKeyBinding(FName ActionName, bool bSecondary) const
{
	for (const FBFKeyBinding& Binding : KeyBindings)
	{
		if (Binding.ActionName == ActionName)
		{
			return bSecondary ? Binding.SecondaryKey : Binding.PrimaryKey;
		}
	}
	return FKey();
}
