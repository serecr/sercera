#include "Systems/BFDamageManager.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Core/BFLog.h"
#include "Data/BFWeaponDataAsset.h"
#include "Engine/DamageEvents.h"
#include "Engine/OverlapResult.h"
#include "Engine/World.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"
#include "GameFramework/Controller.h"
#include "Kismet/GameplayStatics.h"
#include "Systems/BFCraterManager.h"
#include "Systems/BFDestructibleActor.h"
#include "Vehicles/BFVehicleBase.h"

FName UBFDamageManager::ResolveHitZone(FName BoneName)
{
	if (BoneName.IsNone())
	{
		return TEXT("torso");
	}

	const FString Bone = BoneName.ToString().ToLower();

	if (Bone.Contains(TEXT("head")) || Bone.Contains(TEXT("neck")) || Bone.Contains(TEXT("face")))
	{
		return TEXT("head");
	}
	if (Bone.Contains(TEXT("clavicle")) || Bone.Contains(TEXT("spine")) || Bone.Contains(TEXT("pelvis")) || Bone.Contains(TEXT("ribcage")))
	{
		return TEXT("torso");
	}
	if (Bone.Contains(TEXT("upperarm")) || Bone.Contains(TEXT("lowerarm")) || Bone.Contains(TEXT("hand")) || Bone.Contains(TEXT("finger")))
	{
		return TEXT("arms");
	}
	if (Bone.Contains(TEXT("thigh")) || Bone.Contains(TEXT("calf")) || Bone.Contains(TEXT("foot")) || Bone.Contains(TEXT("ball")))
	{
		return TEXT("legs");
	}

	return TEXT("torso");
}

bool UBFDamageManager::ShouldApplyDamage(UObject* WorldContextObject, EBFTeam ShooterTeam, EBFTeam TargetTeam, float& OutScale)
{
	OutScale = 1.f;

	if (TargetTeam == EBFTeam::Neutral || ShooterTeam == EBFTeam::Neutral)
	{
		return true; // world objects, unassigned actors
	}

	if (ShooterTeam != TargetTeam)
	{
		return true;
	}

	// Same team. Ask the match rules.
	const UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	if (const ABFGameState* GS = World ? World->GetGameState<ABFGameState>() : nullptr)
	{
		if (!GS->IsFriendlyFireEnabled())
		{
			return false;
		}
		OutScale = GS->GetFriendlyFireScale();
		return true;
	}

	return false;
}

void UBFDamageManager::ApplyWeaponDamage(
	AActor* Target,
	float BaseDamage,
	const FHitResult& Hit,
	const FVector& ShotDirection,
	ABFCharacter* Shooter,
	AActor* DamageCauser,
	const UBFWeaponDataAsset* WeaponData)
{
	if (!Target || BaseDamage <= 0.f)
	{
		return;
	}

	UWorld* World = Target->GetWorld();
	if (!World || !Target->HasAuthority())
	{
		return;
	}

	float Damage = BaseDamage;

	// --- Destructible cover: structural damage, no hit zones. ---
	if (ABFDestructibleActor* Destructible = Cast<ABFDestructibleActor>(Target))
	{
		Destructible->ApplyStructuralDamage(Damage, Hit.ImpactPoint, ShotDirection, Shooter);
		return;
	}

	// --- Vehicles: armour by component, handled by the vehicle itself. ---
	if (ABFVehicleBase* Vehicle = Cast<ABFVehicleBase>(Target))
	{
		Vehicle->ApplyVehicleDamage(Damage, Hit, ShotDirection, Shooter);
		return;
	}

	// --- Soldiers ---
	ABFCharacter* TargetChar = Cast<ABFCharacter>(Target);
	if (!TargetChar)
	{
		// Generic actor: let the engine's damage pipeline deal with it.
		const FPointDamageEvent DamageEvent(Damage, Hit, ShotDirection, nullptr);
		Target->TakeDamage(Damage, DamageEvent, Shooter ? Shooter->GetController() : nullptr, DamageCauser);
		return;
	}

	const EBFTeam ShooterTeam = Shooter ? Shooter->GetTeam() : EBFTeam::Neutral;
	float TeamScale = 1.f;
	if (!ShouldApplyDamage(Target, ShooterTeam, TargetChar->GetTeam(), TeamScale))
	{
		return;
	}
	Damage *= TeamScale;

	// Hit zone multiplier from the weapon's own table; 1.0 if unlisted.
	const FName Zone = ResolveHitZone(Hit.BoneName);
	if (WeaponData)
	{
		if (const float* Multiplier = WeaponData->HitZoneMultipliers.Find(Zone))
		{
			Damage *= *Multiplier;
		}
	}

	if (UBFHealthComponent* Health = TargetChar->GetHealthComponent())
	{
		const bool bWasAlive = Health->IsAlive() && !Health->IsDowned();
		Health->ApplyHealthDelta(-Damage, Shooter, Hit.BoneName);

		// Score the kill once, on the transition.
		if (bWasAlive && (Health->IsDead() || Health->IsDowned()) && Shooter && Shooter != TargetChar)
		{
			if (ABFPlayerState* ShooterPS = Shooter->GetPlayerState<ABFPlayerState>())
			{
				ShooterPS->RegisterKill(TargetChar->GetPlayerState<ABFPlayerState>(), Zone == TEXT("head"));
			}
			if (ABFPlayerState* VictimPS = TargetChar->GetPlayerState<ABFPlayerState>())
			{
				VictimPS->RegisterDeath(Shooter->GetPlayerState<ABFPlayerState>());
			}
		}
	}
}

void UBFDamageManager::ApplyExplosion(
	UObject* WorldContextObject,
	FVector Origin,
	float Radius,
	float MaxDamage,
	AActor* Instigator,
	bool bSpawnCrater,
	float StructuralMultiplier)
{
	UWorld* World = GEngine ? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull) : nullptr;
	if (!World || Radius <= 0.f)
	{
		return;
	}

	// Authority gate: explosions change the map, so only the server may run one.
	if (World->GetNetMode() == NM_Client)
	{
		return;
	}

	ABFCharacter* InstigatorChar = Cast<ABFCharacter>(Instigator);
	const EBFTeam InstigatorTeam = InstigatorChar ? InstigatorChar->GetTeam() : EBFTeam::Neutral;

	TArray<FOverlapResult> Overlaps;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFExplosion), false);
	FCollisionObjectQueryParams ObjectParams;
	ObjectParams.AddObjectTypesToQuery(ECC_Pawn);
	ObjectParams.AddObjectTypesToQuery(ECC_WorldDynamic);
	ObjectParams.AddObjectTypesToQuery(ECC_PhysicsBody);
	ObjectParams.AddObjectTypesToQuery(ECC_Vehicle);
	ObjectParams.AddObjectTypesToQuery(ECC_Destructible);

	World->OverlapMultiByObjectType(Overlaps, Origin, FQuat::Identity, ObjectParams,
		FCollisionShape::MakeSphere(Radius), Params);

	TSet<AActor*> Processed;

	for (const FOverlapResult& Overlap : Overlaps)
	{
		AActor* Actor = Overlap.GetActor();
		if (!Actor || Processed.Contains(Actor))
		{
			continue;
		}
		Processed.Add(Actor);

		const FVector ToActor = Actor->GetActorLocation() - Origin;
		const float Distance = ToActor.Size();
		const float Falloff = FMath::Clamp(1.f - (Distance / Radius), 0.f, 1.f);
		// Quadratic falloff: standing at the rim is survivable, the centre is not.
		float Damage = MaxDamage * Falloff * Falloff;

		if (Damage <= 1.f)
		{
			continue;
		}

		// Line of sight: a trench wall or sandbag stack should shield you.
		FHitResult Block;
		FCollisionQueryParams LosParams(SCENE_QUERY_STAT(BFExplosionLOS), false);
		LosParams.AddIgnoredActor(Actor);
		if (World->LineTraceSingleByChannel(Block, Origin, Actor->GetActorLocation(), ECC_WorldStatic, LosParams))
		{
			Damage *= 0.35f;
		}

		if (ABFDestructibleActor* Destructible = Cast<ABFDestructibleActor>(Actor))
		{
			Destructible->ApplyStructuralDamage(Damage * StructuralMultiplier, Origin, ToActor.GetSafeNormal(), InstigatorChar);
			continue;
		}

		if (ABFVehicleBase* Vehicle = Cast<ABFVehicleBase>(Actor))
		{
			FHitResult FakeHit;
			FakeHit.ImpactPoint = Origin;
			FakeHit.ImpactNormal = -ToActor.GetSafeNormal();
			Vehicle->ApplyVehicleDamage(Damage, FakeHit, ToActor.GetSafeNormal(), InstigatorChar);
			continue;
		}

		if (ABFCharacter* Char = Cast<ABFCharacter>(Actor))
		{
			float TeamScale = 1.f;
			if (!ShouldApplyDamage(World, InstigatorTeam, Char->GetTeam(), TeamScale))
			{
				continue;
			}

			if (UBFHealthComponent* Health = Char->GetHealthComponent())
			{
				Health->ApplyHealthDelta(-Damage * TeamScale, Instigator, TEXT("torso"));
			}

			// Kick up dirt onto the uniform - cheap, memorable detail.
			if (UBFMudComponent* Mud = Char->GetMud())
			{
				Mud->AddMudBurst(Falloff * 0.35f);
			}
			continue;
		}

		// Loose debris gets thrown around by Chaos.
		if (UPrimitiveComponent* Prim = Overlap.GetComponent())
		{
			if (Prim->IsSimulatingPhysics())
			{
				Prim->AddRadialImpulse(Origin, Radius, MaxDamage * 12.f, ERadialImpulseFalloff::RIF_Linear, true);
			}
		}
	}

	if (bSpawnCrater)
	{
		if (ABFCraterManager* Craters = ABFCraterManager::Get(World))
		{
			EBFCraterSize Size = EBFCraterSize::Small;
			if (Radius > 900.f)      { Size = EBFCraterSize::Large; }
			else if (Radius > 450.f) { Size = EBFCraterSize::Medium; }

			Craters->SpawnCrater(Origin, Size);
		}
	}
}
