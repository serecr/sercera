#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFDestructibleActor.generated.h"

class UStaticMeshComponent;
class UGeometryCollectionComponent;
class UBoxComponent;
class UNiagaraSystem;
class USoundBase;
class ABFCharacter;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFDestructibleStageChanged, int32, NewStage);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FBFDestructibleDestroyed);

/**
 * Wooden walls, sandbag stacks, bunker panels, barricades: anything that can be
 * shot down and that changes how players move once it is gone.
 *
 * Three-stage model:
 *   Stage 0 - intact mesh, blocks movement and sight
 *   Stage 1 - damaged mesh, gaps you can shoot through
 *   Stage 2 - destroyed: Chaos geometry collection is released, collision drops,
 *             and the optional BlockedRoute volume is disabled, opening a new path.
 *
 * Only the server tracks integrity; clients receive the stage and play the break.
 */
UCLASS()
class BROKENFRONT_API ABFDestructibleActor : public AActor
{
	GENERATED_BODY()

public:
	ABFDestructibleActor();

	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Destructible") FBFDestructibleStageChanged OnStageChanged;
	UPROPERTY(BlueprintAssignable, Category = "Destructible") FBFDestructibleDestroyed OnDestroyed;

	/** Server: bullets, shrapnel and vehicle impacts all land here. */
	void ApplyStructuralDamage(float Damage, const FVector& ImpactPoint, const FVector& Direction, ABFCharacter* Instigator);

	/** Server: Engineer repairs. Returns the amount actually restored. */
	UFUNCTION(BlueprintCallable, Category = "Destructible")
	float Repair(float Amount, ABFCharacter* Engineer);

	/** Server: full reset, used when a sector changes hands. */
	UFUNCTION(BlueprintCallable, Category = "Destructible")
	void RepairFully();

	UFUNCTION(BlueprintPure, Category = "Destructible") float GetIntegrity() const { return Integrity; }
	UFUNCTION(BlueprintPure, Category = "Destructible") float GetIntegrityPercent() const { return MaxIntegrity > 0.f ? Integrity / MaxIntegrity : 0.f; }
	UFUNCTION(BlueprintPure, Category = "Destructible") bool IsDestroyed() const { return DamageStage >= 2; }
	UFUNCTION(BlueprintPure, Category = "Destructible") int32 GetDamageStage() const { return DamageStage; }
	UFUNCTION(BlueprintPure, Category = "Destructible") EBFTeam GetOwningTeam() const { return OwningTeam; }

	void SetOwningTeam(EBFTeam NewTeam);

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> IntactMesh;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> DamagedMesh;

	/** Chaos fracture, released on destruction. Optional but strongly recommended. */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UGeometryCollectionComponent> RubbleCollection;

	/**
	 * Placed across a doorway or gap this piece is blocking. Disabled when the
	 * piece is destroyed, which is what physically "opens a new route".
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBoxComponent> BlockedRouteVolume;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "1.0"))
	float MaxIntegrity = 600.f;

	/** Integrity fraction at which the damaged mesh swaps in. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "0.05", ClampMax = "0.95"))
	float DamagedThreshold = 0.45f;

	/** Small-arms fire barely scratches concrete; this scales incoming bullet damage. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "0.0"))
	float BulletDamageScale = 1.f;

	/** Surface used for impact VFX and footsteps on top of it. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	EBFSurfaceType SurfaceType = EBFSurfaceType::Wood;

	/** Engineers can repair this piece back up. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	bool bRepairable = true;

	/** Destroying this awards score to the attacking team. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	int32 DestructionScore = 75;

	/** Rubble is cleaned up after this many seconds to protect performance. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	float RubbleLifetime = 45.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "FX") TSoftObjectPtr<UNiagaraSystem> DamageEffect;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "FX") TSoftObjectPtr<UNiagaraSystem> DestructionEffect;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "FX") TSoftObjectPtr<USoundBase> DamageSound;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "FX") TSoftObjectPtr<USoundBase> DestructionSound;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float Integrity = 600.f;

	UPROPERTY(ReplicatedUsing = OnRep_DamageStage, BlueprintReadOnly, Category = "State")
	int32 DamageStage = 0;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	EBFTeam OwningTeam = EBFTeam::Neutral;

	UFUNCTION() void OnRep_DamageStage();

	/** Applies the visual/collision state for the current stage on every machine. */
	void ApplyStage(int32 Stage, bool bPlayEffects);

	UFUNCTION(NetMulticast, Unreliable)
	void MulticastImpact(FVector_NetQuantize ImpactPoint, FVector_NetQuantizeNormal Direction);

private:
	FTimerHandle RubbleCleanupTimer;
	void CleanUpRubble();
};
