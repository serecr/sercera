#include "Systems/BFSpawnManager.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Core/BFLog.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerController.h"
#include "Gameplay/BFPlayerState.h"
#include "Sectors/BFSector.h"
#include "Sectors/BFSpawnPoint.h"

UBFSpawnManager* UBFSpawnManager::Get(const UWorld* World)
{
	return World ? World->GetSubsystem<UBFSpawnManager>() : nullptr;
}

void UBFSpawnManager::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);
	RefreshSpawnPoints();
}

void UBFSpawnManager::RefreshSpawnPoints()
{
	SpawnPoints.Reset();

	if (UWorld* World = GetWorld())
	{
		for (TActorIterator<ABFSpawnPoint> It(World); It; ++It)
		{
			SpawnPoints.Add(*It);
		}
	}

	BF_LOG(LogBrokenFront, Log, TEXT("Registered %d spawn points."), SpawnPoints.Num());
}

TArray<ABFSpawnPoint*> UBFSpawnManager::GetAvailableSpawnsForTeam(EBFTeam Team) const
{
	TArray<ABFSpawnPoint*> Result;
	for (const TObjectPtr<ABFSpawnPoint>& Point : SpawnPoints)
	{
		if (Point && Point->IsEnabled() && Point->GetOwningTeam() == Team)
		{
			Result.Add(Point.Get());
		}
	}
	return Result;
}

ABFCharacter* UBFSpawnManager::FindSquadAnchor(const APlayerController* Controller) const
{
	const ABFPlayerState* PS = Controller ? Controller->GetPlayerState<ABFPlayerState>() : nullptr;
	if (!PS || PS->GetSquadId() == INDEX_NONE)
	{
		return nullptr;
	}

	ABFCharacter* Best = nullptr;
	float BestScore = -1.f;

	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		ABFCharacter* Char = *It;
		if (!Char || Char->GetTeam() != PS->GetTeam())
		{
			continue;
		}

		const ABFPlayerState* OtherPS = Char->GetPlayerState<ABFPlayerState>();
		if (!OtherPS || OtherPS == PS || OtherPS->GetSquadId() != PS->GetSquadId())
		{
			continue;
		}

		const UBFHealthComponent* Health = Char->GetHealthComponent();
		if (!Health || !Health->IsAlive() || Health->IsDowned())
		{
			continue;
		}

		// Do not drop a player into an active firefight: prefer squadmates who are
		// not currently being shot at. Squad leaders are preferred anchors.
		float Score = OtherPS->IsSquadLeader() ? 100.f : 50.f;

		bool bEnemyNearby = false;
		for (TActorIterator<ABFCharacter> Inner(GetWorld()); Inner; ++Inner)
		{
			const ABFCharacter* Enemy = *Inner;
			if (Enemy && Enemy->GetTeam() != PS->GetTeam() && Enemy->GetTeam() != EBFTeam::Neutral)
			{
				if (FVector::DistSquared(Enemy->GetActorLocation(), Char->GetActorLocation()) < FMath::Square(3000.f))
				{
					bEnemyNearby = true;
					break;
				}
			}
		}

		if (bEnemyNearby)
		{
			Score -= 80.f;
		}

		if (Score > BestScore)
		{
			BestScore = Score;
			Best = Char;
		}
	}

	return BestScore > 0.f ? Best : nullptr;
}

FTransform UBFSpawnManager::ResolveCollisionFreeTransform(const FTransform& Base) const
{
	UWorld* World = GetWorld();
	if (!World)
	{
		return Base;
	}

	const float Radius = 45.f;
	const float HalfHeight = 95.f;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFSpawnResolve), false);

	for (int32 Attempt = 0; Attempt < 12; ++Attempt)
	{
		FVector Candidate = Base.GetLocation();
		if (Attempt > 0)
		{
			// Ring outwards so a full squad deploying at once does not stack up.
			const float Angle = (Attempt * 137.5f);
			const float Distance = 120.f + Attempt * 45.f;
			Candidate += FVector(FMath::Cos(FMath::DegreesToRadians(Angle)) * Distance,
								 FMath::Sin(FMath::DegreesToRadians(Angle)) * Distance, 0.f);
		}

		if (!World->OverlapBlockingTestByChannel(Candidate, FQuat::Identity, ECC_Pawn,
			FCollisionShape::MakeCapsule(Radius, HalfHeight), Params))
		{
			FTransform Result = Base;
			Result.SetLocation(Candidate);
			return Result;
		}
	}

	return Base;
}

FTransform UBFSpawnManager::FindSpawnOfKind(APlayerController* Controller, EBFSpawnKind Kind, bool& bOutFound)
{
	bOutFound = false;

	const ABFPlayerState* PS = Controller ? Controller->GetPlayerState<ABFPlayerState>() : nullptr;
	if (!PS)
	{
		return FTransform::Identity;
	}

	if (Kind == EBFSpawnKind::Squad)
	{
		if (const ABFCharacter* Anchor = FindSquadAnchor(Controller))
		{
			bOutFound = true;
			FTransform Transform = Anchor->GetActorTransform();
			// Drop in slightly behind the squadmate rather than on top of them.
			Transform.SetLocation(Anchor->GetActorLocation() - Anchor->GetActorForwardVector() * 220.f);
			return ResolveCollisionFreeTransform(Transform);
		}
		return FTransform::Identity;
	}

	ABFSpawnPoint* Best = nullptr;
	float BestScore = -FLT_MAX;

	for (const TObjectPtr<ABFSpawnPoint>& Point : SpawnPoints)
	{
		if (!Point || Point->GetSpawnKind() != Kind || Point->GetOwningTeam() != PS->GetTeam())
		{
			continue;
		}

		const float Score = Point->ScoreForPlayer(Controller, FVector::ZeroVector);
		if (Score > BestScore)
		{
			BestScore = Score;
			Best = Point.Get();
		}
	}

	if (Best)
	{
		bOutFound = true;
		return ResolveCollisionFreeTransform(Best->GetActorTransform());
	}

	return FTransform::Identity;
}

FTransform UBFSpawnManager::FindBestSpawnTransform(APlayerController* Controller, bool& bOutFound)
{
	bOutFound = false;

	const ABFPlayerState* PS = Controller ? Controller->GetPlayerState<ABFPlayerState>() : nullptr;
	if (!PS || PS->GetTeam() == EBFTeam::Neutral)
	{
		return FTransform::Identity;
	}

	// 1. Squad spawn is the most valuable for keeping a fight going.
	FTransform Result = FindSpawnOfKind(Controller, EBFSpawnKind::Squad, bOutFound);
	if (bOutFound)
	{
		return Result;
	}

	// 2. Otherwise score every enabled point for the team and take the best.
	ABFSpawnPoint* Best = nullptr;
	float BestScore = -FLT_MAX;

	for (const TObjectPtr<ABFSpawnPoint>& Point : SpawnPoints)
	{
		if (!Point || !Point->IsEnabled() || Point->GetOwningTeam() != PS->GetTeam())
		{
			continue;
		}

		const float Score = Point->ScoreForPlayer(Controller, FVector::ZeroVector);
		if (Score > BestScore)
		{
			BestScore = Score;
			Best = Point.Get();
		}
	}

	if (Best)
	{
		bOutFound = true;
		return ResolveCollisionFreeTransform(Best->GetActorTransform());
	}

	// 3. Last resort: any fallback point regardless of safety scoring.
	for (const TObjectPtr<ABFSpawnPoint>& Point : SpawnPoints)
	{
		if (Point && Point->GetSpawnKind() == EBFSpawnKind::Fallback && Point->GetOwningTeam() == PS->GetTeam())
		{
			bOutFound = true;
			return ResolveCollisionFreeTransform(Point->GetActorTransform());
		}
	}

	BF_LOG(LogBrokenFront, Warning, TEXT("No spawn available for team %d."), static_cast<int32>(PS->GetTeam()));
	return FTransform::Identity;
}
