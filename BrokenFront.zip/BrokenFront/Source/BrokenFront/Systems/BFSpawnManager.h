#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Core/BFTypes.h"
#include "BFSpawnManager.generated.h"

class ABFSpawnPoint;
class ABFCharacter;
class APlayerController;

/**
 * Chooses where a player deploys. Priority: squadmate -> owned forward sector ->
 * main base -> fallback. Points tied to a lost sector are already disabled by the
 * sector itself, so this only has to score what is left.
 */
UCLASS()
class BROKENFRONT_API UBFSpawnManager : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	static UBFSpawnManager* Get(const UWorld* World);

	virtual void OnWorldBeginPlay(UWorld& InWorld) override;

	/** Rebuilds the cached list. Cheap; call after streaming a level in. */
	UFUNCTION(BlueprintCallable, Category = "Spawn")
	void RefreshSpawnPoints();

	/**
	 * Best spawn transform for this controller. bOutFound is false when the team
	 * has literally nowhere left to deploy, which the game mode treats as a loss.
	 */
	UFUNCTION(BlueprintCallable, Category = "Spawn")
	FTransform FindBestSpawnTransform(APlayerController* Controller, bool& bOutFound);

	/** Explicit request from the deploy screen, e.g. "spawn on squad leader". */
	UFUNCTION(BlueprintCallable, Category = "Spawn")
	FTransform FindSpawnOfKind(APlayerController* Controller, EBFSpawnKind Kind, bool& bOutFound);

	UFUNCTION(BlueprintPure, Category = "Spawn")
	TArray<ABFSpawnPoint*> GetAvailableSpawnsForTeam(EBFTeam Team) const;

private:
	UPROPERTY() TArray<TObjectPtr<ABFSpawnPoint>> SpawnPoints;

	/** Finds a living squadmate to deploy next to. */
	ABFCharacter* FindSquadAnchor(const APlayerController* Controller) const;

	/** Nudges a spawn transform so two players never materialise inside each other. */
	FTransform ResolveCollisionFreeTransform(const FTransform& Base) const;
};
