#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Core/BFTypes.h"
#include "BFRadioComponent.generated.h"

class USoundBase;
class ABFCharacter;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FBFRadioReceived, EBFRadioCommand, Command, EBFRadioChannel, Channel, const FString&, SenderName, FVector, WorldLocation);

/** Voice line bank for one faction. */
USTRUCT(BlueprintType)
struct FBFRadioLine
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) EBFRadioCommand Command = EBFRadioCommand::EnemySpotted;
	/** Heard in the world, from the soldier's mouth. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> LocalVoice;
	/** Heard over the radio: filtered, non-spatial. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> RadioVoice;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) FText SubtitleText;
};

/**
 * Preset comms. Three channels with different reach:
 *   Local  - shouted, spatialised, anyone nearby hears it including enemies
 *   Squad  - filtered radio, squad only
 *   Team   - filtered radio, whole team, rate limited so it cannot be spammed
 *
 * Sending is validated server-side; the server fans the message out only to the
 * players who should hear it.
 */
UCLASS(ClassGroup = (BrokenFront), meta = (BlueprintSpawnableComponent))
class BROKENFRONT_API UBFRadioComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBFRadioComponent();

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Radio") FBFRadioReceived OnRadioReceived;

	/** Local entry point. Rate limited, then forwarded to the server. */
	UFUNCTION(BlueprintCallable, Category = "Radio")
	void SendCommand(EBFRadioCommand Command, EBFRadioChannel Channel);

	UFUNCTION(BlueprintPure, Category = "Radio")
	FText GetSubtitleFor(EBFRadioCommand Command) const;

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<FBFRadioLine> RadioLines;

	/** Metres a Local call carries. Enemies inside this hear it too. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float LocalVoiceRange = 2600.f;

	/** Minimum seconds between two calls from the same player. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float CommandCooldown = 2.5f;

	UFUNCTION(Server, Reliable, WithValidation)
	void ServerSendCommand(EBFRadioCommand Command, EBFRadioChannel Channel);

	/** Only sent to the clients the server decided should hear it. */
	UFUNCTION(Client, Reliable)
	void ClientReceiveCommand(EBFRadioCommand Command, EBFRadioChannel Channel, const FString& SenderName, FVector_NetQuantize WorldLocation);

	/** Local shout: everyone in range gets it, so a plain multicast is correct here. */
	UFUNCTION(NetMulticast, Unreliable)
	void MulticastLocalVoice(EBFRadioCommand Command, const FString& SenderName, FVector_NetQuantize WorldLocation);

private:
	float LastSendTime = -100.f;

	const FBFRadioLine* FindLine(EBFRadioCommand Command) const;
	void PlayLine(EBFRadioCommand Command, EBFRadioChannel Channel, const FVector& Location);
};
