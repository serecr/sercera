#include "Systems/BFObjectiveManager.h"

#include "Core/BFLog.h"
#include "EngineUtils.h"
#include "Frontline/BFFrontlineManager.h"
#include "Sectors/BFObjective.h"
#include "Sectors/BFSector.h"

UBFObjectiveManager* UBFObjectiveManager::Get(const UWorld* World)
{
	return World ? World->GetSubsystem<UBFObjectiveManager>() : nullptr;
}

void UBFObjectiveManager::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);
	GatherObjectives();
}

void UBFObjectiveManager::GatherObjectives()
{
	AllObjectives.Reset();

	if (UWorld* World = GetWorld())
	{
		for (TActorIterator<ABFObjective> It(World); It; ++It)
		{
			AllObjectives.Add(*It);
		}
	}
}

TArray<ABFObjective*> UBFObjectiveManager::GetObjectivesInSector(const ABFSector* Sector) const
{
	TArray<ABFObjective*> Result;
	if (!Sector)
	{
		return Result;
	}

	for (const TObjectPtr<ABFObjective>& Objective : AllObjectives)
	{
		if (Objective && Objective->GetSector() == Sector)
		{
			Result.Add(Objective.Get());
		}
	}
	return Result;
}

void UBFObjectiveManager::ActivateBestObjectiveOfType(ABFSector* Sector, EBFObjectiveType Type, EBFTeam Team, TSet<ABFObjective*>& OutActivated)
{
	if (!Sector || Team == EBFTeam::Neutral)
	{
		return;
	}

	for (const TObjectPtr<ABFObjective>& Objective : AllObjectives)
	{
		ABFObjective* Obj = Objective.Get();
		if (!Obj || Obj->GetSector() != Sector || Obj->GetObjectiveType() != Type)
		{
			continue;
		}

		// Do not re-open something that already resolved this match.
		if (Obj->GetStatus() == EBFObjectiveStatus::Completed)
		{
			continue;
		}

		Obj->ActivateFor(Team);
		OutActivated.Add(Obj);
		return; // one of each type per sector keeps the HUD readable
	}
}

void UBFObjectiveManager::RebuildObjectivesForFrontline(ABFFrontlineManager* Frontline)
{
	UWorld* World = GetWorld();
	if (!World || World->GetNetMode() == NM_Client || !Frontline)
	{
		return;
	}

	if (AllObjectives.Num() == 0)
	{
		GatherObjectives();
	}

	TSet<ABFObjective*> ShouldBeActive;

	for (EBFTeam Team : { EBFTeam::Ironclad, EBFTeam::Ashguard })
	{
		// Attack work on the sector this team is pushing into.
		if (ABFSector* AttackTarget = Frontline->GetAttackTargetFor(Team))
		{
			ActivateBestObjectiveOfType(AttackTarget, EBFObjectiveType::CaptureSector, Team, ShouldBeActive);
			ActivateBestObjectiveOfType(AttackTarget, EBFObjectiveType::DestroyObjective, Team, ShouldBeActive);
			ActivateBestObjectiveOfType(AttackTarget, EBFObjectiveType::ReconArea, Team, ShouldBeActive);
		}

		// Defensive work on the sector they are holding at the front.
		if (ABFSector* DefenceTarget = Frontline->GetDefenceTargetFor(Team))
		{
			ActivateBestObjectiveOfType(DefenceTarget, EBFObjectiveType::DefendSector, Team, ShouldBeActive);
			ActivateBestObjectiveOfType(DefenceTarget, EBFObjectiveType::HoldPosition, Team, ShouldBeActive);
			ActivateBestObjectiveOfType(DefenceTarget, EBFObjectiveType::ProtectSupply, Team, ShouldBeActive);
		}
	}

	// Anything else goes quiet.
	int32 Deactivated = 0;
	for (const TObjectPtr<ABFObjective>& Objective : AllObjectives)
	{
		ABFObjective* Obj = Objective.Get();
		if (Obj && !ShouldBeActive.Contains(Obj) && Obj->GetStatus() == EBFObjectiveStatus::Active)
		{
			Obj->Deactivate();
			++Deactivated;
		}
	}

	BF_LOG(LogBFFrontline, Verbose, TEXT("Objectives rebuilt: %d active, %d stood down."),
		ShouldBeActive.Num(), Deactivated);
}

bool UBFObjectiveManager::AssignCommanderObjective(EBFTeam Team, ABFObjective* Objective)
{
	if (!Objective || Team == EBFTeam::Neutral)
	{
		return false;
	}

	UWorld* World = GetWorld();
	if (!World || World->GetNetMode() == NM_Client)
	{
		return false;
	}

	const ABFSector* Sector = Objective->GetSector();
	if (Sector && !Sector->IsActive())
	{
		return false; // cannot task the squad with dead ground
	}

	Objective->ActivateFor(Team);
	return true;
}
