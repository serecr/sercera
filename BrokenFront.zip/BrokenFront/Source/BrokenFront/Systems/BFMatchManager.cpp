#include "Systems/BFMatchManager.h"

#include "Core/BFLog.h"
#include "Frontline/BFFrontlineManager.h"
#include "GameFramework/PlayerController.h"
#include "Gameplay/BFGameInstance.h"
#include "Gameplay/BFGameMode.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"

UBFMatchManager* UBFMatchManager::Get(const UWorld* World)
{
	return World ? World->GetSubsystem<UBFMatchManager>() : nullptr;
}

void UBFMatchManager::OnWorldBeginPlay(UWorld& InWorld)
{
	Super::OnWorldBeginPlay(InWorld);

	if (InWorld.GetNetMode() != NM_Client)
	{
		bTickEnabled = true;
		EnterPhase(EBFMatchPhase::WaitingForPlayers);
	}
}

ABFGameState* UBFMatchManager::GetBFGameState() const
{
	const UWorld* World = GetWorld();
	return World ? World->GetGameState<ABFGameState>() : nullptr;
}

void UBFMatchManager::EnterPhase(EBFMatchPhase Phase)
{
	ABFGameState* GS = GetBFGameState();
	if (!GS)
	{
		return;
	}

	GS->SetMatchPhase(Phase);

	switch (Phase)
	{
	case EBFMatchPhase::WaitingForPlayers:
		PhaseTimeRemaining = 0.f;
		break;
	case EBFMatchPhase::Warmup:
		PhaseTimeRemaining = WarmupDuration;
		break;
	case EBFMatchPhase::InProgress:
		PhaseTimeRemaining = MatchDuration;
		if (ABFFrontlineManager* Frontline = ABFFrontlineManager::Get(GetWorld()))
		{
			Frontline->InitializeFrontline();
		}
		break;
	case EBFMatchPhase::PostMatch:
		PhaseTimeRemaining = PostMatchDuration;
		break;
	}

	GS->SetMatchTimeRemaining(PhaseTimeRemaining);
	BF_LOG(LogBrokenFront, Log, TEXT("Match phase -> %d (%.0fs)"), static_cast<int32>(Phase), PhaseTimeRemaining);
}

void UBFMatchManager::Tick(float DeltaTime)
{
	if (!bTickEnabled)
	{
		return;
	}

	ABFGameState* GS = GetBFGameState();
	if (!GS)
	{
		return;
	}

	const EBFMatchPhase Phase = GS->GetMatchPhase();

	if (Phase == EBFMatchPhase::WaitingForPlayers)
	{
		if (ConnectedPlayers >= MinPlayersToStart)
		{
			EnterPhase(EBFMatchPhase::Warmup);
		}
		return;
	}

	PhaseTimeRemaining = FMath::Max(0.f, PhaseTimeRemaining - DeltaTime);
	GS->SetMatchTimeRemaining(PhaseTimeRemaining);

	if (PhaseTimeRemaining <= 0.f)
	{
		HandleTimeExpired();
	}
}

void UBFMatchManager::HandleTimeExpired()
{
	ABFGameState* GS = GetBFGameState();
	if (!GS)
	{
		return;
	}

	switch (GS->GetMatchPhase())
	{
	case EBFMatchPhase::Warmup:
		EnterPhase(EBFMatchPhase::InProgress);
		break;

	case EBFMatchPhase::InProgress:
	{
		// Time out: whoever is further along the ladder wins; tickets break a tie.
		EBFTeam Winner = EBFTeam::Neutral;
		if (const ABFFrontlineManager* Frontline = ABFFrontlineManager::Get(GetWorld()))
		{
			const int32 Advantage = Frontline->GetSectorAdvantage();
			if (Advantage > 0)      { Winner = EBFTeam::Ashguard; }
			else if (Advantage < 0) { Winner = EBFTeam::Ironclad; }
		}

		if (Winner == EBFTeam::Neutral)
		{
			const float IroncladTickets = GS->GetTickets(EBFTeam::Ironclad);
			const float AshguardTickets = GS->GetTickets(EBFTeam::Ashguard);
			if (!FMath::IsNearlyEqual(IroncladTickets, AshguardTickets, 1.f))
			{
				Winner = IroncladTickets > AshguardTickets ? EBFTeam::Ironclad : EBFTeam::Ashguard;
			}
		}

		EndMatch(Winner, TEXT("TimeExpired"));
		break;
	}

	case EBFMatchPhase::PostMatch:
		// Restart the same map. A real deployment would pull the next entry from a rotation.
		if (UWorld* World = GetWorld())
		{
			World->ServerTravel(World->GetLocalURL(), false);
		}
		break;

	default:
		break;
	}
}

void UBFMatchManager::ForceStartMatch()
{
	EnterPhase(EBFMatchPhase::InProgress);
}

void UBFMatchManager::EndMatch(EBFTeam Winner, FName Reason)
{
	ABFGameState* GS = GetBFGameState();
	if (!GS || GS->GetMatchPhase() == EBFMatchPhase::PostMatch)
	{
		return;
	}

	BF_LOG(LogBrokenFront, Log, TEXT("Match over: %s"), *Reason.ToString());

	AwardEndOfMatchProgression(Winner);
	EnterPhase(EBFMatchPhase::PostMatch);
}

void UBFMatchManager::AwardEndOfMatchProgression(EBFTeam Winner)
{
	UWorld* World = GetWorld();
	ABFGameState* GS = GetBFGameState();
	if (!World || !GS)
	{
		return;
	}

	for (FConstPlayerControllerIterator It = World->GetPlayerControllerIterator(); It; ++It)
	{
		APlayerController* PC = It->Get();
		ABFPlayerState* PS = PC ? PC->GetPlayerState<ABFPlayerState>() : nullptr;
		if (!PS)
		{
			continue;
		}

		const bool bWon = (PS->GetTeam() == Winner);
		const int32 BaseXP = PS->GetMatchXP();
		const int32 TotalXP = BaseXP + (bWon ? 1500 : 500);

		PS->AddScore(bWon ? 1500 : 500);

		// Persist for local players; a dedicated server would post this to a backend.
		if (PC->IsLocalController())
		{
			if (UBFGameInstance* GI = Cast<UBFGameInstance>(World->GetGameInstance()))
			{
				GI->CommitMatchResults(PS->GetMatchRecord(), TotalXP, bWon);
			}
		}
	}
}

void UBFMatchManager::NotifyPlayerJoined()
{
	++ConnectedPlayers;
}

void UBFMatchManager::NotifyPlayerLeft()
{
	ConnectedPlayers = FMath::Max(0, ConnectedPlayers - 1);
}
