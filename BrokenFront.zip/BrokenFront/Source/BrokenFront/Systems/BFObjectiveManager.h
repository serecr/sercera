#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Core/BFTypes.h"
#include "BFObjectiveManager.generated.h"

class ABFObjective;
class ABFFrontlineManager;
class ABFSector;

/**
 * Keeps the task list honest: whenever the frontline moves, objectives attached
 * to dead ground are switched off and the ones that matter now are switched on.
 * Attackers get capture/destroy work, defenders get defend/hold work.
 */
UCLASS()
class BROKENFRONT_API UBFObjectiveManager : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	static UBFObjectiveManager* Get(const UWorld* World);

	virtual void OnWorldBeginPlay(UWorld& InWorld) override;

	/** Server: recompute which objectives are live. Called by the frontline manager. */
	UFUNCTION(BlueprintCallable, Category = "Objectives")
	void RebuildObjectivesForFrontline(ABFFrontlineManager* Frontline);

	UFUNCTION(BlueprintPure, Category = "Objectives")
	TArray<ABFObjective*> GetObjectivesInSector(const ABFSector* Sector) const;

	/** Commander tool: force one assignable objective to the top of the team's list. */
	UFUNCTION(BlueprintCallable, Category = "Objectives")
	bool AssignCommanderObjective(EBFTeam Team, ABFObjective* Objective);

private:
	UPROPERTY() TArray<TObjectPtr<ABFObjective>> AllObjectives;

	void GatherObjectives();
	void ActivateBestObjectiveOfType(ABFSector* Sector, EBFObjectiveType Type, EBFTeam Team, TSet<ABFObjective*>& OutActivated);
};
