#include "Systems/BFRadioComponent.h"

#include "Characters/BFCharacter.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerController.h"
#include "Gameplay/BFPlayerState.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"
#include "Sound/SoundBase.h"
#include "Systems/BFAudioManager.h"

UBFRadioComponent::UBFRadioComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
	SetIsReplicatedByDefault(true);
}

void UBFRadioComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
}

const FBFRadioLine* UBFRadioComponent::FindLine(EBFRadioCommand Command) const
{
	return RadioLines.FindByPredicate([Command](const FBFRadioLine& Line) { return Line.Command == Command; });
}

FText UBFRadioComponent::GetSubtitleFor(EBFRadioCommand Command) const
{
	if (const FBFRadioLine* Line = FindLine(Command))
	{
		if (!Line->SubtitleText.IsEmpty())
		{
			return Line->SubtitleText;
		}
	}

	// Fallback to the enum display names so subtitles work before audio is authored.
	switch (Command)
	{
	case EBFRadioCommand::EnemySpotted: return NSLOCTEXT("BrokenFront", "RadioEnemy", "Enemy spotted");
	case EBFRadioCommand::NeedMedic:    return NSLOCTEXT("BrokenFront", "RadioMedic", "Need medic");
	case EBFRadioCommand::DefendSector: return NSLOCTEXT("BrokenFront", "RadioDefend", "Defend sector");
	case EBFRadioCommand::Attack:       return NSLOCTEXT("BrokenFront", "RadioAttack", "Attack");
	case EBFRadioCommand::FallBack:     return NSLOCTEXT("BrokenFront", "RadioFallBack", "Fall back");
	case EBFRadioCommand::NeedSupplies: return NSLOCTEXT("BrokenFront", "RadioSupplies", "Need supplies");
	default: return FText::GetEmpty();
	}
}

void UBFRadioComponent::SendCommand(EBFRadioCommand Command, EBFRadioChannel Channel)
{
	const UWorld* World = GetWorld();
	if (!World)
	{
		return;
	}

	const float Now = World->GetTimeSeconds();
	if (Now - LastSendTime < CommandCooldown)
	{
		return;
	}
	LastSendTime = Now;

	if (GetOwner() && GetOwner()->HasAuthority())
	{
		ServerSendCommand_Implementation(Command, Channel);
	}
	else
	{
		ServerSendCommand(Command, Channel);
	}
}

bool UBFRadioComponent::ServerSendCommand_Validate(EBFRadioCommand /*Command*/, EBFRadioChannel /*Channel*/)
{
	return true;
}

void UBFRadioComponent::ServerSendCommand_Implementation(EBFRadioCommand Command, EBFRadioChannel Channel)
{
	ABFCharacter* Sender = Cast<ABFCharacter>(GetOwner());
	if (!Sender)
	{
		return;
	}

	// Server-side rate limit as well: the client cooldown is only a nicety.
	const float Now = GetWorld()->GetTimeSeconds();
	if (Now - LastSendTime < CommandCooldown * 0.8f && Sender->GetNetMode() == NM_Client)
	{
		return;
	}
	LastSendTime = Now;

	const ABFPlayerState* SenderPS = Sender->GetPlayerState<ABFPlayerState>();
	const FString SenderName = SenderPS ? SenderPS->GetPlayerName() : TEXT("Soldier");
	const FVector Location = Sender->GetActorLocation();

	if (Channel == EBFRadioChannel::Local)
	{
		// A shout is a world event. Everyone close enough hears it, friend or foe.
		MulticastLocalVoice(Command, SenderName, Location);
		return;
	}

	const EBFTeam SenderTeam = Sender->GetTeam();
	const int32 SenderSquad = SenderPS ? SenderPS->GetSquadId() : INDEX_NONE;

	for (FConstPlayerControllerIterator It = GetWorld()->GetPlayerControllerIterator(); It; ++It)
	{
		APlayerController* PC = It->Get();
		const ABFPlayerState* PS = PC ? PC->GetPlayerState<ABFPlayerState>() : nullptr;
		if (!PS || PS->GetTeam() != SenderTeam)
		{
			continue;
		}

		if (Channel == EBFRadioChannel::Squad && PS->GetSquadId() != SenderSquad)
		{
			continue;
		}

		if (ABFCharacter* Listener = Cast<ABFCharacter>(PC->GetPawn()))
		{
			if (UBFRadioComponent* ListenerRadio = Listener->GetRadio())
			{
				ListenerRadio->ClientReceiveCommand(Command, Channel, SenderName, Location);
				continue;
			}
		}

		// Dead or spectating: still deliver to this component so the HUD log updates.
		ClientReceiveCommand(Command, Channel, SenderName, Location);
	}
}

void UBFRadioComponent::ClientReceiveCommand_Implementation(EBFRadioCommand Command, EBFRadioChannel Channel, const FString& SenderName, FVector_NetQuantize WorldLocation)
{
	PlayLine(Command, Channel, WorldLocation);
	OnRadioReceived.Broadcast(Command, Channel, SenderName, WorldLocation);
}

void UBFRadioComponent::MulticastLocalVoice_Implementation(EBFRadioCommand Command, const FString& SenderName, FVector_NetQuantize WorldLocation)
{
	if (GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	// Range check on the receiving end: attenuation handles the falloff, this just
	// avoids spawning sounds nobody can hear.
	const APlayerController* PC = GetWorld()->GetFirstPlayerController();
	const APawn* Listener = PC ? PC->GetPawn() : nullptr;
	if (Listener && FVector::DistSquared(Listener->GetActorLocation(), WorldLocation) > FMath::Square(LocalVoiceRange))
	{
		return;
	}

	PlayLine(Command, EBFRadioChannel::Local, WorldLocation);
	OnRadioReceived.Broadcast(Command, EBFRadioChannel::Local, SenderName, WorldLocation);
}

void UBFRadioComponent::PlayLine(EBFRadioCommand Command, EBFRadioChannel Channel, const FVector& Location)
{
	if (GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	const FBFRadioLine* Line = FindLine(Command);
	if (!Line)
	{
		return;
	}

	if (Channel == EBFRadioChannel::Local)
	{
		if (USoundBase* Sound = Line->LocalVoice.LoadSynchronous())
		{
			ABFAudioManager::PlaySpatialised(GetWorld(), Sound, Location, 1.f);
		}
		return;
	}

	// Radio traffic is in your ear, not in the world.
	if (USoundBase* Sound = Line->RadioVoice.LoadSynchronous())
	{
		UGameplayStatics::PlaySound2D(this, Sound, Channel == EBFRadioChannel::Squad ? 1.f : 0.8f);
	}
}
