#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFCraterManager.generated.h"

class UStaticMesh;
class UHierarchicalInstancedStaticMeshComponent;
class UNiagaraSystem;

/** One live crater. */
USTRUCT()
struct FBFCraterEntry
{
	GENERATED_BODY()

	UPROPERTY() FVector Location = FVector::ZeroVector;
	UPROPERTY() EBFCraterSize Size = EBFCraterSize::Small;
	UPROPERTY() float RemainingLifetime = 0.f;
	UPROPERTY() int32 InstanceIndex = INDEX_NONE;
};

/**
 * Explosions leave craters that persist, provide real cover, and eventually fade.
 *
 * Implementation choice: instanced crater meshes with collision instead of runtime
 * landscape deformation. It replicates cheaply (a small array), costs one draw call
 * per size bucket thanks to HISM, and is the only approach that holds up with 64
 * players shelling the same field. Landscape sculpting at runtime is not
 * network-friendly and tanks performance on a World Partition map.
 */
UCLASS()
class BROKENFRONT_API ABFCraterManager : public AActor
{
	GENERATED_BODY()

public:
	ABFCraterManager();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	static ABFCraterManager* Get(const UWorld* World);

	/** Server: carve a crater. Snaps to the ground and merges with nearby craters. */
	UFUNCTION(BlueprintCallable, Category = "Craters")
	void SpawnCrater(const FVector& Location, EBFCraterSize Size);

	UFUNCTION(BlueprintPure, Category = "Craters") int32 GetCraterCount() const { return Craters.Num(); }

	/** True if a crater is deep enough at this spot to count as cover. */
	UFUNCTION(BlueprintPure, Category = "Craters")
	bool IsInCrater(const FVector& Location, float Tolerance = 250.f) const;

protected:
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> SmallCraters;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> MediumCraters;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UHierarchicalInstancedStaticMeshComponent> LargeCraters;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<UStaticMesh> SmallCraterMesh;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<UStaticMesh> MediumCraterMesh;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<UStaticMesh> LargeCraterMesh;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<UNiagaraSystem> DirtBurstEffect;

	/** Seconds a crater stays before fading. Large craters last longest. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") float SmallLifetime = 180.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") float MediumLifetime = 420.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") float LargeLifetime = 900.f;

	/** Hard cap. Oldest craters are recycled first so memory and draw cost stay flat. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "16"))
	int32 MaxCraters = 220;

	/** Two blasts inside this radius merge into one larger crater instead of stacking. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config") float MergeRadius = 320.f;

	UPROPERTY(ReplicatedUsing = OnRep_Craters)
	TArray<FBFCraterEntry> Craters;

	UFUNCTION() void OnRep_Craters();

private:
	/** Client-side mirror so we only add/remove the instances that actually changed. */
	TArray<FVector> RenderedCraterLocations;

	UHierarchicalInstancedStaticMeshComponent* GetComponentForSize(EBFCraterSize Size) const;
	float GetLifetimeForSize(EBFCraterSize Size) const;
	float GetRadiusForSize(EBFCraterSize Size) const;
	bool ProjectToGround(const FVector& In, FVector& OutLocation, FVector& OutNormal) const;
	void RebuildInstances();
};
