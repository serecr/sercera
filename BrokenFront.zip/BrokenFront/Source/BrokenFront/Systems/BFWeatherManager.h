#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFWeatherManager.generated.h"

class UDirectionalLightComponent;
class USkyLightComponent;
class USkyAtmosphereComponent;
class UVolumetricCloudComponent;
class UExponentialHeightFogComponent;
class UNiagaraComponent;
class UNiagaraSystem;
class UAudioComponent;
class USoundBase;
class UDataTable;
class UMaterialParameterCollection;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FBFWeatherChanged, EBFWeatherState, NewState);

/**
 * Drives weather and the day/night cycle from the server, blending smoothly on
 * every client. One actor per level; it owns the sky, the sun, the fog, the rain
 * particle system and the ambience bed.
 *
 * Transitions are authored in a DataTable of FBFWeatherPreset rows, so a designer
 * decides that Rain can become HeavyRain or Fog but never jump straight to Clear.
 */
UCLASS()
class BROKENFRONT_API ABFWeatherManager : public AActor
{
	GENERATED_BODY()

public:
	ABFWeatherManager();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	static ABFWeatherManager* Get(const UWorld* World);

	UPROPERTY(BlueprintAssignable, Category = "Weather") FBFWeatherChanged OnWeatherChanged;

	UFUNCTION(BlueprintPure, Category = "Weather") const FBFWeatherSnapshot& GetSnapshot() const { return Snapshot; }
	UFUNCTION(BlueprintPure, Category = "Weather") EBFWeatherState GetWeatherState() const { return TargetState; }
	UFUNCTION(BlueprintPure, Category = "Weather") EBFDayPhase GetDayPhase() const { return Snapshot.DayPhase; }
	UFUNCTION(BlueprintPure, Category = "Weather") float GetTimeOfDay() const { return TimeOfDay; }
	UFUNCTION(BlueprintPure, Category = "Weather") bool IsNight() const { return Snapshot.DayPhase == EBFDayPhase::Night; }
	UFUNCTION(BlueprintPure, Category = "Weather") float GetCurrentMudRate() const;

	/** Effective visibility multiplier: night and fog stack. Used by audio and spotting. */
	UFUNCTION(BlueprintPure, Category = "Weather") float GetVisibilityMultiplier() const;

	/** Server: force a specific state, used by the training map and debug commands. */
	UFUNCTION(BlueprintCallable, Category = "Weather", meta = (CallInEditor = "true"))
	void SetWeatherState(EBFWeatherState NewState, float TransitionSeconds = 25.f);

	UFUNCTION(BlueprintCallable, Category = "Weather", meta = (CallInEditor = "true"))
	void SetTimeOfDay(float NewHour);

protected:
	// ---------- Scene components ----------
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UDirectionalLightComponent> SunLight;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UDirectionalLightComponent> MoonLight;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<USkyLightComponent> SkyLight;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<USkyAtmosphereComponent> SkyAtmosphere;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UVolumetricCloudComponent> VolumetricClouds;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UExponentialHeightFogComponent> HeightFog;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UNiagaraComponent> RainEffect;
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components") TObjectPtr<UAudioComponent> AmbienceAudio;

	// ---------- Config ----------
	/** Rows of FBFWeatherPreset. Without it the manager falls back to built-in defaults. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") TObjectPtr<UDataTable> WeatherPresetTable;

	/** Material parameter collection carrying WetAmount / RainAmount / SnowAmount to landscape materials. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") TObjectPtr<UMaterialParameterCollection> GlobalWeatherParameters;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<UNiagaraSystem> RainSystem;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<USoundBase> RainAmbience;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<USoundBase> WindAmbience;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") TSoftObjectPtr<USoundBase> ThunderSound;

	/** Real seconds per in-game hour. 120 gives a 48 minute full day. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config", meta = (ClampMin = "1.0"))
	float SecondsPerGameHour = 120.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") bool bAdvanceTime = true;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") bool bAutoChangeWeather = true;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") float StartingHour = 9.f;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config") EBFWeatherState StartingWeather = EBFWeatherState::Cloudy;

	/** Sun brightness at noon, and the moon's at midnight. */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Lighting") float MaxSunIntensity = 8.f;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Lighting") float MoonIntensity = 0.35f;
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Lighting") FLinearColor DaySunColour = FLinearColor(1.f, 0.96f, 0.9f);
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Lighting") FLinearColor DawnSunColour = FLinearColor(1.f, 0.62f, 0.38f);
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Lighting") FLinearColor DuskSunColour = FLinearColor(1.f, 0.48f, 0.3f);
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Lighting") FLinearColor NightColour = FLinearColor(0.32f, 0.42f, 0.7f);

	// ---------- Replicated ----------
	UPROPERTY(ReplicatedUsing = OnRep_TargetState, BlueprintReadOnly, Category = "State")
	EBFWeatherState TargetState = EBFWeatherState::Cloudy;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float TimeOfDay = 9.f;

	/** Seconds remaining in the current blend; replicated so late joiners match. */
	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float BlendRemaining = 0.f;

	UFUNCTION() void OnRep_TargetState();

private:
	FBFWeatherSnapshot Snapshot;
	FBFWeatherPreset CurrentPreset;
	FBFWeatherPreset TargetPreset;
	float BlendDuration = 25.f;
	float StateTimeRemaining = 0.f;
	float ThunderCooldown = 0.f;

	void LoadPreset(EBFWeatherState State, FBFWeatherPreset& OutPreset) const;
	void RollNextWeather();
	void AdvanceTime(float DeltaSeconds);
	void UpdateBlend(float DeltaSeconds);
	void ApplyToScene();
	void UpdateDayPhase();
	void MaybePlayThunder(float DeltaSeconds);
};
