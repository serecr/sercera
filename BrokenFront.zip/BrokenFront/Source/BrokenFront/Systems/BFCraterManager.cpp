#include "Systems/BFCraterManager.h"

#include "Components/HierarchicalInstancedStaticMeshComponent.h"
#include "Core/BFLog.h"
#include "Engine/StaticMesh.h"
#include "EngineUtils.h"
#include "Net/UnrealNetwork.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"

ABFCraterManager::ABFCraterManager()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 1.f; // lifetimes are measured in minutes
	bReplicates = true;
	SetReplicateMovement(false);
	bAlwaysRelevant = true;
	NetUpdateFrequency = 2.f;

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

	auto MakeHISM = [this, Root](const FName& Name) -> UHierarchicalInstancedStaticMeshComponent*
	{
		UHierarchicalInstancedStaticMeshComponent* Comp =
			CreateDefaultSubobject<UHierarchicalInstancedStaticMeshComponent>(Name);
		Comp->SetupAttachment(Root);
		Comp->SetMobility(EComponentMobility::Static);
		Comp->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		Comp->SetCollisionProfileName(TEXT("BlockAll"));
		Comp->bReceivesDecals = true;
		// Craters are Nanite-friendly static geometry.
		Comp->SetCullDistances(0, 25000);
		return Comp;
	};

	SmallCraters = MakeHISM(TEXT("SmallCraters"));
	MediumCraters = MakeHISM(TEXT("MediumCraters"));
	LargeCraters = MakeHISM(TEXT("LargeCraters"));
}

ABFCraterManager* ABFCraterManager::Get(const UWorld* World)
{
	if (!World)
	{
		return nullptr;
	}
	for (TActorIterator<ABFCraterManager> It(World); It; ++It)
	{
		return *It;
	}
	return nullptr;
}

void ABFCraterManager::BeginPlay()
{
	Super::BeginPlay();

	if (UStaticMesh* Mesh = SmallCraterMesh.LoadSynchronous())  { SmallCraters->SetStaticMesh(Mesh); }
	if (UStaticMesh* Mesh = MediumCraterMesh.LoadSynchronous()) { MediumCraters->SetStaticMesh(Mesh); }
	if (UStaticMesh* Mesh = LargeCraterMesh.LoadSynchronous())  { LargeCraters->SetStaticMesh(Mesh); }
}

void ABFCraterManager::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFCraterManager, Craters);
}

UHierarchicalInstancedStaticMeshComponent* ABFCraterManager::GetComponentForSize(EBFCraterSize Size) const
{
	switch (Size)
	{
	case EBFCraterSize::Large:  return LargeCraters;
	case EBFCraterSize::Medium: return MediumCraters;
	default:                    return SmallCraters;
	}
}

float ABFCraterManager::GetLifetimeForSize(EBFCraterSize Size) const
{
	switch (Size)
	{
	case EBFCraterSize::Large:  return LargeLifetime;
	case EBFCraterSize::Medium: return MediumLifetime;
	default:                    return SmallLifetime;
	}
}

float ABFCraterManager::GetRadiusForSize(EBFCraterSize Size) const
{
	switch (Size)
	{
	case EBFCraterSize::Large:  return 520.f;
	case EBFCraterSize::Medium: return 330.f;
	default:                    return 180.f;
	}
}

bool ABFCraterManager::ProjectToGround(const FVector& In, FVector& OutLocation, FVector& OutNormal) const
{
	const UWorld* World = GetWorld();
	if (!World)
	{
		return false;
	}

	const FVector Start = In + FVector(0.f, 0.f, 500.f);
	const FVector End = In - FVector(0.f, 0.f, 1500.f);

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFCraterProject), false);
	FHitResult Hit;
	if (World->LineTraceSingleByChannel(Hit, Start, End, ECC_WorldStatic, Params))
	{
		OutLocation = Hit.ImpactPoint;
		OutNormal = Hit.ImpactNormal;
		return true;
	}

	return false;
}

void ABFCraterManager::SpawnCrater(const FVector& Location, EBFCraterSize Size)
{
	if (!HasAuthority())
	{
		return;
	}

	FVector Ground;
	FVector Normal;
	if (!ProjectToGround(Location, Ground, Normal))
	{
		return; // detonated in mid-air or inside a bunker: no terrain to crater
	}

	// Merge with an existing crater rather than stacking meshes on top of each other.
	for (FBFCraterEntry& Existing : Craters)
	{
		if (FVector::DistSquared(Existing.Location, Ground) < FMath::Square(MergeRadius))
		{
			// Upgrade the existing crater one step and refresh its lifetime.
			if (static_cast<uint8>(Size) > static_cast<uint8>(Existing.Size))
			{
				Existing.Size = Size;
			}
			else if (Existing.Size != EBFCraterSize::Large)
			{
				Existing.Size = static_cast<EBFCraterSize>(static_cast<uint8>(Existing.Size) + 1);
			}
			Existing.RemainingLifetime = GetLifetimeForSize(Existing.Size);
			RebuildInstances();
			return;
		}
	}

	// Recycle the oldest crater when at capacity: flat cost, no leak.
	if (Craters.Num() >= MaxCraters)
	{
		int32 OldestIndex = 0;
		float Lowest = TNumericLimits<float>::Max();
		for (int32 Index = 0; Index < Craters.Num(); ++Index)
		{
			if (Craters[Index].RemainingLifetime < Lowest)
			{
				Lowest = Craters[Index].RemainingLifetime;
				OldestIndex = Index;
			}
		}
		Craters.RemoveAt(OldestIndex);
	}

	FBFCraterEntry Entry;
	Entry.Location = Ground;
	Entry.Size = Size;
	Entry.RemainingLifetime = GetLifetimeForSize(Size);
	Craters.Add(Entry);

	RebuildInstances();
}

void ABFCraterManager::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!HasAuthority())
	{
		return;
	}

	bool bChanged = false;
	for (int32 Index = Craters.Num() - 1; Index >= 0; --Index)
	{
		Craters[Index].RemainingLifetime -= DeltaSeconds;
		if (Craters[Index].RemainingLifetime <= 0.f)
		{
			Craters.RemoveAt(Index);
			bChanged = true;
		}
	}

	if (bChanged)
	{
		RebuildInstances();
	}
}

void ABFCraterManager::OnRep_Craters()
{
	RebuildInstances();
}

void ABFCraterManager::RebuildInstances()
{
	// Rebuild is O(n) over a capped array and only runs on add/remove, not per frame.
	SmallCraters->ClearInstances();
	MediumCraters->ClearInstances();
	LargeCraters->ClearInstances();

	TArray<FVector> NewLocations;
	NewLocations.Reserve(Craters.Num());

	for (FBFCraterEntry& Entry : Craters)
	{
		UHierarchicalInstancedStaticMeshComponent* Comp = GetComponentForSize(Entry.Size);
		if (!Comp || !Comp->GetStaticMesh())
		{
			continue;
		}

		// Random yaw and slight scale variation so a shelled field never looks tiled.
		const float Yaw = FMath::Fmod(Entry.Location.X + Entry.Location.Y, 360.f);
		const float Scale = 0.85f + FMath::Fmod(FMath::Abs(Entry.Location.X), 30.f) / 100.f;

		const FTransform Transform(FRotator(0.f, Yaw, 0.f), Entry.Location, FVector(Scale));
		Entry.InstanceIndex = Comp->AddInstance(Transform, true);

		NewLocations.Add(Entry.Location);

		// Dirt burst on newly appearing craters only.
		if (!RenderedCraterLocations.Contains(Entry.Location) && GetNetMode() != NM_DedicatedServer)
		{
			if (UNiagaraSystem* Burst = DirtBurstEffect.LoadSynchronous())
			{
				UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Burst, Entry.Location, FRotator::ZeroRotator);
			}
		}
	}

	RenderedCraterLocations = MoveTemp(NewLocations);
}

bool ABFCraterManager::IsInCrater(const FVector& Location, float Tolerance) const
{
	for (const FBFCraterEntry& Entry : Craters)
	{
		const float Radius = GetRadiusForSize(Entry.Size) + Tolerance;
		if (FVector::DistSquaredXY(Entry.Location, Location) < FMath::Square(Radius))
		{
			// Only counts as cover if you are actually down in it.
			return Location.Z < Entry.Location.Z + 140.f;
		}
	}
	return false;
}
