#include "Systems/BFDestructibleActor.h"

#include "Characters/BFCharacter.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Core/BFLog.h"
#include "GameFramework/Character.h"
#include "GeometryCollection/GeometryCollectionComponent.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"
#include "Sound/SoundBase.h"
#include "Systems/BFAudioManager.h"
#include "TimerManager.h"

ABFDestructibleActor::ABFDestructibleActor()
{
	PrimaryActorTick.bCanEverTick = false;
	bReplicates = true;
	SetReplicateMovement(false);
	NetUpdateFrequency = 4.f;

	IntactMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("IntactMesh"));
	IntactMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	IntactMesh->SetCollisionObjectType(ECC_Destructible);
	IntactMesh->SetCollisionResponseToAllChannels(ECR_Block);
	IntactMesh->SetMobility(EComponentMobility::Static);
	SetRootComponent(IntactMesh);

	DamagedMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("DamagedMesh"));
	DamagedMesh->SetupAttachment(IntactMesh);
	DamagedMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	DamagedMesh->SetVisibility(false);
	DamagedMesh->SetMobility(EComponentMobility::Static);

	RubbleCollection = CreateDefaultSubobject<UGeometryCollectionComponent>(TEXT("RubbleCollection"));
	RubbleCollection->SetupAttachment(IntactMesh);
	RubbleCollection->SetVisibility(false);
	RubbleCollection->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	RubbleCollection->SetSimulatePhysics(false);
	RubbleCollection->SetNotifyRigidBodyCollision(false);

	BlockedRouteVolume = CreateDefaultSubobject<UBoxComponent>(TEXT("BlockedRouteVolume"));
	BlockedRouteVolume->SetupAttachment(IntactMesh);
	BlockedRouteVolume->SetBoxExtent(FVector(80.f, 80.f, 120.f));
	BlockedRouteVolume->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
	BlockedRouteVolume->SetCollisionObjectType(ECC_WorldStatic);
	BlockedRouteVolume->SetCollisionResponseToAllChannels(ECR_Ignore);
	BlockedRouteVolume->SetCollisionResponseToChannel(ECC_Pawn, ECR_Block);
	BlockedRouteVolume->SetHiddenInGame(true);
}

void ABFDestructibleActor::BeginPlay()
{
	Super::BeginPlay();

	if (HasAuthority())
	{
		Integrity = MaxIntegrity;
		DamageStage = 0;
	}

	ApplyStage(DamageStage, false);
}

void ABFDestructibleActor::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFDestructibleActor, Integrity);
	DOREPLIFETIME(ABFDestructibleActor, DamageStage);
	DOREPLIFETIME(ABFDestructibleActor, OwningTeam);
}

void ABFDestructibleActor::SetOwningTeam(EBFTeam NewTeam)
{
	if (HasAuthority())
	{
		OwningTeam = NewTeam;
	}
}

void ABFDestructibleActor::ApplyStructuralDamage(float Damage, const FVector& ImpactPoint, const FVector& Direction, ABFCharacter* Instigator)
{
	if (!HasAuthority() || IsDestroyed() || Damage <= 0.f)
	{
		return;
	}

	Integrity = FMath::Max(0.f, Integrity - Damage * BulletDamageScale);
	MulticastImpact(ImpactPoint, Direction.GetSafeNormal());

	const float Percent = GetIntegrityPercent();
	int32 NewStage = DamageStage;

	if (Percent <= 0.f)
	{
		NewStage = 2;
	}
	else if (Percent <= DamagedThreshold)
	{
		NewStage = 1;
	}

	if (NewStage != DamageStage)
	{
		DamageStage = NewStage;
		ApplyStage(DamageStage, true);

		if (DamageStage >= 2)
		{
			if (Instigator)
			{
				if (ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>())
				{
					GS->AddTeamScore(Instigator->GetTeam(), DestructionScore);
				}
				if (ABFPlayerState* PS = Instigator->GetPlayerState<ABFPlayerState>())
				{
					PS->AddScore(DestructionScore / 3);
				}
			}

			OnDestroyed.Broadcast();
			BF_LOG(LogBFCombat, Verbose, TEXT("%s destroyed, route opened."), *GetName());
		}

		OnStageChanged.Broadcast(DamageStage);
	}
}

float ABFDestructibleActor::Repair(float Amount, ABFCharacter* Engineer)
{
	if (!HasAuthority() || !bRepairable || Amount <= 0.f)
	{
		return 0.f;
	}

	// Rubble cannot be rebuilt in place; the Engineer has to place a new piece.
	if (IsDestroyed())
	{
		return 0.f;
	}

	const float Before = Integrity;
	Integrity = FMath::Min(MaxIntegrity, Integrity + Amount);
	const float Restored = Integrity - Before;

	const float Percent = GetIntegrityPercent();
	const int32 NewStage = (Percent > DamagedThreshold) ? 0 : 1;
	if (NewStage != DamageStage)
	{
		DamageStage = NewStage;
		ApplyStage(DamageStage, false);
		OnStageChanged.Broadcast(DamageStage);
	}

	if (Restored > 0.f && Engineer)
	{
		if (ABFPlayerState* PS = Engineer->GetPlayerState<ABFPlayerState>())
		{
			PS->AddScore(FMath::RoundToInt(Restored * 0.05f));
		}
	}

	return Restored;
}

void ABFDestructibleActor::RepairFully()
{
	if (!HasAuthority())
	{
		return;
	}

	Integrity = MaxIntegrity;
	if (DamageStage != 0)
	{
		DamageStage = 0;
		ApplyStage(0, false);
		OnStageChanged.Broadcast(0);
	}
}

void ABFDestructibleActor::ApplyStage(int32 Stage, bool bPlayEffects)
{
	switch (Stage)
	{
	case 0:
		IntactMesh->SetVisibility(true);
		IntactMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		DamagedMesh->SetVisibility(false);
		DamagedMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		RubbleCollection->SetVisibility(false);
		RubbleCollection->SetSimulatePhysics(false);
		RubbleCollection->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		BlockedRouteVolume->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		break;

	case 1:
		// Damaged: swap to the holed mesh. Still blocks movement, but you can shoot through.
		if (DamagedMesh->GetStaticMesh())
		{
			IntactMesh->SetVisibility(false);
			DamagedMesh->SetVisibility(true);
			DamagedMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
			DamagedMesh->SetCollisionResponseToChannel(BF_TRACE_WEAPON, ECR_Overlap);
			IntactMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		}
		BlockedRouteVolume->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		break;

	default:
		// Destroyed: release the fracture, drop all blocking collision, open the route.
		IntactMesh->SetVisibility(false);
		IntactMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		DamagedMesh->SetVisibility(false);
		DamagedMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
		BlockedRouteVolume->SetCollisionEnabled(ECollisionEnabled::NoCollision);

		if (RubbleCollection->GetRestCollection())
		{
			RubbleCollection->SetVisibility(true);
			RubbleCollection->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
			RubbleCollection->SetSimulatePhysics(true);
			// Physics debris: authoritative on the server, visually simulated on clients.
			RubbleCollection->SetNotifyRigidBodyCollision(true);
		}

		if (RubbleLifetime > 0.f)
		{
			GetWorldTimerManager().SetTimer(RubbleCleanupTimer, this, &ABFDestructibleActor::CleanUpRubble, RubbleLifetime, false);
		}
		break;
	}

	if (!bPlayEffects || GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	if (Stage >= 2)
	{
		if (UNiagaraSystem* Effect = DestructionEffect.LoadSynchronous())
		{
			UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Effect, GetActorLocation(), GetActorRotation());
		}
		if (USoundBase* Sound = DestructionSound.LoadSynchronous())
		{
			ABFAudioManager::PlaySpatialised(GetWorld(), Sound, GetActorLocation(), 1.f);
		}
	}
	else if (Stage == 1)
	{
		if (USoundBase* Sound = DamageSound.LoadSynchronous())
		{
			ABFAudioManager::PlaySpatialised(GetWorld(), Sound, GetActorLocation(), 0.8f);
		}
	}
}

void ABFDestructibleActor::CleanUpRubble()
{
	// Settle the debris into static geometry so a long match does not accumulate
	// thousands of simulating bodies.
	if (RubbleCollection)
	{
		RubbleCollection->SetSimulatePhysics(false);
		RubbleCollection->SetNotifyRigidBodyCollision(false);
	}
}

void ABFDestructibleActor::MulticastImpact_Implementation(FVector_NetQuantize ImpactPoint, FVector_NetQuantizeNormal Direction)
{
	if (GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	if (UNiagaraSystem* Effect = DamageEffect.LoadSynchronous())
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), Effect, ImpactPoint, (-Direction).Rotation());
	}

	ABFAudioManager::PlaySurfaceImpact(GetWorld(), SurfaceType, ImpactPoint, -Direction);
}

void ABFDestructibleActor::OnRep_DamageStage()
{
	ApplyStage(DamageStage, true);
	OnStageChanged.Broadcast(DamageStage);
}
