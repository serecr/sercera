#include "Systems/BFBuildableDefense.h"

#include "Characters/BFCharacter.h"
#include "Data/BFSoldierClassDataAsset.h"
#include "Gameplay/BFPlayerState.h"
#include "Net/UnrealNetwork.h"
#include "Weapons/BFInventoryComponent.h"

ABFBuildableDefense::ABFBuildableDefense()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.1f;

	// Placed pieces move with the level, never simulate before destruction.
	if (IntactMesh)
	{
		IntactMesh->SetMobility(EComponentMobility::Movable);
	}
	if (DamagedMesh)
	{
		DamagedMesh->SetMobility(EComponentMobility::Movable);
	}
}

void ABFBuildableDefense::BeginPlay()
{
	Super::BeginPlay();

	if (HasAuthority())
	{
		RemainingSupplyUses = SupplyUses;
	}
}

void ABFBuildableDefense::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFBuildableDefense, ConstructionProgress);
	DOREPLIFETIME(ABFBuildableDefense, RemainingSupplyUses);
}

void ABFBuildableDefense::BeginConstruction(EBFTeam Team, ABFCharacter* Builder)
{
	if (!HasAuthority())
	{
		return;
	}

	SetOwningTeam(Team);
	BuilderCharacter = Builder;

	TargetIntegrityAfterBuild = MaxIntegrity;
	ConstructionProgress = 0.f;

	// Starts flimsy: a half-built sandbag wall will not save you.
	Integrity = FMath::Max(1.f, MaxIntegrity * 0.15f);

	if (Builder)
	{
		if (ABFPlayerState* PS = Builder->GetPlayerState<ABFPlayerState>())
		{
			PS->RegisterBuild();
		}
	}
}

void ABFBuildableDefense::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	if (!HasAuthority() || ConstructionProgress >= 1.f)
	{
		return;
	}

	ConstructionProgress = FMath::Clamp(ConstructionProgress + DeltaSeconds / FMath::Max(ConstructionTime, 0.1f), 0.f, 1.f);

	// Integrity ramps with the build so the piece becomes cover progressively.
	if (!IsDestroyed())
	{
		Integrity = FMath::Lerp(MaxIntegrity * 0.15f, TargetIntegrityAfterBuild, ConstructionProgress);
	}

	if (ConstructionProgress >= 1.f)
	{
		Integrity = TargetIntegrityAfterBuild;
	}
}

bool ABFBuildableDefense::CanInteract_Implementation(ABFCharacter* Interactor) const
{
	if (!Interactor)
	{
		return false;
	}

	// Enemy pieces cannot be used or repaired.
	if (OwningTeam != EBFTeam::Neutral && Interactor->GetTeam() != OwningTeam)
	{
		return false;
	}

	if (bSupplyPoint && RemainingSupplyUses > 0 && !IsDestroyed())
	{
		return true;
	}

	const UBFSoldierClassDataAsset* ClassAsset = Interactor->GetSoldierClass();
	const bool bCanRepair = ClassAsset && ClassAsset->bCanBuild;
	return bCanRepair && bRepairable && !IsDestroyed() && GetIntegrityPercent() < 1.f;
}

void ABFBuildableDefense::Interact_Implementation(ABFCharacter* Interactor)
{
	if (!HasAuthority() || !Interactor)
	{
		return;
	}

	// Supply crate: hand out magazines.
	if (bSupplyPoint && RemainingSupplyUses > 0)
	{
		if (UBFInventoryComponent* Inventory = Interactor->GetInventory())
		{
			if (Inventory->ResupplyAmmo(SupplyMagazines))
			{
				--RemainingSupplyUses;
				if (ABFPlayerState* PS = Interactor->GetPlayerState<ABFPlayerState>())
				{
					PS->AddScore(10);
				}
				return;
			}
		}
	}

	// Otherwise an Engineer is repairing it.
	const UBFSoldierClassDataAsset* ClassAsset = Interactor->GetSoldierClass();
	if (ClassAsset && ClassAsset->bCanBuild)
	{
		Repair(MaxIntegrity * 0.25f, Interactor);
	}
}

FText ABFBuildableDefense::GetInteractionPrompt_Implementation(ABFCharacter* Interactor) const
{
	if (bSupplyPoint && RemainingSupplyUses > 0)
	{
		return NSLOCTEXT("BrokenFront", "PromptResupply", "Resupply");
	}

	if (GetIntegrityPercent() < 1.f && bRepairable && !IsDestroyed())
	{
		return NSLOCTEXT("BrokenFront", "PromptRepair", "Repair");
	}

	return FText::GetEmpty();
}
