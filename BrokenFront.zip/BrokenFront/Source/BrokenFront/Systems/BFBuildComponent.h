#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "Core/BFTypes.h"
#include "Systems/BFBuildableDefense.h"
#include "BFBuildComponent.generated.h"

class ABFCharacter;
class UBFSoldierClassDataAsset;
class UStaticMeshComponent;
class UMaterialInterface;

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FBFBuildStateChanged, bool, bPreviewActive, int32, SelectedIndex);

/**
 * Engineer construction. The local client drives a ghost preview and validates
 * placement visually; the server re-validates everything (class, resources,
 * distance, overlap, ground slope) before spawning. Resources come from the
 * team-wide pool on the GameState, so a team genuinely runs out of materials.
 */
UCLASS(ClassGroup = (BrokenFront), meta = (BlueprintSpawnableComponent))
class BROKENFRONT_API UBFBuildComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UBFBuildComponent();

	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	UPROPERTY(BlueprintAssignable, Category = "Build") FBFBuildStateChanged OnBuildStateChanged;

	/** Server: applies class permissions and the personal resource allowance. */
	void ConfigureFromClass(const UBFSoldierClassDataAsset* ClassAsset);

	UFUNCTION(BlueprintCallable, Category = "Build") void ToggleBuildMode();
	UFUNCTION(BlueprintCallable, Category = "Build") void SelectBuildable(int32 Index);
	UFUNCTION(BlueprintCallable, Category = "Build") void CycleBuildable(int32 Direction);
	UFUNCTION(BlueprintCallable, Category = "Build") void RotatePreview(float DeltaYaw);

	/** Local: commits the current preview. Sends the request to the server. */
	UFUNCTION(BlueprintCallable, Category = "Build") void ConfirmPlacement();

	UFUNCTION(BlueprintCallable, Category = "Build") void CancelBuildMode();

	UFUNCTION(BlueprintPure, Category = "Build") bool IsPreviewActive() const { return bPreviewActive; }
	UFUNCTION(BlueprintPure, Category = "Build") bool IsPlacementValid() const { return bPlacementValid; }
	UFUNCTION(BlueprintPure, Category = "Build") int32 GetSelectedIndex() const { return SelectedIndex; }
	UFUNCTION(BlueprintPure, Category = "Build") const TArray<FBFBuildableEntry>& GetCatalogue() const { return Catalogue; }
	UFUNCTION(BlueprintPure, Category = "Build") int32 GetTeamResources() const;

protected:
	/** What this soldier can build. Filled on the character Blueprint. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<FBFBuildableEntry> Catalogue;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float MaxPlacementDistance = 450.f;

	/** Maximum ground slope in degrees a piece may be placed on. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float MaxGroundSlope = 25.f;

	/** Minimum gap between two placed pieces. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float MinSpacing = 140.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TSoftObjectPtr<UMaterialInterface> ValidPreviewMaterial;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TSoftObjectPtr<UMaterialInterface> InvalidPreviewMaterial;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	bool bCanBuild = false;

	UFUNCTION(Server, Reliable, WithValidation)
	void ServerPlaceBuildable(int32 Index, FVector_NetQuantize Location, float Yaw);

private:
	UPROPERTY() TObjectPtr<ABFCharacter> OwnerCharacter;
	UPROPERTY() TObjectPtr<UStaticMeshComponent> PreviewMesh;

	bool bPreviewActive = false;
	bool bPlacementValid = false;
	int32 SelectedIndex = 0;
	float PreviewYaw = 0.f;

	void EnsurePreviewMesh();
	void UpdatePreview();
	bool TraceGroundForPlacement(FVector& OutLocation, FVector& OutNormal) const;
	bool ValidatePlacement(const FVector& Location, const FVector& Normal, int32 Index) const;
};
