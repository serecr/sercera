#pragma once

#include "CoreMinimal.h"
#include "Systems/BFDestructibleActor.h"
#include "Core/BFInteractable.h"
#include "BFBuildableDefense.generated.h"

/** Designer-facing catalogue entry for the build menu. */
USTRUCT(BlueprintType)
struct FBFBuildableEntry
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) FText DisplayName;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSubclassOf<class ABFBuildableDefense> BuildableClass;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) int32 ResourceCost = 25;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<UTexture2D> Icon;
};

/**
 * Anything an Engineer can place: sandbags, wooden barriers, defensive panels,
 * observation posts, supply crates. Inherits the destructible pipeline, so a built
 * wall can be shot down exactly like a level-authored one.
 *
 * A freshly placed piece starts at reduced integrity and "builds up" over a few
 * seconds, which stops players from instantly walling off a doorway mid-firefight.
 */
UCLASS()
class BROKENFRONT_API ABFBuildableDefense : public ABFDestructibleActor, public IBFInteractable
{
	GENERATED_BODY()

public:
	ABFBuildableDefense();

	virtual void BeginPlay() override;
	virtual void Tick(float DeltaSeconds) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

	/** Server: called right after spawning from the build component. */
	void BeginConstruction(EBFTeam Team, class ABFCharacter* Builder);

	UFUNCTION(BlueprintPure, Category = "Build") bool IsUnderConstruction() const { return ConstructionProgress < 1.f; }
	UFUNCTION(BlueprintPure, Category = "Build") float GetConstructionProgress() const { return ConstructionProgress; }
	UFUNCTION(BlueprintPure, Category = "Build") int32 GetResourceCost() const { return ResourceCost; }

	/** True when this piece provides ammo resupply (supply crate). */
	UFUNCTION(BlueprintPure, Category = "Build") bool IsSupplyPoint() const { return bSupplyPoint; }

	/** True when this piece grants a spotting bonus (observation post). */
	UFUNCTION(BlueprintPure, Category = "Build") bool IsObservationPost() const { return bObservationPost; }

	// IBFInteractable
	virtual void Interact_Implementation(class ABFCharacter* Interactor) override;
	virtual FText GetInteractionPrompt_Implementation(class ABFCharacter* Interactor) const override;
	virtual bool CanInteract_Implementation(class ABFCharacter* Interactor) const override;

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Build", meta = (ClampMin = "0"))
	int32 ResourceCost = 25;

	/** Seconds to finish building. Sandbags are fast, observation posts are slow. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Build", meta = (ClampMin = "0.1"))
	float ConstructionTime = 4.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Build")
	bool bSupplyPoint = false;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Build")
	bool bObservationPost = false;

	/** Magazines handed out per interaction, for supply crates. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Build")
	int32 SupplyMagazines = 2;

	/** Total resupply uses before the crate is spent. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Build")
	int32 SupplyUses = 8;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	float ConstructionProgress = 0.f;

	UPROPERTY(Replicated, BlueprintReadOnly, Category = "State")
	int32 RemainingSupplyUses = 8;

private:
	UPROPERTY() TWeakObjectPtr<class ABFCharacter> BuilderCharacter;
	float TargetIntegrityAfterBuild = 0.f;
};
