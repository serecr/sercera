#include "Systems/BFBuildComponent.h"

#include "Characters/BFCharacter.h"
#include "Components/StaticMeshComponent.h"
#include "Core/BFLog.h"
#include "Data/BFSoldierClassDataAsset.h"
#include "Engine/OverlapResult.h"
#include "Gameplay/BFGameState.h"
#include "Materials/MaterialInterface.h"
#include "Net/UnrealNetwork.h"

UBFBuildComponent::UBFBuildComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = false;
	SetIsReplicatedByDefault(true);
}

void UBFBuildComponent::BeginPlay()
{
	Super::BeginPlay();
	OwnerCharacter = Cast<ABFCharacter>(GetOwner());
}

void UBFBuildComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(UBFBuildComponent, bCanBuild);
}

void UBFBuildComponent::ConfigureFromClass(const UBFSoldierClassDataAsset* ClassAsset)
{
	if (!GetOwner() || !GetOwner()->HasAuthority())
	{
		return;
	}

	bCanBuild = ClassAsset && ClassAsset->bCanBuild;
}

int32 UBFBuildComponent::GetTeamResources() const
{
	if (const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr)
	{
		return GS->GetBuildResources(OwnerCharacter ? OwnerCharacter->GetTeam() : EBFTeam::Neutral);
	}
	return 0;
}

void UBFBuildComponent::EnsurePreviewMesh()
{
	if (PreviewMesh || !OwnerCharacter)
	{
		return;
	}

	PreviewMesh = NewObject<UStaticMeshComponent>(OwnerCharacter, TEXT("BuildPreview"));
	PreviewMesh->RegisterComponent();
	PreviewMesh->SetCollisionEnabled(ECollisionEnabled::NoCollision);
	PreviewMesh->SetCastShadow(false);
	PreviewMesh->SetOnlyOwnerSee(true);
	PreviewMesh->bReceivesDecals = false;
}

void UBFBuildComponent::ToggleBuildMode()
{
	if (!bCanBuild || !OwnerCharacter || !OwnerCharacter->IsLocallyControlled())
	{
		return;
	}

	if (bPreviewActive)
	{
		CancelBuildMode();
		return;
	}

	if (Catalogue.Num() == 0)
	{
		BF_LOG(LogBrokenFront, Warning, TEXT("Build catalogue is empty on %s."), *GetNameSafe(OwnerCharacter));
		return;
	}

	bPreviewActive = true;
	SelectedIndex = FMath::Clamp(SelectedIndex, 0, Catalogue.Num() - 1);
	EnsurePreviewMesh();
	SetComponentTickEnabled(true);
	OnBuildStateChanged.Broadcast(true, SelectedIndex);
}

void UBFBuildComponent::CancelBuildMode()
{
	bPreviewActive = false;
	bPlacementValid = false;
	SetComponentTickEnabled(false);

	if (PreviewMesh)
	{
		PreviewMesh->SetVisibility(false);
	}

	OnBuildStateChanged.Broadcast(false, SelectedIndex);
}

void UBFBuildComponent::SelectBuildable(int32 Index)
{
	if (Catalogue.IsValidIndex(Index))
	{
		SelectedIndex = Index;
		OnBuildStateChanged.Broadcast(bPreviewActive, SelectedIndex);
	}
}

void UBFBuildComponent::CycleBuildable(int32 Direction)
{
	if (Catalogue.Num() == 0)
	{
		return;
	}
	SelectBuildable((SelectedIndex + Direction + Catalogue.Num()) % Catalogue.Num());
}

void UBFBuildComponent::RotatePreview(float DeltaYaw)
{
	PreviewYaw = FMath::Fmod(PreviewYaw + DeltaYaw, 360.f);
}

bool UBFBuildComponent::TraceGroundForPlacement(FVector& OutLocation, FVector& OutNormal) const
{
	if (!OwnerCharacter)
	{
		return false;
	}

	FVector ViewLocation;
	FRotator ViewRotation;
	OwnerCharacter->GetAimTransform(ViewLocation, ViewRotation);

	const FVector AimEnd = ViewLocation + ViewRotation.Vector() * MaxPlacementDistance;

	// Aim ray first, then drop to the ground from wherever it lands.
	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFBuildAim), false, OwnerCharacter);
	FHitResult AimHit;
	const FVector Anchor = GetWorld()->LineTraceSingleByChannel(AimHit, ViewLocation, AimEnd, ECC_WorldStatic, Params)
		? AimHit.ImpactPoint
		: AimEnd;

	FHitResult GroundHit;
	if (GetWorld()->LineTraceSingleByChannel(GroundHit, Anchor + FVector(0.f, 0.f, 200.f),
		Anchor - FVector(0.f, 0.f, 400.f), ECC_WorldStatic, Params))
	{
		OutLocation = GroundHit.ImpactPoint;
		OutNormal = GroundHit.ImpactNormal;
		return true;
	}

	return false;
}

bool UBFBuildComponent::ValidatePlacement(const FVector& Location, const FVector& Normal, int32 Index) const
{
	if (!Catalogue.IsValidIndex(Index) || !OwnerCharacter)
	{
		return false;
	}

	// Distance from the builder.
	if (FVector::DistSquared(Location, OwnerCharacter->GetActorLocation()) > FMath::Square(MaxPlacementDistance + 100.f))
	{
		return false;
	}

	// Ground must be flat enough.
	const float SlopeDegrees = FMath::RadiansToDegrees(FMath::Acos(FVector::DotProduct(Normal, FVector::UpVector)));
	if (SlopeDegrees > MaxGroundSlope)
	{
		return false;
	}

	// No stacking on top of another piece.
	TArray<FOverlapResult> Overlaps;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFBuildOverlap), false, OwnerCharacter);
	if (GetWorld()->OverlapMultiByObjectType(Overlaps, Location, FQuat::Identity,
		FCollisionObjectQueryParams(ECC_Destructible), FCollisionShape::MakeSphere(MinSpacing), Params))
	{
		for (const FOverlapResult& Overlap : Overlaps)
		{
			if (Cast<ABFBuildableDefense>(Overlap.GetActor()))
			{
				return false;
			}
		}
	}

	// Resources.
	if (GetTeamResources() < Catalogue[Index].ResourceCost)
	{
		return false;
	}

	return true;
}

void UBFBuildComponent::UpdatePreview()
{
	if (!Catalogue.IsValidIndex(SelectedIndex) || !PreviewMesh)
	{
		return;
	}

	FVector Location;
	FVector Normal;
	if (!TraceGroundForPlacement(Location, Normal))
	{
		PreviewMesh->SetVisibility(false);
		bPlacementValid = false;
		return;
	}

	bPlacementValid = ValidatePlacement(Location, Normal, SelectedIndex);

	// Pull the preview mesh from the buildable's own CDO so there is nothing extra to author.
	if (const UClass* BuildClass = Catalogue[SelectedIndex].BuildableClass)
	{
		if (const ABFBuildableDefense* CDO = BuildClass->GetDefaultObject<ABFBuildableDefense>())
		{
			if (const UStaticMeshComponent* SourceMesh = CDO->FindComponentByClass<UStaticMeshComponent>())
			{
				if (PreviewMesh->GetStaticMesh() != SourceMesh->GetStaticMesh())
				{
					PreviewMesh->SetStaticMesh(SourceMesh->GetStaticMesh());
				}
			}
		}
	}

	PreviewMesh->SetVisibility(true);
	PreviewMesh->SetWorldLocationAndRotation(Location, FRotator(0.f, PreviewYaw, 0.f));

	UMaterialInterface* Material = bPlacementValid
		? ValidPreviewMaterial.LoadSynchronous()
		: InvalidPreviewMaterial.LoadSynchronous();

	if (Material)
	{
		for (int32 Index = 0; Index < PreviewMesh->GetNumMaterials(); ++Index)
		{
			PreviewMesh->SetMaterial(Index, Material);
		}
	}
}

void UBFBuildComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	if (bPreviewActive)
	{
		UpdatePreview();
	}
}

void UBFBuildComponent::ConfirmPlacement()
{
	if (!bPreviewActive || !bPlacementValid || !PreviewMesh)
	{
		return;
	}

	const FVector Location = PreviewMesh->GetComponentLocation();
	ServerPlaceBuildable(SelectedIndex, Location, PreviewYaw);
	CancelBuildMode();
}

bool UBFBuildComponent::ServerPlaceBuildable_Validate(int32 Index, FVector_NetQuantize /*Location*/, float /*Yaw*/)
{
	return Index >= 0 && Index < 64;
}

void UBFBuildComponent::ServerPlaceBuildable_Implementation(int32 Index, FVector_NetQuantize Location, float Yaw)
{
	if (!bCanBuild || !OwnerCharacter || !Catalogue.IsValidIndex(Index))
	{
		return;
	}

	const FBFBuildableEntry& Entry = Catalogue[Index];
	if (!Entry.BuildableClass)
	{
		return;
	}

	// Re-validate on the server. Never trust the client's placement.
	FHitResult GroundHit;
	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFBuildServerGround), false, OwnerCharacter);
	FVector Normal = FVector::UpVector;
	if (GetWorld()->LineTraceSingleByChannel(GroundHit, FVector(Location) + FVector(0.f, 0.f, 200.f),
		FVector(Location) - FVector(0.f, 0.f, 300.f), ECC_WorldStatic, Params))
	{
		Normal = GroundHit.ImpactNormal;
		Location = GroundHit.ImpactPoint;
	}

	if (!ValidatePlacement(Location, Normal, Index))
	{
		return;
	}

	ABFGameState* GS = GetWorld()->GetGameState<ABFGameState>();
	const EBFTeam Team = OwnerCharacter->GetTeam();
	if (!GS || !GS->ConsumeBuildResources(Team, Entry.ResourceCost))
	{
		return;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.Owner = OwnerCharacter;
	SpawnParams.Instigator = OwnerCharacter;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	ABFBuildableDefense* Placed = GetWorld()->SpawnActor<ABFBuildableDefense>(
		Entry.BuildableClass, FVector(Location), FRotator(0.f, Yaw, 0.f), SpawnParams);

	if (Placed)
	{
		Placed->BeginConstruction(Team, OwnerCharacter);
	}
	else
	{
		GS->RefundBuildResources(Team, Entry.ResourceCost);
	}
}
