#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Core/BFTypes.h"
#include "BFAudioManager.generated.h"

class USoundBase;
class USoundMix;
class USoundClass;
class UNiagaraSystem;
class USoundAttenuation;

/** Surface impact bank: one row per surface, shared by bullets, shrapnel and debris. */
USTRUCT(BlueprintType)
struct FBFSurfaceImpactSet
{
	GENERATED_BODY()

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) EBFSurfaceType Surface = EBFSurfaceType::Default;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<USoundBase> ImpactSound;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<UNiagaraSystem> ImpactEffect;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite) TSoftObjectPtr<UNiagaraSystem> ImpactDecal;
};

/**
 * One per level. Central place for spatialised one-shots so every system shares
 * the same attenuation, the same surface banks, and the same indoor treatment.
 *
 * Bunker muffling: instead of per-sound raycasts everywhere, the manager applies
 * a sound mix when the local listener is enclosed, and dampens one-shots that
 * originate outside while the listener is inside.
 */
UCLASS()
class BROKENFRONT_API ABFAudioManager : public AActor
{
	GENERATED_BODY()

public:
	ABFAudioManager();

	virtual void Tick(float DeltaSeconds) override;
	virtual void BeginPlay() override;

	static ABFAudioManager* Get(const UWorld* World);

	/** Plays a one-shot through the shared attenuation, applying indoor damping. */
	static void PlaySpatialised(const UWorld* World, USoundBase* Sound, const FVector& Location, float VolumeScale = 1.f);

	/** Bullet/shrapnel impact: sound plus VFX, chosen by surface. */
	static void PlaySurfaceImpact(const UWorld* World, EBFSurfaceType Surface, const FVector& Location, const FVector& Normal);

	/** Distant artillery / far-off firefights. Plays 2D with a random offset so it reads as "somewhere out there". */
	UFUNCTION(BlueprintCallable, Category = "Audio")
	void PlayDistantRumble();

	UFUNCTION(BlueprintPure, Category = "Audio") bool IsListenerIndoors() const { return bListenerIndoors; }

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<FBFSurfaceImpactSet> SurfaceImpacts;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TSoftObjectPtr<USoundAttenuation> DefaultAttenuation;

	/** Applied while the listener is inside a bunker or tunnel. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TSoftObjectPtr<USoundMix> IndoorSoundMix;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<TSoftObjectPtr<USoundBase>> DistantRumbleSounds;

	/** Seconds between distant battle rumbles. Randomised within the range. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float RumbleMinInterval = 14.f;
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float RumbleMaxInterval = 48.f;

	/** Volume multiplier applied to outdoor one-shots heard from inside. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config") float IndoorDamping = 0.42f;

private:
	bool bListenerIndoors = false;
	bool bMixPushed = false;
	float IndoorCheckTimer = 0.f;
	float RumbleTimer = 0.f;

	void UpdateListenerEnclosure();
	const FBFSurfaceImpactSet* FindImpactSet(EBFSurfaceType Surface) const;
};
