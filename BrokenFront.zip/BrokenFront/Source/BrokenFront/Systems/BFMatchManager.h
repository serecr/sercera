#pragma once

#include "CoreMinimal.h"
#include "Subsystems/WorldSubsystem.h"
#include "Core/BFTypes.h"
#include "BFMatchManager.generated.h"

class ABFGameState;

/**
 * Owns match timing: waiting for players, warmup, the match clock, and the
 * post-match window before travelling. The game mode delegates here so the
 * flow is testable and the rules live in one file.
 */
UCLASS()
class BROKENFRONT_API UBFMatchManager : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	static UBFMatchManager* Get(const UWorld* World);

	virtual void OnWorldBeginPlay(UWorld& InWorld) override;
	virtual void Tick(float DeltaTime);

	UFUNCTION(BlueprintCallable, Category = "Match") void NotifyPlayerJoined();
	UFUNCTION(BlueprintCallable, Category = "Match") void NotifyPlayerLeft();

	/** Server: skip straight to the match, used by the training map and debug. */
	UFUNCTION(BlueprintCallable, Category = "Match") void ForceStartMatch();

	UFUNCTION(BlueprintCallable, Category = "Match") void EndMatch(EBFTeam Winner, FName Reason);

	UFUNCTION(BlueprintPure, Category = "Match") float GetPhaseTimeRemaining() const { return PhaseTimeRemaining; }

	// ---------- Tuning ----------
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config") int32 MinPlayersToStart = 2;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config") float WarmupDuration = 45.f;
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config") float MatchDuration = 2400.f; // 40 minutes
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Config") float PostMatchDuration = 25.f;

private:
	float PhaseTimeRemaining = 0.f;
	bool bTickEnabled = false;
	int32 ConnectedPlayers = 0;

	ABFGameState* GetBFGameState() const;
	void EnterPhase(EBFMatchPhase Phase);
	void HandleTimeExpired();
	void AwardEndOfMatchProgression(EBFTeam Winner);
};
