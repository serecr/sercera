#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "Core/BFTypes.h"
#include "BFDamageManager.generated.h"

class ABFCharacter;
class UBFWeaponDataAsset;

/**
 * Single funnel for every damage event in the game: hit-zone multipliers,
 * friendly-fire rules, destructible routing, explosion handling and crater
 * spawning all live here so no two systems can disagree.
 * Server authority is asserted at the top of every entry point.
 */
UCLASS()
class BROKENFRONT_API UBFDamageManager : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	/** Resolves one bullet/pellet hit. Safe to call with a null target. */
	static void ApplyWeaponDamage(
		AActor* Target,
		float BaseDamage,
		const FHitResult& Hit,
		const FVector& ShotDirection,
		ABFCharacter* Shooter,
		AActor* DamageCauser,
		const UBFWeaponDataAsset* WeaponData);

	/**
	 * Explosion: radial damage with falloff, structural damage to destructibles,
	 * physics impulse on debris, and a terrain crater sized from the radius.
	 */
	UFUNCTION(BlueprintCallable, Category = "BrokenFront|Damage", meta = (WorldContext = "WorldContextObject"))
	static void ApplyExplosion(
		UObject* WorldContextObject,
		FVector Origin,
		float Radius,
		float MaxDamage,
		AActor* Instigator,
		bool bSpawnCrater = true,
		float StructuralMultiplier = 2.5f);

	/** Team damage rules, honouring the game state's friendly-fire setting. */
	UFUNCTION(BlueprintPure, Category = "BrokenFront|Damage", meta = (WorldContext = "WorldContextObject"))
	static bool ShouldApplyDamage(UObject* WorldContextObject, EBFTeam ShooterTeam, EBFTeam TargetTeam, float& OutScale);

	/** Maps a skeleton bone to a coarse hit zone name used by the weapon multipliers. */
	UFUNCTION(BlueprintPure, Category = "BrokenFront|Damage")
	static FName ResolveHitZone(FName BoneName);
};
