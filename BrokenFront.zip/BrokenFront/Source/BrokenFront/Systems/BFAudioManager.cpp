#include "Systems/BFAudioManager.h"

#include "Characters/BFCharacter.h"
#include "Components/AudioComponent.h"
#include "Engine/World.h"
#include "EngineUtils.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraSystem.h"
#include "Sound/SoundAttenuation.h"
#include "Sound/SoundBase.h"
#include "Sound/SoundMix.h"

ABFAudioManager::ABFAudioManager()
{
	PrimaryActorTick.bCanEverTick = true;
	PrimaryActorTick.TickInterval = 0.2f;
	bReplicates = false; // purely local presentation

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);
}

ABFAudioManager* ABFAudioManager::Get(const UWorld* World)
{
	if (!World)
	{
		return nullptr;
	}
	for (TActorIterator<ABFAudioManager> It(World); It; ++It)
	{
		return *It;
	}
	return nullptr;
}

void ABFAudioManager::BeginPlay()
{
	Super::BeginPlay();

	if (GetNetMode() == NM_DedicatedServer)
	{
		SetActorTickEnabled(false);
		return;
	}

	RumbleTimer = FMath::FRandRange(RumbleMinInterval, RumbleMaxInterval);
}

void ABFAudioManager::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	IndoorCheckTimer += DeltaSeconds;
	if (IndoorCheckTimer >= 0.5f)
	{
		IndoorCheckTimer = 0.f;
		UpdateListenerEnclosure();
	}

	RumbleTimer -= DeltaSeconds;
	if (RumbleTimer <= 0.f)
	{
		RumbleTimer = FMath::FRandRange(RumbleMinInterval, RumbleMaxInterval);
		PlayDistantRumble();
	}
}

void ABFAudioManager::UpdateListenerEnclosure()
{
	const APlayerController* PC = GetWorld()->GetFirstPlayerController();
	const ABFCharacter* Char = PC ? Cast<ABFCharacter>(PC->GetPawn()) : nullptr;

	const bool bNewIndoors = Char ? Char->IsIndoors() : false;
	if (bNewIndoors == bListenerIndoors)
	{
		return;
	}

	bListenerIndoors = bNewIndoors;

	if (USoundMix* Mix = IndoorSoundMix.LoadSynchronous())
	{
		if (bListenerIndoors && !bMixPushed)
		{
			UGameplayStatics::PushSoundMixModifier(this, Mix);
			bMixPushed = true;
		}
		else if (!bListenerIndoors && bMixPushed)
		{
			UGameplayStatics::PopSoundMixModifier(this, Mix);
			bMixPushed = false;
		}
	}
}

void ABFAudioManager::PlaySpatialised(const UWorld* World, USoundBase* Sound, const FVector& Location, float VolumeScale)
{
	if (!World || !Sound || World->GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	float Volume = VolumeScale;
	USoundAttenuation* Attenuation = nullptr;

	if (const ABFAudioManager* Manager = Get(World))
	{
		Attenuation = Manager->DefaultAttenuation.LoadSynchronous();

		// Heard from inside a bunker, an outdoor shot should be a dull thud.
		if (Manager->IsListenerIndoors())
		{
			const APlayerController* PC = World->GetFirstPlayerController();
			const ABFCharacter* Char = PC ? Cast<ABFCharacter>(PC->GetPawn()) : nullptr;
			if (Char && FVector::DistSquared(Char->GetActorLocation(), Location) > FMath::Square(600.f))
			{
				Volume *= Manager->IndoorDamping;
			}
		}
	}

	UGameplayStatics::PlaySoundAtLocation(World->GetFirstPlayerController(), Sound, Location,
		FRotator::ZeroRotator, Volume, 1.f, 0.f, Attenuation);
}

const FBFSurfaceImpactSet* ABFAudioManager::FindImpactSet(EBFSurfaceType Surface) const
{
	const FBFSurfaceImpactSet* Exact = SurfaceImpacts.FindByPredicate(
		[Surface](const FBFSurfaceImpactSet& Set) { return Set.Surface == Surface; });

	if (Exact)
	{
		return Exact;
	}

	return SurfaceImpacts.FindByPredicate(
		[](const FBFSurfaceImpactSet& Set) { return Set.Surface == EBFSurfaceType::Default; });
}

void ABFAudioManager::PlaySurfaceImpact(const UWorld* World, EBFSurfaceType Surface, const FVector& Location, const FVector& Normal)
{
	if (!World || World->GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	const ABFAudioManager* Manager = Get(World);
	if (!Manager)
	{
		return;
	}

	const FBFSurfaceImpactSet* Set = Manager->FindImpactSet(Surface);
	if (!Set)
	{
		return;
	}

	if (USoundBase* Sound = Set->ImpactSound.LoadSynchronous())
	{
		PlaySpatialised(World, Sound, Location, 1.f);
	}

	const FRotator Rotation = Normal.Rotation();

	if (UNiagaraSystem* Effect = Set->ImpactEffect.LoadSynchronous())
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(World, Effect, Location, Rotation);
	}

	if (UNiagaraSystem* Decal = Set->ImpactDecal.LoadSynchronous())
	{
		UNiagaraFunctionLibrary::SpawnSystemAtLocation(World, Decal, Location, Rotation);
	}
}

void ABFAudioManager::PlayDistantRumble()
{
	if (DistantRumbleSounds.Num() == 0 || GetNetMode() == NM_DedicatedServer)
	{
		return;
	}

	const int32 Index = FMath::RandRange(0, DistantRumbleSounds.Num() - 1);
	if (USoundBase* Sound = DistantRumbleSounds[Index].LoadSynchronous())
	{
		// 2D with a random, quiet level: the war is happening elsewhere too.
		UGameplayStatics::PlaySound2D(this, Sound, FMath::FRandRange(0.25f, 0.55f), FMath::FRandRange(0.92f, 1.08f));
	}
}
