#include "Systems/BFWeatherManager.h"

#include "Components/AudioComponent.h"
#include "Components/DirectionalLightComponent.h"
#include "Components/ExponentialHeightFogComponent.h"
#include "Components/SkyAtmosphereComponent.h"
#include "Components/SkyLightComponent.h"
#include "Components/VolumetricCloudComponent.h"
#include "Core/BFLog.h"
#include "Engine/DataTable.h"
#include "EngineUtils.h"
#include "Kismet/KismetMaterialLibrary.h"
#include "Materials/MaterialParameterCollection.h"
#include "Net/UnrealNetwork.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "Sound/SoundBase.h"

ABFWeatherManager::ABFWeatherManager()
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;
	SetReplicateMovement(false);
	bAlwaysRelevant = true;
	NetUpdateFrequency = 1.f; // weather changes over tens of seconds

	USceneComponent* Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	SetRootComponent(Root);

	SunLight = CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("SunLight"));
	SunLight->SetupAttachment(Root);
	SunLight->SetMobility(EComponentMobility::Movable);
	SunLight->SetIntensity(6.f);
	SunLight->bAtmosphereSunLight = true;
	SunLight->SetDynamicShadowCascades(3);
	SunLight->SetShadowAmount(1.f);
	// Virtual shadow maps: crisp trench shadows without cascade seams.
	SunLight->ForwardShadingPriority = 0;

	MoonLight = CreateDefaultSubobject<UDirectionalLightComponent>(TEXT("MoonLight"));
	MoonLight->SetupAttachment(Root);
	MoonLight->SetMobility(EComponentMobility::Movable);
	MoonLight->SetIntensity(0.f);
	MoonLight->SetLightColor(FLinearColor(0.4f, 0.5f, 0.85f));
	MoonLight->bAtmosphereSunLight = false;

	SkyLight = CreateDefaultSubobject<USkyLightComponent>(TEXT("SkyLight"));
	SkyLight->SetupAttachment(Root);
	SkyLight->SetMobility(EComponentMobility::Movable);
	SkyLight->bRealTimeCapture = true;

	SkyAtmosphere = CreateDefaultSubobject<USkyAtmosphereComponent>(TEXT("SkyAtmosphere"));
	SkyAtmosphere->SetupAttachment(Root);

	VolumetricClouds = CreateDefaultSubobject<UVolumetricCloudComponent>(TEXT("VolumetricClouds"));
	VolumetricClouds->SetupAttachment(Root);

	HeightFog = CreateDefaultSubobject<UExponentialHeightFogComponent>(TEXT("HeightFog"));
	HeightFog->SetupAttachment(Root);
	HeightFog->SetFogDensity(0.02f);
	HeightFog->SetVolumetricFog(true);

	RainEffect = CreateDefaultSubobject<UNiagaraComponent>(TEXT("RainEffect"));
	RainEffect->SetupAttachment(Root);
	RainEffect->bAutoActivate = false;

	AmbienceAudio = CreateDefaultSubobject<UAudioComponent>(TEXT("AmbienceAudio"));
	AmbienceAudio->SetupAttachment(Root);
	AmbienceAudio->bAutoActivate = false;
	AmbienceAudio->bAllowSpatialization = false;
}

ABFWeatherManager* ABFWeatherManager::Get(const UWorld* World)
{
	if (!World)
	{
		return nullptr;
	}
	for (TActorIterator<ABFWeatherManager> It(World); It; ++It)
	{
		return *It;
	}
	return nullptr;
}

void ABFWeatherManager::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(ABFWeatherManager, TargetState);
	DOREPLIFETIME(ABFWeatherManager, TimeOfDay);
	DOREPLIFETIME(ABFWeatherManager, BlendRemaining);
}

void ABFWeatherManager::BeginPlay()
{
	Super::BeginPlay();

	TimeOfDay = StartingHour;
	TargetState = StartingWeather;

	LoadPreset(StartingWeather, CurrentPreset);
	TargetPreset = CurrentPreset;
	BlendRemaining = 0.f;

	Snapshot.State = StartingWeather;
	Snapshot.RainIntensity = CurrentPreset.RainIntensity;
	Snapshot.FogDensity = CurrentPreset.FogDensity;
	Snapshot.CloudCoverage = CurrentPreset.CloudCoverage;
	Snapshot.WindStrength = CurrentPreset.WindStrength;
	Snapshot.ThunderChance = CurrentPreset.ThunderChance;

	if (HasAuthority())
	{
		StateTimeRemaining = FMath::FRandRange(CurrentPreset.MinDuration, CurrentPreset.MaxDuration);
	}

	if (UNiagaraSystem* System = RainSystem.LoadSynchronous())
	{
		RainEffect->SetAsset(System);
	}

	ApplyToScene();
	UpdateDayPhase();
}

void ABFWeatherManager::LoadPreset(EBFWeatherState State, FBFWeatherPreset& OutPreset) const
{
	// Table first, so designers can retune without touching code.
	if (WeatherPresetTable)
	{
		TArray<FBFWeatherPreset*> Rows;
		WeatherPresetTable->GetAllRows<FBFWeatherPreset>(TEXT("BFWeather"), Rows);
		for (const FBFWeatherPreset* Row : Rows)
		{
			if (Row && Row->State == State)
			{
				OutPreset = *Row;
				return;
			}
		}
	}

	// Sensible built-in defaults so the system works in an empty project.
	FBFWeatherPreset Preset;
	Preset.State = State;

	switch (State)
	{
	case EBFWeatherState::Clear:
		Preset.RainIntensity = 0.f; Preset.FogDensity = 0.012f; Preset.CloudCoverage = 0.12f;
		Preset.WindStrength = 0.12f; Preset.MudRate = 0.f; Preset.VisibilityMultiplier = 1.f;
		Preset.AllowedTransitions = { EBFWeatherState::Cloudy, EBFWeatherState::Fog };
		break;

	case EBFWeatherState::Cloudy:
		Preset.RainIntensity = 0.f; Preset.FogDensity = 0.022f; Preset.CloudCoverage = 0.55f;
		Preset.WindStrength = 0.28f; Preset.MudRate = 0.f; Preset.VisibilityMultiplier = 0.92f;
		Preset.AllowedTransitions = { EBFWeatherState::Clear, EBFWeatherState::Rain, EBFWeatherState::Fog };
		break;

	case EBFWeatherState::Rain:
		Preset.RainIntensity = 0.45f; Preset.FogDensity = 0.035f; Preset.CloudCoverage = 0.8f;
		Preset.WindStrength = 0.4f; Preset.MudRate = 0.03f; Preset.VisibilityMultiplier = 0.72f;
		Preset.AllowedTransitions = { EBFWeatherState::Cloudy, EBFWeatherState::HeavyRain, EBFWeatherState::Fog };
		break;

	case EBFWeatherState::HeavyRain:
		Preset.RainIntensity = 1.f; Preset.FogDensity = 0.05f; Preset.CloudCoverage = 0.95f;
		Preset.WindStrength = 0.65f; Preset.MudRate = 0.07f; Preset.VisibilityMultiplier = 0.5f;
		Preset.ThunderChance = 0.25f;
		Preset.AllowedTransitions = { EBFWeatherState::Rain, EBFWeatherState::Storm, EBFWeatherState::Fog };
		break;

	case EBFWeatherState::Fog:
		Preset.RainIntensity = 0.f; Preset.FogDensity = 0.12f; Preset.CloudCoverage = 0.7f;
		Preset.WindStrength = 0.06f; Preset.MudRate = 0.01f; Preset.VisibilityMultiplier = 0.35f;
		Preset.AllowedTransitions = { EBFWeatherState::Cloudy, EBFWeatherState::Rain, EBFWeatherState::Clear };
		break;

	case EBFWeatherState::Storm:
		Preset.RainIntensity = 1.f; Preset.FogDensity = 0.07f; Preset.CloudCoverage = 1.f;
		Preset.WindStrength = 1.f; Preset.MudRate = 0.09f; Preset.VisibilityMultiplier = 0.4f;
		Preset.ThunderChance = 0.8f;
		Preset.MinDuration = 120.f; Preset.MaxDuration = 240.f;
		Preset.AllowedTransitions = { EBFWeatherState::HeavyRain, EBFWeatherState::Rain };
		break;
	}

	OutPreset = Preset;
}

void ABFWeatherManager::SetWeatherState(EBFWeatherState NewState, float TransitionSeconds)
{
	if (!HasAuthority() || NewState == TargetState)
	{
		return;
	}

	TargetState = NewState;
	LoadPreset(NewState, TargetPreset);
	BlendDuration = FMath::Max(TransitionSeconds, 0.5f);
	BlendRemaining = BlendDuration;
	StateTimeRemaining = FMath::FRandRange(TargetPreset.MinDuration, TargetPreset.MaxDuration);

	BF_LOG(LogBFWeather, Log, TEXT("Weather -> %d over %.0fs"), static_cast<int32>(NewState), BlendDuration);
	OnWeatherChanged.Broadcast(NewState);
}

void ABFWeatherManager::OnRep_TargetState()
{
	LoadPreset(TargetState, TargetPreset);
	BlendDuration = FMath::Max(BlendRemaining, 0.5f);
	OnWeatherChanged.Broadcast(TargetState);
}

void ABFWeatherManager::RollNextWeather()
{
	const TArray<EBFWeatherState>& Options = CurrentPreset.AllowedTransitions;
	if (Options.Num() == 0)
	{
		StateTimeRemaining = 120.f;
		return;
	}

	const EBFWeatherState Next = Options[FMath::RandRange(0, Options.Num() - 1)];
	// Long, believable transitions. A downpour does not appear in three seconds.
	SetWeatherState(Next, FMath::FRandRange(25.f, 70.f));
}

void ABFWeatherManager::SetTimeOfDay(float NewHour)
{
	TimeOfDay = FMath::Fmod(FMath::Max(NewHour, 0.f), 24.f);
	UpdateDayPhase();
	ApplyToScene();
}

void ABFWeatherManager::AdvanceTime(float DeltaSeconds)
{
	if (!bAdvanceTime)
	{
		return;
	}

	TimeOfDay = FMath::Fmod(TimeOfDay + (DeltaSeconds / FMath::Max(SecondsPerGameHour, 1.f)), 24.f);
}

void ABFWeatherManager::UpdateDayPhase()
{
	EBFDayPhase Phase = EBFDayPhase::Day;
	if (TimeOfDay >= 5.f && TimeOfDay < 7.5f)       { Phase = EBFDayPhase::Dawn; }
	else if (TimeOfDay >= 7.5f && TimeOfDay < 18.f) { Phase = EBFDayPhase::Day; }
	else if (TimeOfDay >= 18.f && TimeOfDay < 20.5f){ Phase = EBFDayPhase::Dusk; }
	else                                            { Phase = EBFDayPhase::Night; }

	Snapshot.DayPhase = Phase;
	Snapshot.TimeOfDay = TimeOfDay;
}

void ABFWeatherManager::UpdateBlend(float DeltaSeconds)
{
	if (BlendRemaining <= 0.f)
	{
		CurrentPreset = TargetPreset;
		Snapshot.State = TargetState;
		return;
	}

	BlendRemaining = FMath::Max(0.f, BlendRemaining - DeltaSeconds);
	const float Alpha = 1.f - (BlendRemaining / FMath::Max(BlendDuration, 0.001f));

	CurrentPreset.RainIntensity = FMath::Lerp(CurrentPreset.RainIntensity, TargetPreset.RainIntensity, Alpha * DeltaSeconds * 2.f);
	CurrentPreset.FogDensity = FMath::Lerp(CurrentPreset.FogDensity, TargetPreset.FogDensity, Alpha * DeltaSeconds * 2.f);
	CurrentPreset.CloudCoverage = FMath::Lerp(CurrentPreset.CloudCoverage, TargetPreset.CloudCoverage, Alpha * DeltaSeconds * 2.f);
	CurrentPreset.WindStrength = FMath::Lerp(CurrentPreset.WindStrength, TargetPreset.WindStrength, Alpha * DeltaSeconds * 2.f);
	CurrentPreset.ThunderChance = FMath::Lerp(CurrentPreset.ThunderChance, TargetPreset.ThunderChance, Alpha * DeltaSeconds * 2.f);
	CurrentPreset.MudRate = FMath::Lerp(CurrentPreset.MudRate, TargetPreset.MudRate, Alpha * DeltaSeconds * 2.f);
	CurrentPreset.VisibilityMultiplier = FMath::Lerp(CurrentPreset.VisibilityMultiplier, TargetPreset.VisibilityMultiplier, Alpha * DeltaSeconds * 2.f);

	if (BlendRemaining <= 0.f)
	{
		CurrentPreset = TargetPreset;
		Snapshot.State = TargetState;
	}
}

void ABFWeatherManager::Tick(float DeltaSeconds)
{
	Super::Tick(DeltaSeconds);

	AdvanceTime(DeltaSeconds);
	UpdateDayPhase();
	UpdateBlend(DeltaSeconds);

	if (HasAuthority() && bAutoChangeWeather && BlendRemaining <= 0.f)
	{
		StateTimeRemaining -= DeltaSeconds;
		if (StateTimeRemaining <= 0.f)
		{
			RollNextWeather();
		}
	}

	Snapshot.RainIntensity = CurrentPreset.RainIntensity;
	Snapshot.FogDensity = CurrentPreset.FogDensity;
	Snapshot.CloudCoverage = CurrentPreset.CloudCoverage;
	Snapshot.WindStrength = CurrentPreset.WindStrength;
	Snapshot.ThunderChance = CurrentPreset.ThunderChance;
	Snapshot.WindDirection = FRotator(0.f, TimeOfDay * 6.f, 0.f).Vector();

	// Dedicated servers skip all rendering work but keep the simulation running.
	if (GetNetMode() != NM_DedicatedServer)
	{
		ApplyToScene();
		MaybePlayThunder(DeltaSeconds);
	}
}

void ABFWeatherManager::ApplyToScene()
{
	// --- Sun / moon orbit. 6:00 = sunrise on the eastern horizon. ---
	const float SunAngle = (TimeOfDay / 24.f) * 360.f - 90.f;
	SunLight->SetWorldRotation(FRotator(SunAngle, 45.f, 0.f));
	MoonLight->SetWorldRotation(FRotator(SunAngle + 180.f, 45.f, 0.f));

	// Above the horizon the sun lights the scene; below it the moon takes over.
	const float SunHeight = FMath::Sin(FMath::DegreesToRadians(-SunAngle));
	const float DayAlpha = FMath::Clamp(SunHeight * 3.f, 0.f, 1.f);
	const float CloudDim = FMath::Lerp(1.f, 0.35f, CurrentPreset.CloudCoverage);

	SunLight->SetIntensity(MaxSunIntensity * DayAlpha * CloudDim);
	MoonLight->SetIntensity(MoonIntensity * (1.f - DayAlpha));

	FLinearColor SunColour = DaySunColour;
	switch (Snapshot.DayPhase)
	{
	case EBFDayPhase::Dawn:  SunColour = DawnSunColour; break;
	case EBFDayPhase::Dusk:  SunColour = DuskSunColour; break;
	case EBFDayPhase::Night: SunColour = NightColour; break;
	default: break;
	}
	SunLight->SetLightColor(SunColour);

	SunLight->bAtmosphereSunLight = DayAlpha > 0.05f;
	MoonLight->bAtmosphereSunLight = DayAlpha <= 0.05f;

	// --- Fog: heavier at night, in fog weather, and low in the trenches. ---
	const float NightFogBoost = FMath::Lerp(1.6f, 1.f, DayAlpha);
	HeightFog->SetFogDensity(CurrentPreset.FogDensity * NightFogBoost);
	HeightFog->SetVolumetricFogExtinctionScale(FMath::Lerp(1.f, 2.5f, CurrentPreset.FogDensity * 8.f));
	HeightFog->SetFogInscatteringColor(FLinearColor::LerpUsingHSV(NightColour, SunColour, DayAlpha));

	// --- Clouds ---
	if (VolumetricClouds)
	{
		VolumetricClouds->SetLayerBottomAltitude(FMath::Lerp(4.f, 1.5f, CurrentPreset.CloudCoverage));
		VolumetricClouds->SetLayerHeight(FMath::Lerp(3.f, 9.f, CurrentPreset.CloudCoverage));
	}

	// --- Rain ---
	if (RainEffect)
	{
		const bool bShouldRain = CurrentPreset.RainIntensity > 0.02f;
		if (bShouldRain && !RainEffect->IsActive())
		{
			RainEffect->Activate(true);
		}
		else if (!bShouldRain && RainEffect->IsActive())
		{
			RainEffect->Deactivate();
		}

		if (RainEffect->IsActive())
		{
			RainEffect->SetFloatParameter(TEXT("RainIntensity"), CurrentPreset.RainIntensity);
			RainEffect->SetVectorParameter(TEXT("WindVector"), Snapshot.WindDirection * CurrentPreset.WindStrength * 400.f);
		}
	}

	// --- Global material parameters: puddles, wet landscape, foliage wind. ---
	if (GlobalWeatherParameters)
	{
		UKismetMaterialLibrary::SetScalarParameterValue(this, GlobalWeatherParameters, TEXT("RainAmount"), CurrentPreset.RainIntensity);
		UKismetMaterialLibrary::SetScalarParameterValue(this, GlobalWeatherParameters, TEXT("WetAmount"), FMath::Max(CurrentPreset.RainIntensity, CurrentPreset.FogDensity * 4.f));
		UKismetMaterialLibrary::SetScalarParameterValue(this, GlobalWeatherParameters, TEXT("WindStrength"), CurrentPreset.WindStrength);
		UKismetMaterialLibrary::SetScalarParameterValue(this, GlobalWeatherParameters, TEXT("NightAmount"), 1.f - DayAlpha);
		UKismetMaterialLibrary::SetVectorParameterValue(this, GlobalWeatherParameters, TEXT("WindDirection"), Snapshot.WindDirection);
	}

	// --- Ambience bed: rain over wind, crossfaded. ---
	if (AmbienceAudio)
	{
		USoundBase* Desired = (CurrentPreset.RainIntensity > 0.2f)
			? RainAmbience.LoadSynchronous()
			: WindAmbience.LoadSynchronous();

		if (Desired && AmbienceAudio->Sound != Desired)
		{
			AmbienceAudio->SetSound(Desired);
			AmbienceAudio->FadeIn(3.f, 1.f);
		}

		const float Volume = FMath::Max(0.25f, FMath::Max(CurrentPreset.RainIntensity, CurrentPreset.WindStrength));
		AmbienceAudio->SetVolumeMultiplier(Volume);
	}
}

void ABFWeatherManager::MaybePlayThunder(float DeltaSeconds)
{
	if (CurrentPreset.ThunderChance <= 0.f)
	{
		return;
	}

	ThunderCooldown -= DeltaSeconds;
	if (ThunderCooldown > 0.f)
	{
		return;
	}

	// Roughly one strike every 8-25 seconds at full storm intensity.
	ThunderCooldown = FMath::FRandRange(8.f, 25.f) / FMath::Max(CurrentPreset.ThunderChance, 0.05f);

	if (USoundBase* Sound = ThunderSound.LoadSynchronous())
	{
		if (AmbienceAudio)
		{
			UGameplayStatics::PlaySound2D(this, Sound, 1.f);
		}
	}

	// A brief lightning flash by spiking the sky light. Cheap and effective.
	if (SkyLight)
	{
		const float Original = SkyLight->Intensity;
		SkyLight->SetIntensity(Original * 4.f);
		FTimerHandle Handle;
		GetWorldTimerManager().SetTimer(Handle, [this, Original]()
		{
			if (SkyLight) { SkyLight->SetIntensity(Original); }
		}, 0.12f, false);
	}
}

float ABFWeatherManager::GetCurrentMudRate() const
{
	return CurrentPreset.MudRate;
}

float ABFWeatherManager::GetVisibilityMultiplier() const
{
	const float NightPenalty = (Snapshot.DayPhase == EBFDayPhase::Night) ? 0.45f
		: (Snapshot.DayPhase == EBFDayPhase::Dawn || Snapshot.DayPhase == EBFDayPhase::Dusk) ? 0.75f : 1.f;

	return CurrentPreset.VisibilityMultiplier * NightPenalty;
}
