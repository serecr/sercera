#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "Data/BFLoadout.h"
#include "BFDeployWidget.generated.h"

class UBFSoldierClassDataAsset;
class UBFWeaponDataAsset;
class ABFSpawnPoint;

/**
 * Team select + loadout + deploy, in one screen. Drives the whole pre-match flow:
 * TEAM SELECT -> LOADOUT -> DEPLOY.
 */
UCLASS(Abstract)
class BROKENFRONT_API UBFDeployWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	// ---------- Class / loadout ----------
	UFUNCTION(BlueprintCallable, Category = "Deploy") void SelectClass(UBFSoldierClassDataAsset* ClassAsset);
	UFUNCTION(BlueprintCallable, Category = "Deploy") void SelectPrimary(UBFWeaponDataAsset* Weapon);
	UFUNCTION(BlueprintCallable, Category = "Deploy") void SelectSecondary(UBFWeaponDataAsset* Weapon);
	UFUNCTION(BlueprintCallable, Category = "Deploy") void SelectEquipment(int32 EquipmentIndex);
	UFUNCTION(BlueprintCallable, Category = "Deploy") void SelectUniform(FName UniformId);

	UFUNCTION(BlueprintPure, Category = "Deploy") const FBFLoadout& GetPendingLoadout() const { return PendingLoadout; }

	/** Available classes, filtered by team limits and career level. */
	UFUNCTION(BlueprintPure, Category = "Deploy") TArray<UBFSoldierClassDataAsset*> GetSelectableClasses() const;

	UFUNCTION(BlueprintPure, Category = "Deploy") TArray<UBFWeaponDataAsset*> GetSelectablePrimaries() const;
	UFUNCTION(BlueprintPure, Category = "Deploy") TArray<UBFWeaponDataAsset*> GetSelectableSecondaries() const;

	// ---------- Team & deploy ----------
	UFUNCTION(BlueprintCallable, Category = "Deploy") void RequestTeam(EBFTeam Team);
	UFUNCTION(BlueprintCallable, Category = "Deploy") void Deploy(EBFSpawnKind PreferredKind);

	UFUNCTION(BlueprintPure, Category = "Deploy") bool CanDeployNow() const;
	UFUNCTION(BlueprintPure, Category = "Deploy") TArray<ABFSpawnPoint*> GetAvailableSpawns() const;
	UFUNCTION(BlueprintPure, Category = "Deploy") FText GetFrontlineSummary() const;

	UFUNCTION(BlueprintImplementableEvent, Category = "Deploy")
	void OnLoadoutUpdated(const FBFLoadout& Loadout);

protected:
	/** All classes shipped with the game. Assigned on the Blueprint. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	TArray<TObjectPtr<UBFSoldierClassDataAsset>> AllClasses;

private:
	FBFLoadout PendingLoadout;

	void PushLoadoutToPlayerState();
};
