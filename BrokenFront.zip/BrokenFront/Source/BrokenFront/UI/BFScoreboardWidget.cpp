#include "UI/BFScoreboardWidget.h"

#include "Gameplay/BFGameState.h"
#include "GameFramework/PlayerController.h"

void UBFScoreboardWidget::RefreshScoreboard()
{
	IroncladRows.Reset();
	AshguardRows.Reset();

	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	if (!GS)
	{
		return;
	}

	const APlayerState* LocalPS = GetOwningPlayerState();

	for (APlayerState* PlayerState : GS->PlayerArray)
	{
		const ABFPlayerState* PS = Cast<ABFPlayerState>(PlayerState);
		if (!PS)
		{
			continue;
		}

		FBFScoreboardRow Row;
		Row.PlayerName = PS->GetPlayerName();
		Row.Team = PS->GetTeam();
		Row.SquadId = PS->GetSquadId();
		Row.SoldierClass = PS->GetSoldierClassType();
		Row.Record = PS->GetMatchRecord();
		Row.Ping = FMath::RoundToInt(PS->GetPingInMilliseconds());
		Row.bIsLocalPlayer = (PlayerState == LocalPS);

		if (Row.Team == EBFTeam::Ironclad)
		{
			IroncladRows.Add(Row);
		}
		else if (Row.Team == EBFTeam::Ashguard)
		{
			AshguardRows.Add(Row);
		}
	}

	auto SortByScore = [](TArray<FBFScoreboardRow>& Rows)
	{
		Rows.Sort([](const FBFScoreboardRow& A, const FBFScoreboardRow& B)
		{
			if (A.Record.Score != B.Record.Score)
			{
				return A.Record.Score > B.Record.Score;
			}
			return A.Record.Kills > B.Record.Kills;
		});
	};

	SortByScore(IroncladRows);
	SortByScore(AshguardRows);
}

int32 UBFScoreboardWidget::GetTeamScore(EBFTeam Team) const
{
	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	return GS ? GS->GetTeamScore(Team) : 0;
}

float UBFScoreboardWidget::GetTeamTickets(EBFTeam Team) const
{
	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	return GS ? GS->GetTickets(Team) : 0.f;
}

EBFTeam UBFScoreboardWidget::GetWinningTeam() const
{
	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	return GS ? GS->GetWinningTeam() : EBFTeam::Neutral;
}

bool UBFScoreboardWidget::IsMatchOver() const
{
	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	return GS && GS->GetMatchPhase() == EBFMatchPhase::PostMatch;
}

int32 UBFScoreboardWidget::GetLocalMatchXP() const
{
	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	return PS ? PS->GetMatchXP() : 0;
}
