// Copyright (c) Broken Front. Fictional setting, no real-world factions.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "BFSettingsWidget.generated.h"

class UBFGameSettings;

/**
 * Options screen backing logic: Graphics / Audio / Controls / Gameplay.
 *
 * Works on a pending copy so the player can cancel. Audio is applied live while
 * dragging a slider (you need to hear it), everything else waits for Apply.
 */
UCLASS(Abstract)
class BROKENFRONT_API UBFSettingsWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	/** The working copy the widgets bind to. Never null after NativeConstruct. */
	UFUNCTION(BlueprintPure, Category = "Settings") UBFGameSettings* GetPending() const { return Pending; }

	UFUNCTION(BlueprintCallable, Category = "Settings") void Apply();
	UFUNCTION(BlueprintCallable, Category = "Settings") void Cancel();
	UFUNCTION(BlueprintCallable, Category = "Settings") void ResetDefaults();

	/** Call after moving any audio slider so the change is audible immediately. */
	UFUNCTION(BlueprintCallable, Category = "Settings") void PreviewAudio();

	UFUNCTION(BlueprintCallable, Category = "Settings") void SetPreset(EBFQualityPreset Preset);

	UFUNCTION(BlueprintPure, Category = "Settings") TArray<FIntPoint> GetResolutions() const;
	UFUNCTION(BlueprintPure, Category = "Settings") FText FormatResolution(FIntPoint Res) const;

	/** Rebinding: the Blueprint captures a key press and passes it here. */
	UFUNCTION(BlueprintCallable, Category = "Settings") void RebindKey(FName ActionName, const FKey& NewKey, bool bSecondary);

	UFUNCTION(BlueprintPure, Category = "Settings") FText GetBindingLabel(FName ActionName, bool bSecondary) const;

	UFUNCTION(BlueprintPure, Category = "Settings") bool HasUnappliedChanges() const { return bDirty; }

	UFUNCTION(BlueprintCallable, Category = "Settings") void MarkDirty() { bDirty = true; }

	UFUNCTION(BlueprintImplementableEvent, Category = "Settings") void OnSettingsRefreshed();

protected:
	UBFGameSettings* GetLive() const;
	void CopyInto(UBFGameSettings* Target, const UBFGameSettings* Source) const;

	UPROPERTY(Transient, BlueprintReadOnly, Category = "Settings") TObjectPtr<UBFGameSettings> Pending;

	bool bDirty = false;
};
