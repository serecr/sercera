#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "Gameplay/BFPlayerState.h"
#include "BFScoreboardWidget.generated.h"

/** One scoreboard row, flattened for easy Blueprint binding. */
USTRUCT(BlueprintType)
struct FBFScoreboardRow
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly) FString PlayerName;
	UPROPERTY(BlueprintReadOnly) EBFTeam Team = EBFTeam::Neutral;
	UPROPERTY(BlueprintReadOnly) int32 SquadId = INDEX_NONE;
	UPROPERTY(BlueprintReadOnly) EBFSoldierClass SoldierClass = EBFSoldierClass::Rifleman;
	UPROPERTY(BlueprintReadOnly) FBFMatchRecord Record;
	UPROPERTY(BlueprintReadOnly) int32 Ping = 0;
	UPROPERTY(BlueprintReadOnly) bool bIsLocalPlayer = false;
};

/** End-of-match and in-match scoreboard, sorted by score within each team. */
UCLASS(Abstract)
class BROKENFRONT_API UBFScoreboardWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "Scoreboard") void RefreshScoreboard();

	UFUNCTION(BlueprintPure, Category = "Scoreboard") const TArray<FBFScoreboardRow>& GetIroncladRows() const { return IroncladRows; }
	UFUNCTION(BlueprintPure, Category = "Scoreboard") const TArray<FBFScoreboardRow>& GetAshguardRows() const { return AshguardRows; }
	UFUNCTION(BlueprintPure, Category = "Scoreboard") int32 GetTeamScore(EBFTeam Team) const;
	UFUNCTION(BlueprintPure, Category = "Scoreboard") float GetTeamTickets(EBFTeam Team) const;
	UFUNCTION(BlueprintPure, Category = "Scoreboard") EBFTeam GetWinningTeam() const;
	UFUNCTION(BlueprintPure, Category = "Scoreboard") bool IsMatchOver() const;

	/** XP breakdown for the post-match screen. */
	UFUNCTION(BlueprintPure, Category = "Scoreboard") int32 GetLocalMatchXP() const;

private:
	TArray<FBFScoreboardRow> IroncladRows;
	TArray<FBFScoreboardRow> AshguardRows;
};
