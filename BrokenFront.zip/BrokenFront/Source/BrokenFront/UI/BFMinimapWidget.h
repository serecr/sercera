#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "BFMinimapWidget.generated.h"

class ABFCharacter;

/** One thing to draw on the tactical map. */
USTRUCT(BlueprintType)
struct FBFMinimapMarker
{
	GENERATED_BODY()

	/** Normalised widget-space position, -1..1 on both axes. */
	UPROPERTY(BlueprintReadOnly) FVector2D NormalisedPosition = FVector2D::ZeroVector;
	UPROPERTY(BlueprintReadOnly) FName MarkerType = NAME_None;
	UPROPERTY(BlueprintReadOnly) EBFTeam Team = EBFTeam::Neutral;
	UPROPERTY(BlueprintReadOnly) float Rotation = 0.f;
	UPROPERTY(BlueprintReadOnly) FText Label;
	UPROPERTY(BlueprintReadOnly) float Progress = 0.f;
	/** Squadmates draw bigger and brighter than generic allies. */
	UPROPERTY(BlueprintReadOnly) bool bIsSquad = false;
};

/**
 * Tactical minimap. Shows allies, squad, sectors, capture progress, the frontline
 * and objectives. Enemies are NOT shown continuously: only what the drone is
 * currently spotting or what a Scout has marked, and only for a short while.
 * That restraint is the whole point of the map.
 */
UCLASS(Abstract)
class BROKENFRONT_API UBFMinimapWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	void SetTrackedPawn(ABFCharacter* Pawn) { TrackedPawn = Pawn; }

	UFUNCTION(BlueprintPure, Category = "Minimap") const TArray<FBFMinimapMarker>& GetMarkers() const { return Markers; }

	/** 0..1 position of the frontline along the ladder, for the front indicator bar. */
	UFUNCTION(BlueprintPure, Category = "Minimap") float GetFrontlinePosition() const { return FrontlinePosition; }

	UFUNCTION(BlueprintPure, Category = "Minimap") float GetViewRadius() const { return ViewRadius; }

	UFUNCTION(BlueprintCallable, Category = "Minimap") void SetViewRadius(float NewRadius) { ViewRadius = FMath::Clamp(NewRadius, 1500.f, 60000.f); }

	/** Server-fed spot marks live for a few seconds, then fade. */
	UFUNCTION(BlueprintCallable, Category = "Minimap") void AddSpotMark(const FVector& WorldLocation, EBFTeam Team, float Duration = 6.f);

protected:
	/** World-space radius the minimap covers, in centimetres. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float ViewRadius = 12000.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	float RefreshInterval = 0.2f;

	/** Rotate the map with the player instead of keeping north up. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	bool bRotateWithPlayer = true;

private:
	struct FSpotMark
	{
		FVector Location = FVector::ZeroVector;
		EBFTeam Team = EBFTeam::Neutral;
		float Remaining = 0.f;
	};

	UPROPERTY() TWeakObjectPtr<ABFCharacter> TrackedPawn;

	TArray<FBFMinimapMarker> Markers;
	TArray<FSpotMark> SpotMarks;
	float RefreshTimer = 0.f;
	float FrontlinePosition = 0.5f;

	void RebuildMarkers();
	bool WorldToMinimap(const FVector& WorldLocation, const FVector& Origin, float ViewYaw, FVector2D& OutNormalised) const;
};
