#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "BFServerBrowserWidget.generated.h"

/** Filters applied to the server list. */
USTRUCT(BlueprintType)
struct FBFServerFilter
{
	GENERATED_BODY()

	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bHideEmpty = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bHideFull = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) bool bLowPingOnly = false;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) int32 MaxPing = 90;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FString GameModeFilter;
	UPROPERTY(EditAnywhere, BlueprintReadWrite) FString MapFilter;
};

/** Server browser list with filtering and sorting. */
UCLASS(Abstract)
class BROKENFRONT_API UBFServerBrowserWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	UFUNCTION(BlueprintCallable, Category = "Servers") void Refresh();
	UFUNCTION(BlueprintCallable, Category = "Servers") void SetFilter(const FBFServerFilter& NewFilter);
	UFUNCTION(BlueprintCallable, Category = "Servers") void SortBy(FName ColumnName, bool bAscending);

	UFUNCTION(BlueprintPure, Category = "Servers") const TArray<FBFServerEntry>& GetFilteredServers() const { return FilteredServers; }
	UFUNCTION(BlueprintPure, Category = "Servers") bool IsSearching() const { return bSearching; }

	UFUNCTION(BlueprintImplementableEvent, Category = "Servers") void OnServerListUpdated();

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Servers") FBFServerFilter Filter;

	UFUNCTION() void HandleServerListReady(const TArray<FBFServerEntry>& Servers);

private:
	TArray<FBFServerEntry> AllServers;
	TArray<FBFServerEntry> FilteredServers;
	bool bSearching = false;

	void ApplyFilter();
};
