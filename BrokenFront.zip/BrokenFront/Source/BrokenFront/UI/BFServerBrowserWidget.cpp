#include "UI/BFServerBrowserWidget.h"

#include "Gameplay/BFGameInstance.h"

void UBFServerBrowserWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		GI->OnServerListReady.AddDynamic(this, &UBFServerBrowserWidget::HandleServerListReady);
	}

	Refresh();
}

void UBFServerBrowserWidget::Refresh()
{
	if (UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		bSearching = true;
		GI->RefreshServerList();
	}
}

void UBFServerBrowserWidget::HandleServerListReady(const TArray<FBFServerEntry>& Servers)
{
	bSearching = false;
	AllServers = Servers;
	ApplyFilter();
}

void UBFServerBrowserWidget::SetFilter(const FBFServerFilter& NewFilter)
{
	Filter = NewFilter;
	ApplyFilter();
}

void UBFServerBrowserWidget::ApplyFilter()
{
	FilteredServers.Reset();

	for (const FBFServerEntry& Entry : AllServers)
	{
		if (Filter.bHideEmpty && Entry.PlayerCount == 0) { continue; }
		if (Filter.bHideFull && Entry.PlayerCount >= Entry.MaxPlayers) { continue; }
		if (Filter.bLowPingOnly && Entry.PingMs > Filter.MaxPing) { continue; }
		if (!Filter.GameModeFilter.IsEmpty() && !Entry.GameMode.Contains(Filter.GameModeFilter)) { continue; }
		if (!Filter.MapFilter.IsEmpty() && !Entry.MapName.Contains(Filter.MapFilter)) { continue; }

		FilteredServers.Add(Entry);
	}

	// Default ordering: most populated first, ties broken by ping.
	FilteredServers.Sort([](const FBFServerEntry& A, const FBFServerEntry& B)
	{
		if (A.PlayerCount != B.PlayerCount)
		{
			return A.PlayerCount > B.PlayerCount;
		}
		return A.PingMs < B.PingMs;
	});

	OnServerListUpdated();
}

void UBFServerBrowserWidget::SortBy(FName ColumnName, bool bAscending)
{
	FilteredServers.Sort([ColumnName, bAscending](const FBFServerEntry& A, const FBFServerEntry& B)
	{
		int32 Comparison = 0;

		if (ColumnName == TEXT("Name"))          { Comparison = A.ServerName.Compare(B.ServerName); }
		else if (ColumnName == TEXT("Players"))  { Comparison = A.PlayerCount - B.PlayerCount; }
		else if (ColumnName == TEXT("Ping"))     { Comparison = A.PingMs - B.PingMs; }
		else if (ColumnName == TEXT("Map"))      { Comparison = A.MapName.Compare(B.MapName); }
		else if (ColumnName == TEXT("Mode"))     { Comparison = A.GameMode.Compare(B.GameMode); }
		else if (ColumnName == TEXT("Frontline")){ Comparison = A.FrontlineState.Compare(B.FrontlineState); }

		return bAscending ? Comparison < 0 : Comparison > 0;
	});

	OnServerListUpdated();
}
