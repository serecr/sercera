#include "UI/BFHUDWidget.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "Core/BFInteractable.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"
#include "Sectors/BFObjective.h"
#include "Systems/BFRadioComponent.h"
#include "UI/BFMinimapWidget.h"
#include "Weapons/BFInventoryComponent.h"
#include "Weapons/BFWeaponBase.h"
#include "Data/BFWeaponDataAsset.h"

void UBFHUDWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (APlayerController* PC = GetOwningPlayer())
	{
		BindToPawn(Cast<ABFCharacter>(PC->GetPawn()));
	}
}

void UBFHUDWidget::BindToPawn(ABFCharacter* NewPawn)
{
	// Unbind the old pawn so stale delegates never fire into a dead widget state.
	if (ABFCharacter* Old = BoundPawn.Get())
	{
		if (UBFHealthComponent* Health = Old->GetHealthComponent())
		{
			Health->OnHealthChanged.RemoveDynamic(this, &UBFHUDWidget::HandleHealthChanged);
			Health->OnDownedStateChanged.RemoveDynamic(this, &UBFHUDWidget::HandleDownedChanged);
		}
		if (UBFInventoryComponent* Inventory = Old->GetInventory())
		{
			Inventory->OnWeaponChanged.RemoveDynamic(this, &UBFHUDWidget::HandleWeaponChanged);
		}
		if (UBFRadioComponent* Radio = Old->GetRadio())
		{
			Radio->OnRadioReceived.RemoveDynamic(this, &UBFHUDWidget::HandleRadioReceived);
		}
	}

	if (ABFWeaponBase* OldWeapon = BoundWeapon.Get())
	{
		OldWeapon->OnAmmoChanged.RemoveDynamic(this, &UBFHUDWidget::HandleAmmoChanged);
	}

	BoundPawn = NewPawn;
	BoundWeapon = nullptr;

	if (!NewPawn)
	{
		return;
	}

	if (UBFHealthComponent* Health = NewPawn->GetHealthComponent())
	{
		Health->OnHealthChanged.AddDynamic(this, &UBFHUDWidget::HandleHealthChanged);
		Health->OnDownedStateChanged.AddDynamic(this, &UBFHUDWidget::HandleDownedChanged);
		CachedHealthPercent = Health->GetHealthPercent();
		bCachedDowned = Health->IsDowned();
	}

	if (UBFInventoryComponent* Inventory = NewPawn->GetInventory())
	{
		Inventory->OnWeaponChanged.AddDynamic(this, &UBFHUDWidget::HandleWeaponChanged);
		HandleWeaponChanged(Inventory->GetCurrentWeapon());
	}

	if (UBFRadioComponent* Radio = NewPawn->GetRadio())
	{
		Radio->OnRadioReceived.AddDynamic(this, &UBFHUDWidget::HandleRadioReceived);
	}

	if (Minimap)
	{
		Minimap->SetTrackedPawn(NewPawn);
	}
}

void UBFHUDWidget::HandleHealthChanged(float /*NewHealth*/, float /*Delta*/, AActor* /*Instigator*/)
{
	if (const ABFCharacter* Pawn = BoundPawn.Get())
	{
		if (const UBFHealthComponent* Health = Pawn->GetHealthComponent())
		{
			CachedHealthPercent = Health->GetHealthPercent();
		}
	}
}

void UBFHUDWidget::HandleDownedChanged(bool bDowned)
{
	bCachedDowned = bDowned;
}

void UBFHUDWidget::HandleWeaponChanged(ABFWeaponBase* NewWeapon)
{
	if (ABFWeaponBase* Old = BoundWeapon.Get())
	{
		Old->OnAmmoChanged.RemoveDynamic(this, &UBFHUDWidget::HandleAmmoChanged);
	}

	BoundWeapon = NewWeapon;

	if (!NewWeapon)
	{
		CachedClipAmmo = 0;
		CachedReserveAmmo = 0;
		CachedWeaponName = FText::GetEmpty();
		return;
	}

	NewWeapon->OnAmmoChanged.AddDynamic(this, &UBFHUDWidget::HandleAmmoChanged);
	CachedClipAmmo = NewWeapon->GetClipAmmo();
	CachedReserveAmmo = NewWeapon->GetReserveAmmo();
	CachedWeaponName = NewWeapon->GetDisplayName();
	CachedFireMode = NewWeapon->GetFireMode();
}

void UBFHUDWidget::HandleAmmoChanged(int32 ClipAmmo, int32 ReserveAmmo)
{
	CachedClipAmmo = ClipAmmo;
	CachedReserveAmmo = ReserveAmmo;
}

void UBFHUDWidget::HandleRadioReceived(EBFRadioCommand Command, EBFRadioChannel Channel, const FString& SenderName, FVector /*WorldLocation*/)
{
	FText Subtitle;
	if (const ABFCharacter* Pawn = BoundPawn.Get())
	{
		if (const UBFRadioComponent* Radio = Pawn->GetRadio())
		{
			Subtitle = Radio->GetSubtitleFor(Command);
		}
	}

	OnRadioMessage(Subtitle, SenderName, Channel);
}

void UBFHUDWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	// Fast values every frame, everything else on a quarter-second cadence.
	if (const ABFCharacter* Pawn = BoundPawn.Get())
	{
		CachedStaminaPercent = Pawn->GetStaminaPercent();

		if (const UBFHealthComponent* Health = Pawn->GetHealthComponent())
		{
			CachedBleedOutPercent = bCachedDowned ? FMath::Clamp(Health->GetBleedOutRemaining() / 35.f, 0.f, 1.f) : 0.f;
		}
	}

	if (const ABFWeaponBase* Weapon = BoundWeapon.Get())
	{
		bCachedReloading = Weapon->IsReloading();
		CachedFireMode = Weapon->GetFireMode();
	}

	SlowRefreshTimer += InDeltaTime;
	if (SlowRefreshTimer >= SlowRefreshInterval)
	{
		SlowRefreshTimer = 0.f;
		RefreshSlowData();
		RefreshInteractionPrompt();
	}
}

void UBFHUDWidget::RefreshSlowData()
{
	const ABFCharacter* Pawn = BoundPawn.Get();
	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	if (!GS)
	{
		return;
	}

	CachedMatchTime = GS->GetMatchTimeRemaining();

	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	CachedTeam = PS ? PS->GetTeam() : EBFTeam::Neutral;
	CachedBuildResources = GS->GetBuildResources(CachedTeam);

	// Current sector from the replicated snapshot list.
	if (Pawn)
	{
		const FBFSectorSnapshot Snapshot = GS->GetSectorSnapshotAt(Pawn->GetActorLocation());

		if (Snapshot.SectorId != CachedSectorId)
		{
			CachedSectorId = Snapshot.SectorId;
			CachedSectorName = Snapshot.DisplayName;
			OnSectorChanged(CachedSectorName, Snapshot.Owner);
		}

		CachedSectorState = Snapshot.State;
		CachedCapturePercent = FMath::Abs(Snapshot.CaptureProgress);
	}

	// Primary objective: first active one for the team.
	const TArray<ABFObjective*> Objectives = GS->GetActiveObjectivesForTeam(CachedTeam);
	if (Objectives.Num() > 0 && Objectives[0])
	{
		CachedObjectiveText = Objectives[0]->GetObjectiveText();
		CachedObjectiveProgress = Objectives[0]->GetProgress();
	}
	else
	{
		CachedObjectiveText = FText::GetEmpty();
		CachedObjectiveProgress = 0.f;
	}

	// Squad roster.
	CachedSquadNames.Reset();
	if (PS && PS->GetSquadId() != INDEX_NONE)
	{
		for (APlayerState* Other : GS->PlayerArray)
		{
			const ABFPlayerState* OtherBF = Cast<ABFPlayerState>(Other);
			if (OtherBF && OtherBF->GetTeam() == CachedTeam && OtherBF->GetSquadId() == PS->GetSquadId())
			{
				CachedSquadNames.Add(FText::FromString(OtherBF->GetPlayerName()));
			}
		}
	}
}

void UBFHUDWidget::RefreshInteractionPrompt()
{
	CachedInteractPrompt = FText::GetEmpty();

	const ABFCharacter* Pawn = BoundPawn.Get();
	if (!Pawn)
	{
		return;
	}

	FVector Start;
	FRotator Rotation;
	Pawn->GetAimTransform(Start, Rotation);
	const FVector End = Start + Rotation.Vector() * 220.f;

	FCollisionQueryParams Params(SCENE_QUERY_STAT(BFHUDInteract), false, Pawn);
	FHitResult Hit;
	if (GetWorld()->LineTraceSingleByChannel(Hit, Start, End, BF_TRACE_INTERACT, Params))
	{
		AActor* HitActor = Hit.GetActor();
		if (HitActor && HitActor->Implements<UBFInteractable>())
		{
			ABFCharacter* MutablePawn = const_cast<ABFCharacter*>(Pawn);
			if (IBFInteractable::Execute_CanInteract(HitActor, MutablePawn))
			{
				CachedInteractPrompt = IBFInteractable::Execute_GetInteractionPrompt(HitActor, MutablePawn);
			}
		}
	}
}
