#include "UI/BFDeployWidget.h"

#include "Data/BFSoldierClassDataAsset.h"
#include "Data/BFWeaponDataAsset.h"
#include "Frontline/BFFrontlineManager.h"
#include "Gameplay/BFGameMode.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerController.h"
#include "Gameplay/BFPlayerState.h"
#include "Sectors/BFSpawnPoint.h"
#include "Systems/BFSpawnManager.h"

void UBFDeployWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// Seed from whatever the player last used this session.
	if (const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>())
	{
		PendingLoadout = PS->GetSelectedLoadout();
	}

	if (!PendingLoadout.SoldierClass && AllClasses.Num() > 0)
	{
		SelectClass(AllClasses[0]);
	}
}

TArray<UBFSoldierClassDataAsset*> UBFDeployWidget::GetSelectableClasses() const
{
	TArray<UBFSoldierClassDataAsset*> Result;

	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	const int32 Level = PS ? PS->GetCareerLevel() : 1;
	const EBFTeam Team = PS ? PS->GetTeam() : EBFTeam::Neutral;

	const ABFGameMode* GM = GetWorld() ? GetWorld()->GetAuthGameMode<ABFGameMode>() : nullptr;

	for (const TObjectPtr<UBFSoldierClassDataAsset>& ClassAsset : AllClasses)
	{
		if (!ClassAsset || ClassAsset->UnlockLevel > Level)
		{
			continue;
		}

		// On a listen server we can check the live limit; on a client the server
		// re-validates anyway, so show it and let the server refuse.
		if (GM && !GM->CanTeamTakeClass(Team, ClassAsset))
		{
			continue;
		}

		Result.Add(ClassAsset);
	}

	return Result;
}

TArray<UBFWeaponDataAsset*> UBFDeployWidget::GetSelectablePrimaries() const
{
	TArray<UBFWeaponDataAsset*> Result;
	if (!PendingLoadout.SoldierClass)
	{
		return Result;
	}

	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	const int32 Level = PS ? PS->GetCareerLevel() : 1;

	for (const TSoftObjectPtr<UBFWeaponDataAsset>& Entry : PendingLoadout.SoldierClass->AllowedPrimaries)
	{
		if (UBFWeaponDataAsset* Weapon = Entry.LoadSynchronous())
		{
			if (Weapon->UnlockLevel <= Level)
			{
				Result.Add(Weapon);
			}
		}
	}
	return Result;
}

TArray<UBFWeaponDataAsset*> UBFDeployWidget::GetSelectableSecondaries() const
{
	TArray<UBFWeaponDataAsset*> Result;
	if (!PendingLoadout.SoldierClass)
	{
		return Result;
	}

	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	const int32 Level = PS ? PS->GetCareerLevel() : 1;

	for (const TSoftObjectPtr<UBFWeaponDataAsset>& Entry : PendingLoadout.SoldierClass->AllowedSecondaries)
	{
		if (UBFWeaponDataAsset* Weapon = Entry.LoadSynchronous())
		{
			if (Weapon->UnlockLevel <= Level)
			{
				Result.Add(Weapon);
			}
		}
	}
	return Result;
}

void UBFDeployWidget::SelectClass(UBFSoldierClassDataAsset* ClassAsset)
{
	if (!ClassAsset)
	{
		return;
	}

	PendingLoadout.SoldierClass = ClassAsset;

	// Reset weapon choices to the first legal option for the new class.
	const TArray<UBFWeaponDataAsset*> Primaries = GetSelectablePrimaries();
	PendingLoadout.Primary = Primaries.Num() > 0 ? Primaries[0] : nullptr;

	const TArray<UBFWeaponDataAsset*> Secondaries = GetSelectableSecondaries();
	PendingLoadout.Secondary = Secondaries.Num() > 0 ? Secondaries[0] : nullptr;

	PendingLoadout.Equipment = ClassAsset->AllowedEquipment.Num() > 0 ? ClassAsset->AllowedEquipment[0] : nullptr;

	PushLoadoutToPlayerState();
}

void UBFDeployWidget::SelectPrimary(UBFWeaponDataAsset* Weapon)
{
	if (GetSelectablePrimaries().Contains(Weapon))
	{
		PendingLoadout.Primary = Weapon;
		PushLoadoutToPlayerState();
	}
}

void UBFDeployWidget::SelectSecondary(UBFWeaponDataAsset* Weapon)
{
	if (GetSelectableSecondaries().Contains(Weapon))
	{
		PendingLoadout.Secondary = Weapon;
		PushLoadoutToPlayerState();
	}
}

void UBFDeployWidget::SelectEquipment(int32 EquipmentIndex)
{
	if (PendingLoadout.SoldierClass && PendingLoadout.SoldierClass->AllowedEquipment.IsValidIndex(EquipmentIndex))
	{
		PendingLoadout.Equipment = PendingLoadout.SoldierClass->AllowedEquipment[EquipmentIndex];
		PushLoadoutToPlayerState();
	}
}

void UBFDeployWidget::SelectUniform(FName UniformId)
{
	PendingLoadout.UniformId = UniformId;
	PushLoadoutToPlayerState();
}

void UBFDeployWidget::PushLoadoutToPlayerState()
{
	if (ABFPlayerController* PC = Cast<ABFPlayerController>(GetOwningPlayer()))
	{
		PC->SubmitLoadout(PendingLoadout);
	}
	OnLoadoutUpdated(PendingLoadout);
}

void UBFDeployWidget::RequestTeam(EBFTeam Team)
{
	if (ABFPlayerController* PC = Cast<ABFPlayerController>(GetOwningPlayer()))
	{
		PC->ServerRequestTeamChange(Team);
	}
}

bool UBFDeployWidget::CanDeployNow() const
{
	if (!PendingLoadout.IsValid())
	{
		return false;
	}

	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	if (!GS || GS->GetMatchPhase() == EBFMatchPhase::PostMatch)
	{
		return false;
	}

	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	return PS && PS->GetTeam() != EBFTeam::Neutral;
}

TArray<ABFSpawnPoint*> UBFDeployWidget::GetAvailableSpawns() const
{
	const ABFPlayerState* PS = GetOwningPlayerState<ABFPlayerState>();
	if (!PS)
	{
		return {};
	}

	if (const UBFSpawnManager* Manager = UBFSpawnManager::Get(GetWorld()))
	{
		return Manager->GetAvailableSpawnsForTeam(PS->GetTeam());
	}
	return {};
}

FText UBFDeployWidget::GetFrontlineSummary() const
{
	if (const ABFFrontlineManager* Frontline = ABFFrontlineManager::Get(GetWorld()))
	{
		return FText::FromString(Frontline->GetFrontlineStateString());
	}
	return FText::GetEmpty();
}

void UBFDeployWidget::Deploy(EBFSpawnKind PreferredKind)
{
	if (!CanDeployNow())
	{
		return;
	}

	if (ABFPlayerController* PC = Cast<ABFPlayerController>(GetOwningPlayer()))
	{
		PC->RequestDeploy(PreferredKind);
	}
}
