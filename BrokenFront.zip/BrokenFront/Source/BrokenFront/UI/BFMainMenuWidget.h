#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "BFMainMenuWidget.generated.h"

/**
 * Front end. Everything a menu button needs to actually do something lives here,
 * so the Blueprint is pure presentation: dark, military, minimal, cinematic.
 *
 *         BROKEN FRONT
 *        [ PLAY ]
 *        [ SERVERS ]
 *        [ TRAINING ]
 *        [ LOADOUT ]
 *        [ SETTINGS ]
 *        [ CREDITS ]
 *        [ EXIT ]
 */
UCLASS(Abstract)
class BROKENFRONT_API UBFMainMenuWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	/** Quick play: hosts a listen server on the default map. */
	UFUNCTION(BlueprintCallable, Category = "Menu") void Play();

	/** Opens the server browser panel; the Blueprint handles the panel swap. */
	UFUNCTION(BlueprintCallable, Category = "Menu") void RefreshServers();

	UFUNCTION(BlueprintCallable, Category = "Menu") void JoinServer(const FBFServerEntry& Entry);

	/** Training map: single player, no bots required, weather and time controllable. */
	UFUNCTION(BlueprintCallable, Category = "Menu") void StartTraining();

	UFUNCTION(BlueprintCallable, Category = "Menu") void HostDedicatedInfoCopy();

	UFUNCTION(BlueprintCallable, Category = "Menu") void QuitGame();

	UFUNCTION(BlueprintPure, Category = "Menu") FText GetPlayerNickname() const;
	UFUNCTION(BlueprintPure, Category = "Menu") int32 GetPlayerLevel() const;
	UFUNCTION(BlueprintPure, Category = "Menu") float GetLevelProgressPercent() const;
	UFUNCTION(BlueprintPure, Category = "Menu") FBFProfileStats GetProfileStats() const;

	UFUNCTION(BlueprintCallable, Category = "Menu") void SetPlayerNickname(const FString& NewNickname);

protected:
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	FName DefaultMapName = TEXT("BF_BrokenRidge");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	FName TrainingMapName = TEXT("BF_Training");

	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "Config")
	int32 DefaultMaxPlayers = 64;
};
