#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Core/BFTypes.h"
#include "BFHUDWidget.generated.h"

class ABFCharacter;
class ABFGameState;
class ABFWeaponBase;
class ABFObjective;
class UBFMinimapWidget;

/**
 * Minimal tactical HUD. C++ gathers and caches the data; the Blueprint child
 * decides how it looks. Deliberately sparse: health, ammo, sector, objective,
 * squad, minimap. No kill feed clutter, no damage numbers.
 */
UCLASS(Abstract)
class BROKENFRONT_API UBFHUDWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

	/** Called by the controller on possess / unpossess. */
	void BindToPawn(ABFCharacter* NewPawn);

	// ---------- Data the Blueprint binds to ----------
	UFUNCTION(BlueprintPure, Category = "HUD") float GetHealthPercent() const { return CachedHealthPercent; }
	UFUNCTION(BlueprintPure, Category = "HUD") float GetStaminaPercent() const { return CachedStaminaPercent; }
	UFUNCTION(BlueprintPure, Category = "HUD") bool IsDowned() const { return bCachedDowned; }
	UFUNCTION(BlueprintPure, Category = "HUD") float GetBleedOutPercent() const { return CachedBleedOutPercent; }
	UFUNCTION(BlueprintPure, Category = "HUD") int32 GetClipAmmo() const { return CachedClipAmmo; }
	UFUNCTION(BlueprintPure, Category = "HUD") int32 GetReserveAmmo() const { return CachedReserveAmmo; }
	UFUNCTION(BlueprintPure, Category = "HUD") FText GetWeaponName() const { return CachedWeaponName; }
	UFUNCTION(BlueprintPure, Category = "HUD") EBFFireMode GetFireMode() const { return CachedFireMode; }
	UFUNCTION(BlueprintPure, Category = "HUD") bool IsReloading() const { return bCachedReloading; }
	UFUNCTION(BlueprintPure, Category = "HUD") FText GetSectorName() const { return CachedSectorName; }
	UFUNCTION(BlueprintPure, Category = "HUD") EBFSectorState GetSectorState() const { return CachedSectorState; }
	UFUNCTION(BlueprintPure, Category = "HUD") float GetSectorCapturePercent() const { return CachedCapturePercent; }
	UFUNCTION(BlueprintPure, Category = "HUD") bool IsSectorContested() const { return CachedSectorState == EBFSectorState::Contested; }
	UFUNCTION(BlueprintPure, Category = "HUD") FText GetObjectiveText() const { return CachedObjectiveText; }
	UFUNCTION(BlueprintPure, Category = "HUD") float GetObjectiveProgress() const { return CachedObjectiveProgress; }
	UFUNCTION(BlueprintPure, Category = "HUD") EBFTeam GetTeam() const { return CachedTeam; }
	UFUNCTION(BlueprintPure, Category = "HUD") int32 GetBuildResources() const { return CachedBuildResources; }
	UFUNCTION(BlueprintPure, Category = "HUD") float GetMatchTimeRemaining() const { return CachedMatchTime; }
	UFUNCTION(BlueprintPure, Category = "HUD") FText GetInteractionPrompt() const { return CachedInteractPrompt; }

	/** Squad roster for the small corner list. */
	UFUNCTION(BlueprintPure, Category = "HUD") const TArray<FText>& GetSquadNames() const { return CachedSquadNames; }

	/** Fires when the player's sector changes, for a subtle on-screen announcement. */
	UFUNCTION(BlueprintImplementableEvent, Category = "HUD")
	void OnSectorChanged(const FText& NewSectorName, EBFTeam Owner);

	/** Fires when a radio message arrives, so the Blueprint can show a subtitle. */
	UFUNCTION(BlueprintImplementableEvent, Category = "HUD")
	void OnRadioMessage(const FText& Subtitle, const FString& SenderName, EBFRadioChannel Channel);

protected:
	UPROPERTY(EditAnywhere, BlueprintReadWrite, meta = (BindWidgetOptional), Category = "HUD")
	TObjectPtr<UBFMinimapWidget> Minimap;

	/** How often the slower HUD data refreshes. Health and ammo update instantly via delegates. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadWrite, Category = "HUD")
	float SlowRefreshInterval = 0.25f;

	UFUNCTION() void HandleHealthChanged(float NewHealth, float Delta, AActor* Instigator);
	UFUNCTION() void HandleDownedChanged(bool bDowned);
	UFUNCTION() void HandleWeaponChanged(ABFWeaponBase* NewWeapon);
	UFUNCTION() void HandleAmmoChanged(int32 ClipAmmo, int32 ReserveAmmo);
	UFUNCTION() void HandleRadioReceived(EBFRadioCommand Command, EBFRadioChannel Channel, const FString& SenderName, FVector WorldLocation);

private:
	UPROPERTY() TWeakObjectPtr<ABFCharacter> BoundPawn;
	UPROPERTY() TWeakObjectPtr<ABFWeaponBase> BoundWeapon;

	float SlowRefreshTimer = 0.f;

	float CachedHealthPercent = 1.f;
	float CachedStaminaPercent = 1.f;
	float CachedBleedOutPercent = 0.f;
	bool bCachedDowned = false;
	int32 CachedClipAmmo = 0;
	int32 CachedReserveAmmo = 0;
	bool bCachedReloading = false;
	FText CachedWeaponName;
	EBFFireMode CachedFireMode = EBFFireMode::FullAuto;
	FText CachedSectorName;
	FName CachedSectorId = NAME_None;
	EBFSectorState CachedSectorState = EBFSectorState::Dormant;
	float CachedCapturePercent = 0.f;
	FText CachedObjectiveText;
	float CachedObjectiveProgress = 0.f;
	EBFTeam CachedTeam = EBFTeam::Neutral;
	int32 CachedBuildResources = 0;
	float CachedMatchTime = 0.f;
	FText CachedInteractPrompt;
	TArray<FText> CachedSquadNames;

	void RefreshSlowData();
	void RefreshInteractionPrompt();
};
