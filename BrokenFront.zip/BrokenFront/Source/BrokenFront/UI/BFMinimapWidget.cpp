#include "UI/BFMinimapWidget.h"

#include "Characters/BFCharacter.h"
#include "Characters/BFHealthComponent.h"
#include "EngineUtils.h"
#include "Frontline/BFFrontlineManager.h"
#include "Gameplay/BFGameState.h"
#include "Gameplay/BFPlayerState.h"
#include "Sectors/BFObjective.h"

void UBFMinimapWidget::AddSpotMark(const FVector& WorldLocation, EBFTeam Team, float Duration)
{
	FSpotMark Mark;
	Mark.Location = WorldLocation;
	Mark.Team = Team;
	Mark.Remaining = Duration;
	SpotMarks.Add(Mark);
}

void UBFMinimapWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	// Age out spot marks so enemy positions are never permanently known.
	for (int32 Index = SpotMarks.Num() - 1; Index >= 0; --Index)
	{
		SpotMarks[Index].Remaining -= InDeltaTime;
		if (SpotMarks[Index].Remaining <= 0.f)
		{
			SpotMarks.RemoveAtSwap(Index);
		}
	}

	RefreshTimer += InDeltaTime;
	if (RefreshTimer >= RefreshInterval)
	{
		RefreshTimer = 0.f;
		RebuildMarkers();
	}
}

bool UBFMinimapWidget::WorldToMinimap(const FVector& WorldLocation, const FVector& Origin, float ViewYaw, FVector2D& OutNormalised) const
{
	FVector Delta = WorldLocation - Origin;
	Delta.Z = 0.f;

	const float Distance = Delta.Size();
	if (Distance > ViewRadius)
	{
		// Clamp to the rim rather than dropping it: off-map objectives still matter.
		Delta = Delta.GetSafeNormal() * ViewRadius;
	}

	if (bRotateWithPlayer)
	{
		Delta = FRotator(0.f, -ViewYaw, 0.f).RotateVector(Delta);
	}

	OutNormalised = FVector2D(Delta.Y / ViewRadius, -Delta.X / ViewRadius);
	return Distance <= ViewRadius;
}

void UBFMinimapWidget::RebuildMarkers()
{
	Markers.Reset();

	const ABFCharacter* Pawn = TrackedPawn.Get();
	const ABFGameState* GS = GetWorld() ? GetWorld()->GetGameState<ABFGameState>() : nullptr;
	if (!Pawn || !GS)
	{
		return;
	}

	const FVector Origin = Pawn->GetActorLocation();
	const float ViewYaw = Pawn->GetActorRotation().Yaw;
	const ABFPlayerState* MyPS = Pawn->GetPlayerState<ABFPlayerState>();
	const EBFTeam MyTeam = MyPS ? MyPS->GetTeam() : EBFTeam::Neutral;
	const int32 MySquad = MyPS ? MyPS->GetSquadId() : INDEX_NONE;

	// --- Sectors and capture points ---
	for (const FBFSectorSnapshot& Snapshot : GS->GetSectorSnapshots())
	{
		FBFMinimapMarker Marker;
		if (!WorldToMinimap(Snapshot.WorldLocation, Origin, ViewYaw, Marker.NormalisedPosition))
		{
			// Keep frontline sectors visible on the rim; ignore far rear ones.
			if (!Snapshot.bIsFrontline)
			{
				continue;
			}
		}

		Marker.MarkerType = Snapshot.bIsFrontline ? TEXT("SectorFront") : TEXT("Sector");
		Marker.Team = Snapshot.Owner;
		Marker.Label = Snapshot.DisplayName;
		Marker.Progress = FMath::Abs(Snapshot.CaptureProgress);
		Markers.Add(Marker);
	}

	// --- Allies (never enemies) ---
	for (TActorIterator<ABFCharacter> It(GetWorld()); It; ++It)
	{
		const ABFCharacter* Other = *It;
		if (!Other || Other == Pawn || Other->GetTeam() != MyTeam)
		{
			continue;
		}

		if (const UBFHealthComponent* Health = Other->GetHealthComponent())
		{
			if (!Health->IsAlive())
			{
				continue;
			}

			// Downed allies get their own marker so medics can find them.
			if (Health->IsDowned())
			{
				FBFMinimapMarker Downed;
				if (WorldToMinimap(Other->GetActorLocation(), Origin, ViewYaw, Downed.NormalisedPosition))
				{
					Downed.MarkerType = TEXT("AllyDowned");
					Downed.Team = MyTeam;
					Markers.Add(Downed);
				}
				continue;
			}
		}

		FBFMinimapMarker Marker;
		if (!WorldToMinimap(Other->GetActorLocation(), Origin, ViewYaw, Marker.NormalisedPosition))
		{
			continue;
		}

		const ABFPlayerState* OtherPS = Other->GetPlayerState<ABFPlayerState>();
		Marker.bIsSquad = OtherPS && OtherPS->GetSquadId() == MySquad && MySquad != INDEX_NONE;
		Marker.MarkerType = Marker.bIsSquad ? TEXT("Squad") : TEXT("Ally");
		Marker.Team = MyTeam;
		Marker.Rotation = Other->GetActorRotation().Yaw - (bRotateWithPlayer ? ViewYaw : 0.f);
		if (Marker.bIsSquad && OtherPS)
		{
			Marker.Label = FText::FromString(OtherPS->GetPlayerName());
		}
		Markers.Add(Marker);
	}

	// --- Objectives ---
	for (const ABFObjective* Objective : GS->GetActiveObjectivesForTeam(MyTeam))
	{
		if (!Objective)
		{
			continue;
		}

		FBFMinimapMarker Marker;
		WorldToMinimap(Objective->GetActorLocation(), Origin, ViewYaw, Marker.NormalisedPosition);
		Marker.MarkerType = TEXT("Objective");
		Marker.Team = MyTeam;
		Marker.Label = Objective->GetObjectiveText();
		Marker.Progress = Objective->GetProgress();
		Markers.Add(Marker);
	}

	// --- Temporary enemy spot marks (drone / scout only) ---
	for (const FSpotMark& Mark : SpotMarks)
	{
		FBFMinimapMarker Marker;
		if (!WorldToMinimap(Mark.Location, Origin, ViewYaw, Marker.NormalisedPosition))
		{
			continue;
		}
		Marker.MarkerType = TEXT("EnemySpotted");
		Marker.Team = Mark.Team;
		Marker.Progress = FMath::Clamp(Mark.Remaining / 6.f, 0.f, 1.f); // fades out
		Markers.Add(Marker);
	}

	// --- Frontline indicator ---
	if (const ABFFrontlineManager* Frontline = ABFFrontlineManager::Get(GetWorld()))
	{
		const int32 Count = FMath::Max(1, Frontline->GetLadder().Num() - 1);
		const float Mid = (Frontline->GetIroncladFrontIndex() + Frontline->GetAshguardFrontIndex()) * 0.5f;
		FrontlinePosition = FMath::Clamp(Mid / Count, 0.f, 1.f);
	}
}
