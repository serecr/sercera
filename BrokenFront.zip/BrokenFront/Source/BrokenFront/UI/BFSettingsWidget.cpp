#include "UI/BFSettingsWidget.h"

#include "Settings/BFGameSettings.h"
#include "Gameplay/BFGameInstance.h"

void UBFSettingsWidget::NativeConstruct()
{
	Super::NativeConstruct();

	if (!Pending)
	{
		Pending = NewObject<UBFGameSettings>(this);
	}

	CopyInto(Pending, GetLive());
	bDirty = false;
	OnSettingsRefreshed();
}

UBFGameSettings* UBFSettingsWidget::GetLive() const
{
	if (const UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		return GI->GetSettings();
	}
	return nullptr;
}

void UBFSettingsWidget::CopyInto(UBFGameSettings* Target, const UBFGameSettings* Source) const
{
	if (!Target || !Source)
	{
		return;
	}

	// Property-wise copy so adding an option later needs no change here.
	for (TFieldIterator<FProperty> It(UBFGameSettings::StaticClass()); It; ++It)
	{
		FProperty* Property = *It;
		if (!Property->HasAnyPropertyFlags(CPF_Config))
		{
			continue;
		}
		Property->CopyCompleteValue(
			Property->ContainerPtrToValuePtr<void>(Target),
			Property->ContainerPtrToValuePtr<void>(const_cast<UBFGameSettings*>(Source)));
	}
}

void UBFSettingsWidget::Apply()
{
	UBFGameSettings* Live = GetLive();
	if (!Live || !Pending)
	{
		return;
	}

	CopyInto(Live, Pending);
	Live->ApplyAll(this);
	Live->SaveToDisk();
	bDirty = false;
	OnSettingsRefreshed();
}

void UBFSettingsWidget::Cancel()
{
	UBFGameSettings* Live = GetLive();

	// Audio was previewed live, so restore it from the stored values on the way out.
	if (Live)
	{
		Live->ApplyAudio(this);
	}

	CopyInto(Pending, Live);
	bDirty = false;
	OnSettingsRefreshed();
}

void UBFSettingsWidget::ResetDefaults()
{
	if (UBFGameSettings* Live = GetLive())
	{
		Live->ResetToDefaults();
		Live->ApplyAll(this);
		CopyInto(Pending, Live);
	}
	bDirty = false;
	OnSettingsRefreshed();
}

void UBFSettingsWidget::PreviewAudio()
{
	if (!Pending)
	{
		return;
	}

	if (UBFGameSettings* Live = GetLive())
	{
		// Only the volumes: we do not want a resolution change mid-drag.
		Live->MasterVolume = Pending->MasterVolume;
		Live->MusicVolume = Pending->MusicVolume;
		Live->EffectsVolume = Pending->EffectsVolume;
		Live->VoiceVolume = Pending->VoiceVolume;
		Live->RadioVolume = Pending->RadioVolume;
		Live->ApplyAudio(this);
	}

	bDirty = true;
}

void UBFSettingsWidget::SetPreset(EBFQualityPreset Preset)
{
	if (Pending)
	{
		Pending->QualityPreset = Preset;
		if (Preset != EBFQualityPreset::Custom)
		{
			// Reflect the preset in the individual sliders so the UI shows the truth,
			// without touching the live renderer before the player presses Apply.
			Pending->ApplyPresetToFields(Preset);
		}
		bDirty = true;
		OnSettingsRefreshed();
	}
}

TArray<FIntPoint> UBFSettingsWidget::GetResolutions() const
{
	return Pending ? Pending->GetSupportedResolutions() : TArray<FIntPoint>();
}

FText UBFSettingsWidget::FormatResolution(FIntPoint Res) const
{
	return FText::FromString(FString::Printf(TEXT("%d x %d"), Res.X, Res.Y));
}

void UBFSettingsWidget::RebindKey(FName ActionName, const FKey& NewKey, bool bSecondary)
{
	if (Pending)
	{
		Pending->SetKeyBinding(ActionName, NewKey, bSecondary);
		bDirty = true;
		OnSettingsRefreshed();
	}
}

FText UBFSettingsWidget::GetBindingLabel(FName ActionName, bool bSecondary) const
{
	if (!Pending)
	{
		return FText::GetEmpty();
	}

	const FKey Key = Pending->GetKeyBinding(ActionName, bSecondary);
	return Key.IsValid() ? Key.GetDisplayName() : FText::FromString(TEXT("-"));
}
