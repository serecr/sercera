#include "UI/BFMainMenuWidget.h"

#include "Gameplay/BFGameInstance.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/PlayerController.h"
#include "HAL/PlatformApplicationMisc.h"
#include "Kismet/KismetSystemLibrary.h"

void UBFMainMenuWidget::Play()
{
	// Host an advertised listen server so friends can find it in the browser.
	if (UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		GI->HostListenServer(FString(), DefaultMapName, DefaultMaxPlayers);
		return;
	}

	const FString Options = FString::Printf(TEXT("/Game/Maps/%s?listen?MaxPlayers=%d"),
		*DefaultMapName.ToString(), DefaultMaxPlayers);
	UGameplayStatics::OpenLevel(this, FName(*Options));
}

void UBFMainMenuWidget::StartTraining()
{
	// Offline, no networking: a quiet trench to learn movement, weapons and building.
	UGameplayStatics::OpenLevel(this, TrainingMapName);
}

void UBFMainMenuWidget::RefreshServers()
{
	if (UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		GI->RefreshServerList();
	}
}

void UBFMainMenuWidget::JoinServer(const FBFServerEntry& Entry)
{
	if (Entry.ConnectString.IsEmpty())
	{
		return;
	}

	if (APlayerController* PC = GetOwningPlayer())
	{
		PC->ClientTravel(Entry.ConnectString, ETravelType::TRAVEL_Absolute);
	}
}

void UBFMainMenuWidget::HostDedicatedInfoCopy()
{
	// Convenience for server admins: the exact command line for a dedicated server.
	const FString Command = FString::Printf(
		TEXT("BrokenFrontServer.exe /Game/Maps/%s -log -port=7777"), *DefaultMapName.ToString());
	FPlatformApplicationMisc::ClipboardCopy(*Command);
}

void UBFMainMenuWidget::QuitGame()
{
	if (APlayerController* PC = GetOwningPlayer())
	{
		UKismetSystemLibrary::QuitGame(this, PC, EQuitPreference::Quit, false);
	}
}

FText UBFMainMenuWidget::GetPlayerNickname() const
{
	if (const UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		return FText::FromString(GI->GetNickname());
	}
	return FText::GetEmpty();
}

void UBFMainMenuWidget::SetPlayerNickname(const FString& NewNickname)
{
	if (UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		GI->SetNickname(NewNickname);
	}
}

int32 UBFMainMenuWidget::GetPlayerLevel() const
{
	if (const UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		return GI->GetCareerLevel();
	}
	return 1;
}

float UBFMainMenuWidget::GetLevelProgressPercent() const
{
	if (const UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		return GI->GetLevelProgressPercent();
	}
	return 0.f;
}

FBFProfileStats UBFMainMenuWidget::GetProfileStats() const
{
	if (const UBFGameInstance* GI = Cast<UBFGameInstance>(GetGameInstance()))
	{
		return GI->GetProfileStats();
	}
	return FBFProfileStats();
}
