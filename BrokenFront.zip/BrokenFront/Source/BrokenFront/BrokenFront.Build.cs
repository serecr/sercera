using UnrealBuildTool;

public class BrokenFront : ModuleRules
{
	public BrokenFront(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;
		CppStandard = CppStandardVersion.Cpp20;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"InputCore",
			"EnhancedInput",
			"UMG",
			"Slate",
			"SlateCore",
			"GameplayTags",
			"Niagara",
			"PhysicsCore",
			"Chaos",
			"ChaosVehicles",
			"GeometryCollectionEngine",
			"AudioMixer",
			"MetasoundEngine",
			"OnlineSubsystem",
			"OnlineSubsystemUtils",
			"ApplicationCore",
			"RHI",
			"Landscape"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Renderer"
		});

		// Public include path so headers can be included as "Characters/BFCharacter.h".
		PublicIncludePaths.Add(ModuleDirectory);
	}
}
