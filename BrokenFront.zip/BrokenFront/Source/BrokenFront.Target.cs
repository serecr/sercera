using UnrealBuildTool;

public class BrokenFrontTarget : TargetRules
{
	public BrokenFrontTarget(TargetInfo Target) : base(Target)
	{
		Type = TargetType.Game;
		DefaultBuildSettings = BuildSettingsVersion.V5;
		IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;
		ExtraModuleNames.Add("BrokenFront");
	}
}
