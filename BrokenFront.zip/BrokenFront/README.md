# BROKEN FRONT
### The Front Never Stays Broken.

Tactical first-person shooter for **Unreal Engine 5.4**. Two fictional factions, the
**Ironclad Coalition** and the **Ashguard Union**, fight over a ladder of sectors on one
large World Partition map. The front moves forward and backward for the whole match.

Fully fictional setting. No real armies, conflicts, insignia or political symbols.

---

## 1. Build and run

```
# 1. Right click BrokenFront.uproject -> Generate Visual Studio project files
# 2. Open BrokenFront.sln, build the "Development Editor" configuration
# 3. Open BrokenFront.uproject

# Dedicated server
BrokenFrontServer.exe /Game/Maps/BF_BrokenFront -log -port=7777
# Client
BrokenFront.exe 127.0.0.1:7777
# Two clients from the editor: Play -> Net Mode: Play As Client, Number of Players: 2
```

Requires UE 5.4 and a C++ toolchain (MSVC 2022 on Windows, clang on Linux).

## 2. What is implemented in C++

Everything gameplay bearing lives in `Source/BrokenFront`. Blueprints are meant for
assets, tuning and presentation only, never for rules.

| Area | Classes |
|---|---|
| Framework | `ABFGameMode`, `ABFGameState`, `ABFPlayerState`, `ABFPlayerController`, `UBFGameInstance`, `UBFSaveGame` |
| Character | `ABFCharacter`, `UBFHealthComponent`, `UBFMudComponent`, `UBFFootstepComponent`, `UBFInventoryComponent` |
| Weapons | `ABFWeaponBase` + `ABFRifle` / `ABFSMG` / `ABFPistol` / `ABFShotgun` / `ABFMachineGun` / `ABFSniper`, `ABFProjectile` |
| Frontline | `ABFFrontlineManager`, `ABFSector`, `ABFSpawnPoint`, `ABFObjective` |
| Managers | `UBFMatchManager`, `UBFSpawnManager`, `UBFObjectiveManager`, `UBFDamageManager`, `ABFWeatherManager`, `ABFAudioManager`, `ABFCraterManager` |
| Destruction | `ABFDestructibleActor`, `ABFBuildableDefense`, `UBFBuildComponent` |
| Equipment | `ABFEquipmentBase`, `ABFMedicalKit`, `ABFRepairTool`, `ABFAmmoBag`, `ABFDroneController`, `ABFReconDrone` |
| Vehicles | `ABFVehicleBase` (Chaos Vehicles) |
| Comms | `UBFRadioComponent` |
| UI | `UBFHUDWidget`, `UBFMinimapWidget`, `UBFDeployWidget`, `UBFScoreboardWidget`, `UBFMainMenuWidget`, `UBFServerBrowserWidget`, `UBFSettingsWidget` |
| Settings | `UBFGameSettings` (graphics, audio, controls, gameplay, LOW/MEDIUM/HIGH/EPIC) |

## 3. Frontline model

Sectors form an ordered ladder by `LineIndex`:

```
IRONCLAD BASE -> RESERVE -> MAIN TRENCH -> FORWARD -> NO MAN'S LAND -> ENEMY FRONT -> ASHGUARD BASE
```

`ABFFrontlineManager` keeps two pointers, one per team, and only the sectors between them
are capture enabled. Consequences of a flip, all server side, all in one place
(`ABFSector::OnOwnerChanged` -> `ABFFrontlineManager::Recalculate`):

* spawn points of the lost sector are disabled, the new ones come online
* the active window shifts, so routes open and close
* objectives are regenerated from the new front position
* the replicated sector snapshot updates the HUD and the minimap
* a `ShiftCooldown` lockout gives the losing side time to organise a counter-attack

Capture progress is signed, `-1` Ironclad to `+1` Ashguard. Two teams inside the
volume freezes it completely (CONTESTED), no majority rule. Capture rate uses
`sqrt` diminishing returns so a 20 player zerg is not 20 times faster than one squad.
Victory: take the enemy home base, exhaust their tickets, or hold a sector advantage
when the clock runs out.

## 4. Deliberate engineering decisions

**Craters are instanced meshes, not landscape deformation.** Runtime heightmap edits do
not replicate cheaply and do not survive 64 players on a World Partition map.
`ABFCraterManager` uses a HISM with collision, a merge radius so overlapping shells do
not stack, and an oldest-first recycle cap. Craters persist and are usable as cover.

**Destruction is a three stage model.** Intact -> damaged (swapped mesh, shoot-through
holes) -> destroyed (Chaos `GeometryCollection` release plus a disabled
`BlockedRouteVolume`). That volume is the mechanical meaning of "a destroyed wall opens
a new route": route blocking is data, not geometry guesswork.

**Health has a downed/bleed-out window.** Medics matter, and overkill damage skips it so
a direct explosion is still lethal.

**The minimap never shows continuous enemy positions.** Only time limited, fading spot
marks from the drone and the Scout. Information is a resource.

**The drone is not a weapon.** Battery, link distance, altitude ceiling, line-of-sight
gated spotting, replicated owner only.

**No AI is required.** There is no bot dependency anywhere in the match loop.

## 5. Networking

Server authoritative throughout. Clients predict camera feel, cosmetic recoil, mud and
footsteps only. Weapon fire is predicted visually, then validated on the server with a
rate limit and an origin clamp. Nothing that decides a kill, a capture, a spawn or a
build happens on a client. Configured for 32-64 players (`Config/DefaultEngine.ini`).

## 6. Data-driven content

`UBFWeaponDataAsset`, `UBFSoldierClassDataAsset`, `UBFSectorDataAsset`, `FBFWeatherPreset`
rows, `FBFLoadout`. Weapon subclasses hold no numbers at all, only category behaviour:
a new rifle is a new Data Asset plus a Blueprint child, no code.

## 7. Content that must be authored in the editor

The C++ layer is complete and compiles on its own. Binary `.uasset` files cannot be
generated outside the editor, so the following still has to be created once inside UE 5.4.
Every one of them has a C++ owner already waiting for it, with sane fallbacks so the
project runs before they exist:

1. `BP_BFCharacter`, arms + body skeletal meshes, animation Blueprint
2. Weapon Blueprints and `DA_Weapon_*` Data Assets, one per weapon
3. `DA_Class_*` for the six soldier classes
4. `DT_WeatherPresets` with the nine weather states
5. Trench, bunker, tunnel and No Man's Land modular meshes, plus `GeometryCollection`s
6. `WBP_*` widgets parented to the C++ widget classes
7. `IMC_Default` Enhanced Input context and the `IA_*` actions listed in `UBFGameSettings`
8. Sound classes and cues under `/Game/Audio/Mix`
9. `BF_BrokenFront` World Partition map with the sector ladder and `MainMenu` / `BF_Training`

## 8. Verification checklist

Run after each stage: Compile, Build, Play In Editor, dedicated server + two clients,
replication (`net.PktLag`), FPS (`stat unit`), memory (`stat memory`), collision
(`show collision`), input, UI, audio (`au.Debug.Sounds`).
